jQuery(document).ready(function ($) {

/////////////////////// MUDAR SETOR #1 ///////////////////////
jQuery(document).on("change", ".nome_integrante_js select", function(){

  var parent = $(this).closest('.cmb-repeatable-grouping').find('.setor_integrante_js input');

  var userId = $(this).val();

  $.ajax({
             type: "POST",
             url: 'http://localhost/nhcsite/wp-admin/admin-ajax.php',
             data:{action:'get_user_setor', id: userId},
             success:function(html) {
              // Adiciona o setor com base no usuário
               jQuery(parent).val(html);
               // alert(jQuery(parent).val());
             }

        });

});
/////////////////////// MUDAR SETOR #1 ///////////////////////
       
});