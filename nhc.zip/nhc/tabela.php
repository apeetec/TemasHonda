<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

$loop = new WP_Query( $args );

if ( $loop->have_posts() ) { ?>

<div class="flow-root head">
<div class="single">
  <p>Nome do grupo</p>
</div>
<div class="single" id="middle">
  <p>Integrantes</p>
</div>
<div class="single">
  <p>Ações</p>
</div>
</div>

<?php

if ($loop->have_posts()) 

while ( $loop->have_posts() ) : $loop->the_post();

$ids_integrantes = array();
$orientador = get_post_meta( get_the_ID(), 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
$integrantes = get_post_meta( get_the_ID(), 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
$confirmados = get_post_meta( get_the_ID(), 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );                     
$confirma_1_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
$confirma_2_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
$confirma_3_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );                     

  $count = $count + 1;

  ?>

  <div class="flow-root corpo">
    <div class="single">
      <p id="title-name">
        <?php the_title(); ?>
      </p>
    </div>
    <div class="single" id="integrantes">

      <?php
      // Exibe orientador

      if(!empty($orientador)) { ?>
      <b id="ori">Orientador: </b><p><?php echo get_user_meta($orientador, 'first_name', true);; ?></p>
      <?php } 

      if($integrantes) {
      
      echo '<b id="int">Integrantes:</b>';
      foreach((array) $integrantes as $key => $entry ){ ?>
       <p>
        <?php $id = $entry['grupos_integrantes_nome']; echo get_user_meta($id, 'first_name', true);

        // Exibe se integrante confirmou ou não
        $confirmados_array = explode(" ", $confirmados);  
        if (in_array($id,$confirmados_array)) {
          echo '<i class="fas fa-check-circle"></i>';
        }
        else {
          echo '<i class="fas fa-exclamation-circle"></i>';
        }
        ?>
       </p>
      <?php
        } }
      ?>
    </div>
    <div class="single">
      <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit">Editar</a>

      <?php if($status != 'Inscrição') { ?>
      <span id="status-label">Confirmação: <?php echo $status; ?>:</span>
      <span id="status-confirma">
        <?php

        if(
        $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
        $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
        $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
        ) {
          echo '<span class="status-confirma" id="pendente">Pendente</span>';
        }
        else if(
        $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
        $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
        $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
        ) {
          echo '<span class="status-confirma" id="confirmado">Confirmado</span>';
        }

        else {
          echo '<span class="status-confirma" id="pendente">Pendente</span>';
        }
        ?>
      </span>
      <?php } ?>
      
    </div>
  </div> 

<?php endwhile;

  } else {
      echo '<div id="text"><p>Você ainda não é orientador(a) de nenhum grupo.</div>';
  }

wp_reset_postdata();

?>