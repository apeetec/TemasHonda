<?php get_header(); ?>

<style>
.postPage {padding: 70px 0px 40px 0px;font-size: 17px;}
</style>
	
<div class="postPage">
	<div class="container">
		<div class="content">
			<div class="post-content">
				<?php 
					$id=get_the_ID(); 
					$post = get_post($id); 
					$content = apply_filters('the_content', $post->post_content); 
					echo $content;  
				?>	
			</div>
		</div>
	</div>
</div>

<?php get_footer(); ?>