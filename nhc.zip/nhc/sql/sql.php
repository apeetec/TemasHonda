<?php
/**
 * CSV User Import Script
 * Handles bulk user creation and updates via CSV upload
 */

// Enable error reporting for debugging (disable in production)
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Set memory limit and execution time for large imports
ini_set('memory_limit', '256M');
set_time_limit(300);

// Load WordPress
try {
    $path = preg_replace('/wp-content.*$/', '', __DIR__);
    $path = preg_replace('/wp-content(?!.*wp-content).*/', '', __DIR__);
    
    if (!file_exists($path . 'wp-load.php')) {
        throw new Exception('WordPress não encontrado');
    }
    
    require_once($path . 'wp-load.php');
} catch (Exception $e) {
    sendJsonResponse(false, 'Erro ao carregar WordPress: ' . $e->getMessage());
}

/**
 * Send JSON response and exit
 */
function sendJsonResponse($success, $message, $data = []) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Process taxonomy term (create if not exists)
 */
function processTerm($term, $taxonomy) {
    if (empty($term) || empty($taxonomy)) {
        return '';
    }
    
    // Convert to lowercase and sanitize for taxonomy terms
    $term = sanitize_title(strtolower(trim($term)));
    
    if (empty($term)) {
        return '';
    }
    
    $termObj = get_term_by('slug', $term, $taxonomy);
    if ($termObj && !is_wp_error($termObj)) {
        return $termObj->slug;
    }
    
    // Try to find by name as fallback
    $termObj = get_term_by('name', $term, $taxonomy);
    if ($termObj && !is_wp_error($termObj)) {
        return $termObj->slug;
    }
    
    $insertTerm = wp_insert_term($term, $taxonomy);
    if (is_wp_error($insertTerm)) {
        // Check if term already exists error
        if ($insertTerm->get_error_code() === 'term_exists') {
            $term_id = $insertTerm->get_error_data('term_exists');
            $existingTerm = get_term_by('id', $term_id, $taxonomy);
            return $existingTerm ? $existingTerm->slug : '';
        }
        error_log('Erro ao inserir termo: ' . $insertTerm->get_error_message());
        return '';
    }
    
    $newTerm = get_term_by('id', $insertTerm['term_id'], $taxonomy);
    return $newTerm ? $newTerm->slug : '';
}

/**
 * Validate email format
 */
function validateEmail($email) {
    $email = sanitize_email(trim(str_replace(' ', '', $email)));
    return is_email($email) ? $email : false;
}

/**
 * Validate user data
 */
function validateUserData($entry) {
    $errors = [];
    
    if (empty($entry['user_login'])) {
        $errors[] = 'Login obrigatório';
    }
    
    if (empty($entry['user_email'])) {
        $errors[] = 'Email obrigatório';
    } elseif (!validateEmail($entry['user_email'])) {
        $errors[] = 'Email inválido';
    }
    
    if (empty($entry['user_pass'])) {
        $errors[] = 'Senha obrigatória';
    }
    
    return $errors;
}

// Security checks
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Método não permitido');
}

// Verify nonce
if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'csv_user_import')) {
    sendJsonResponse(false, 'Verificação de segurança falhou. Recarregue a página e tente novamente.');
}

// Check user capabilities
if (!current_user_can('create_users')) {
    sendJsonResponse(false, 'Você não tem permissão para importar usuários.');
}

// Validate file upload
if (!isset($_FILES['csvFile']) || $_FILES['csvFile']['error'] !== UPLOAD_ERR_OK) {
    $uploadErrors = [
        UPLOAD_ERR_INI_SIZE => 'Arquivo muito grande',
        UPLOAD_ERR_FORM_SIZE => 'Arquivo excede o limite',
        UPLOAD_ERR_PARTIAL => 'Upload parcial',
        UPLOAD_ERR_NO_FILE => 'Nenhum arquivo enviado',
    ];
    $errorMsg = $uploadErrors[$_FILES['csvFile']['error']] ?? 'Erro no upload';
    sendJsonResponse(false, $errorMsg);
}

// Validate file type
$fileExtension = strtolower(pathinfo($_FILES['csvFile']['name'], PATHINFO_EXTENSION));
if ($fileExtension !== 'csv') {
    sendJsonResponse(false, 'Apenas arquivos CSV são permitidos');
}

// Read and parse CSV
try {
    $file = $_FILES['csvFile']['tmp_name'];
    
    if (!file_exists($file) || !is_readable($file)) {
        throw new Exception('Arquivo não pode ser lido');
    }
    
    $csvData = array_map(function($row) {
        if (empty($row)) return null;
        $converted = mb_convert_encoding($row, 'UTF-8', 'ISO-8859-1');
        return str_getcsv($converted, ";");
    }, file($file));
    
    $csvData = array_filter($csvData); // Remove empty lines
    
    if (count($csvData) < 2) {
        throw new Exception('Arquivo CSV vazio ou sem dados');
    }
    
} catch (Exception $e) {
    sendJsonResponse(false, 'Erro ao ler CSV: ' . $e->getMessage());
}

// Process CSV data
$usuariosCadastrados = [];
$usuariosNaoCadastrados = [];
$usuariosJaExistentes = [];
$erros = [];

$metaboxes = array_shift($csvData); // Get header row
$batchSize = 50;
$totalProcessed = 0;

global $wpdb;

foreach (array_chunk($csvData, $batchSize) as $batchIndex => $batch) {
    try {
        $wpdb->query('START TRANSACTION');
        
        foreach ($batch as $rowIndex => $userData) {
            try {
                // Combine header with data
                if (count($userData) !== count($metaboxes)) {
                    throw new Exception('Número de colunas incompatível');
                }
                
                $entry = array_combine($metaboxes, $userData);
                
                // Validate user data
                $validationErrors = validateUserData($entry);
                if (!empty($validationErrors)) {
                    $usuariosNaoCadastrados[] = [
                        'login' => $entry['user_login'] ?? 'Desconhecido',
                        'erros' => $validationErrors
                    ];
                    continue;
                }
                
                // Sanitize email
                $email = validateEmail($entry['user_email']);
                if (!$email) {
                    $usuariosNaoCadastrados[] = [
                        'login' => $entry['user_login'],
                        'erros' => ['Email inválido']
                    ];
                    continue;
                }
                $entry['user_email'] = $email;
                
                // Check if user exists
                $user = get_user_by('email', $email);
                
                // Process taxonomy terms
                if (!empty($entry['user_infos_unidades'])) {
                    $entry['user_infos_unidades'] = processTerm($entry['user_infos_unidades'], 'user_unidade');
                }
                if (!empty($entry['user_infos_empresas'])) {
                    $entry['user_infos_empresas'] = processTerm($entry['user_infos_empresas'], 'user_empresa');
                }
                if (!empty($entry['user_infos_setores'])) {
                    $entry['user_infos_setores'] = processTerm($entry['user_infos_setores'], 'user_setor');
                }
                
                if ($user) {
                    // Update existing user
                    $user_id = $user->ID;
                    
                    // Update user meta
                    foreach ($entry as $key => $value) {
                        if (!in_array($key, ['user_pass', 'role'])) {
                            update_user_meta($user_id, $key, sanitize_text_field($value));
                        }
                    }
                    
                    // Update role
                    if (!empty($entry['role'])) {
                        $u = new WP_User($user_id);
                        $u->set_role(sanitize_text_field($entry['role']));
                    }
                    
                    // Update password
                    if (!empty($entry['user_pass'])) {
                        wp_set_password($entry['user_pass'], $user_id);
                    }
                    
                    $usuariosJaExistentes[] = sanitize_text_field($entry['user_login']);
                    
                } else {
                    // Create new user
                    $userData = [
                        'user_login' => sanitize_user($entry['user_login']),
                        'user_email' => $email,
                        'user_pass' => $entry['user_pass'],
                        'role' => sanitize_text_field($entry['role'] ?? 'subscriber')
                    ];
                    
                    // Add optional fields
                    if (!empty($entry['first_name'])) {
                        $userData['first_name'] = sanitize_text_field($entry['first_name']);
                    }
                    if (!empty($entry['last_name'])) {
                        $userData['last_name'] = sanitize_text_field($entry['last_name']);
                    }
                    
                    $user_id = wp_insert_user($userData);
                    
                    if (is_wp_error($user_id)) {
                        throw new Exception($user_id->get_error_message());
                    }
                    
                    // Update custom meta fields
                    foreach ($entry as $key => $value) {
                        if (!in_array($key, ['user_login', 'user_email', 'user_pass', 'role', 'first_name', 'last_name'])) {
                            update_user_meta($user_id, $key, sanitize_text_field($value));
                        }
                    }
                    
                    $usuariosCadastrados[] = sanitize_text_field($entry['user_login']);
                }
                
                $totalProcessed++;
                
            } catch (Exception $e) {
                error_log('Erro ao processar usuário: ' . $e->getMessage());
                $usuariosNaoCadastrados[] = [
                    'login' => $entry['user_login'] ?? 'Desconhecido',
                    'erros' => [$e->getMessage()]
                ];
            }
        }
        
        $wpdb->query('COMMIT');
        
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        error_log('Erro no lote ' . $batchIndex . ': ' . $e->getMessage());
        $erros[] = 'Erro no lote ' . ($batchIndex + 1) . ': ' . $e->getMessage();
    }
}

// Prepare response HTML
$html = '<div class="import-results">';

if (!empty($usuariosJaExistentes)) {
    $html .= '<div class="grid-div"><h3>Usuários Atualizados (' . count($usuariosJaExistentes) . ')</h3>';
    foreach ($usuariosJaExistentes as $login) {
        $html .= '<p>' . esc_html($login) . '</p>';
    }
    $html .= '</div>';
}

if (!empty($usuariosCadastrados)) {
    $html .= '<div class="grid-div"><h3>Usuários Criados (' . count($usuariosCadastrados) . ')</h3>';
    foreach ($usuariosCadastrados as $login) {
        $html .= '<p>' . esc_html($login) . '</p>';
    }
    $html .= '</div>';
}

if (!empty($usuariosNaoCadastrados)) {
    $html .= '<div class="grid-div"><h3>Usuários com Erro (' . count($usuariosNaoCadastrados) . ')</h3>';
    foreach ($usuariosNaoCadastrados as $item) {
        $login = is_array($item) ? $item['login'] : $item;
        $errors = is_array($item) && isset($item['erros']) ? ' - ' . implode(', ', $item['erros']) : '';
        $html .= '<p>' . esc_html($login . $errors) . '</p>';
    }
    $html .= '</div>';
}

$html .= '</div>';

sendJsonResponse(true, 'Processamento concluído', [
    'html' => $html,
    'total_processado' => $totalProcessed,
    'criados' => count($usuariosCadastrados),
    'atualizados' => count($usuariosJaExistentes),
    'erros' => count($usuariosNaoCadastrados)
]);
?>
