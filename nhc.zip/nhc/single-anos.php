<?php get_header(); ?>

    <?php

    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];

    $ano_home_id = $opcoes_gerais['opcoes_gerais_ano_usuarios_' . $user_empresa];
    $ano_home = $ano_home_id; // SLUG

    $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

    ?>

    <?php
    ///////////// VERIFICACAO DE HORÁRIO - PARTE 1/2 /////////////

    // Variáveis dos horários selecionados
    $begin = $opcoes_gerais['opcoes_gerais_abertura_' . $user_empresa];
    $end = $opcoes_gerais['opcoes_gerais_fechamento_' . $user_empresa];
    $liberacao = $opcoes_gerais['opcoes_gerais_ignorar_' . $user_empresa];

    ////// Verifica Timezone
    if($user_empresa == 'har') {
      date_default_timezone_set('America/Argentina/Buenos_Aires');
    }
    else if($user_empresa == 'hmdc') {
      date_default_timezone_set('America/Santiago');
    }
    else {
      date_default_timezone_set('America/Sao_Paulo');
    }
    ////// Fim timezone
    $now  = date("H:i", strtotime("now")); // Date('H:i')
    /* // FORMATO: 16:51    
    echo 'Begin: ' . $begin;
    echo '<br>Agora: ' . $now;
    echo '<br>End: ' . $end; */ 

    ################ BLOQUEIO CUSTOMIZADO HAB ################
    // Obs: atualizar também o arquivo 'horário.php' com o mesmo código abaixo

    
    if($user_empresa == 'hab') {
    $turno = get_user_meta($current_user_id, 'user_infos_turno', true);
    switch ($turno) {
      case '1-turno':
          // $begin = date('06:00');
          // $end = date('17:00');

          $begin = date("H:i", strtotime("06:00"));
          $end = date("H:i", strtotime('+1 day',"17:00"));
          break;
      case '2-turno':
          // $begin = date('15:30');
          // $end = date('03:00');
          $begin = date("H:i", strtotime("15:30"));
          $end = date("H:i", strtotime('+1 day',"03:00"));
          break;
      case '3-turno':
          // $begin = date('23:30');
          // $end = date('07:00');

          $begin = date("H:i", strtotime("23:30"));
          $end = date("H:i", strtotime('+1 day',"07:00"));
          break;
      case '4-turno':
        // $begin = date('01:00');
        // $end = date('23:59');
        $begin = date("H:i", strtotime("01:00"));
        $end = date("H:i", strtotime('+1 day',"23:59"));
        break;
      default:
        // $begin = date('07:30');
        // $end = date('18:00');
        $begin = date("H:i", strtotime("07:30"));
        $end = date("H:i", strtotime('+1 day',"18:00"));
       
      }
    }


    // // HAB
    // if($user_empresa == 'hab') {
    //   $turno = get_user_meta($current_user_id, 'user_infos_turno', true);
    //   if($turno == '1-turno') {
    //     $begin = '06:00';
    //     $end = '17:00';
    //   }
    //   else if($turno == '2-turno') {
    //     $begin = '15:30';
    //     $end = '03:00';       
    //   }
    //   else if($turno == '3-turno') {
    //     $begin = '23:30';
    //     $end = '07:00';
    //   }
    //   else if($turno == '4-turno') {
    //     // doesn't exist, neutral values for all day
    //     $begin = '01:00';
    //     $end = '23:59';
    //   }
    //   else if($turno == 'adm') {
    //     $begin = '07:30';
    //     $end = '18:00';
    //   }
    // }
    
    ################ FIM BLOQUEIO CUSTOMIZADO HAB ################

    // Condição: Se tempo de inicio for maior que hora atual, opção de liberacao nao estiver marcada e usuario nao for comissao nem administrador... ou
    // Condição: Se hora atual for maior que término, opção de liberacao nao estiver marcada e usuario nao for comissao nem administrador...
    if (
      $begin >= $now && !empty($begin) && $liberacao == 'Não' && !current_user_can('administrator') && !current_user_can('comissao') || 
      $now >= $end && !empty($end) && $liberacao == 'Não' && !current_user_can('administrator') && !current_user_can('comissao')
      ) {

      set_query_var( 'begin', $begin );
      set_query_var( 'end', $end );
      get_template_part('horario');

    }

    else {

    ?>      

    <?php
    ///////////////////////// Verificação de acesso interno
    /*
    $ip = $_SERVER['REMOTE_ADDR'];
    $ip_lista = file_get_contents("http://ip-api.com/json/");
    $json = json_decode($ip_lista,true);
    $isp = $json['isp'];
    $query = $json['query'];
    // PC local: 201.68.164.11 - Vivo

    if($query == '147.161.129.73' && $isp == 'SCALER, INC.') {
      echo '<p id="interno" class="space-top">(É acesso interno)</p>';
    }
    else {
      echo '<p id="interno" class="space-top">(Não é acesso interno)</p>';
    }
    ///////////////////////// Fim Verificação de acesso interno
    */
    ?>

      <?php if(

        // Condições para exibição de conteúdo
        // Exibe conteúdo apenas se o status for diferente de bloqueado
        $status != 'Bloqueado'
        || // ou - Exibe se estiver bloqueado mas é 'administrator'
        $status == 'Bloqueado' && current_user_can('administrator')
        || // ou - Exibe se estiver bloqueado mas é 'comissao'
        $status == 'Bloqueado' && current_user_can('comissao')

      ) { // Exibe conteudo apenas se status não for bloqueado 

      if($ano_home == get_the_title()) {

      // Verifica se ano vigente da home (opções gerais) é o mesmo ano da página selecionada pela comissao para ser a princial, se for, exibe conteúdo de grupos apenas nela

      if(current_user_can('orientador')) {

        // Exibe a tabela de grupos da página do orientador
        get_template_part('orientadores/content','tabela');

      ?>

        <!--<div class="message space-top">
          <div class="container">
            <div class="content">
              <p><a href="<?php echo get_site_url(); ?>/orientador">Clique aqui</a> para visualizar os grupos em que você é orientador!</p>
            </div>
          </div>
        </div>-->

        <?php }
        
        if(current_user_can('coordenador') || current_user_can('membro-coordenador')) { 

        // Legenda de confirmação de participacao de grupo
        get_template_part('legenda');

        // Tabela de grupos criados por coordenadores
        get_template_part('coordenadores/content','tabela');
        
        }

        if(current_user_can('membro') || current_user_can('membro-coordenador')) {

        // Tabela de grupos criados aguardando aprovacao
        get_template_part('membro/content','tabela');

        } 

      } // Fim verificação se ano vigente

      ?>

      <?php } // Fim verificação se status é BLOQUEADO

      else { get_template_part('bloqueado'); }

      ?>
  
      <?php

          $entries = get_post_meta( get_the_ID(), 'group_cronograma_' . $user_empresa, true );
          if( !empty( $entries ) ) { ?>

          <div class="cronograma space-top">
            <div class="container">

              <h1><?php echo apply_filters('str_from_lang','Cronograma','Cronología'); ?></h1>

              <ul id='timeline' class="<?php foreach ( (array) $entries as $key => $entry ) { $sum = $sum + 1; } echo 'contador' . $sum; ?>">

                <?php
                    $classes = array('up', 'down');
                    $data_sem_formato = new DateTime();
                    $data_com_formato = $data_sem_formato->format('y/m/d'); // MySQL datetime format
                    $hoje = $data_com_formato;

                    foreach ( (array) $entries as $key => $entry ) {
                    $titulo = $entry['title_' . $user_empresa];
                    $data_1 = $entry['date_1_' . $user_empresa];
                    $data_1_formatada = date('y/m/d', strtotime($data_1));
                    $data_2 = $entry['date_2_' . $user_empresa];
                    if($data_2) {$data_2_formatada = date('y/m/d', strtotime($data_2));}
                    $text = $entry['custom_text_' . $user_empresa];
                    $counter = $counter + 1;
                    $class = $classes[$i++ % 2];

                    /*
                    // Verificação das datas
                    echo 'Hoje: ' . $hoje;
                    echo '<br>';
                    echo 'Data #1: ' . $data_1_formatada;
                    echo '<br>';
                    echo 'Data #2: ' . $data_2_formatada;
                    echo '<br>';*/                 

                    ?>

                    <li class='event <?php echo $class; ?>'>
                      <div class='content'>
                        <div class="conteudo<?php
                          if((!empty($data_1_formatada) && $hoje >= $data_1_formatada) && (!empty($data_2_formatada) && $hoje <= $data_2_formatada)) { echo ' active'; }
                          else if(empty($data_2_formatada) && $data_1_formatada == $hoje) {
                            echo ' active';
                          }
                          if($data_1_formatada < $hoje && empty($data_2_formatada)) {
                            echo ' passed';
                          }
                          if($data_1_formatada < $hoje && $data_2_formatada < $hoje) {
                            echo ' passed';
                          }
                          ?>">
                          <h2><?php echo $titulo; ?></h2>
                          <p class="data"><?php

                          if(!empty($text)) {
                            echo $text;
                          }
                          elseif(!empty($data_1) && !empty($data_2)) {
                            echo date('d/m', strtotime($data_1)); ?> a <?php echo date('d/m', strtotime($data_2));
                          }
                          elseif(!empty($data_1) && empty($data_2)) {
                            echo date('d/m', strtotime($data_1));
                          }  
                          elseif(empty($data_1) && !empty($data_2)) {
                            echo date('d/m', strtotime($data_2));
                          }                          
                          ?></p>
                        </div>
                      </div>
                      <div class="dot">
                        <span class='circle'></span>
                      </div>
                    </li>

                    <?php
                   
                    }

                  echo '</ul></div></div>';

                 }

          ?>  

        <?php

          $videos = get_post_meta( get_the_ID(), 'videos_files_' . $user_empresa, true );
          if( !empty( $videos ) ) { ?>

        <div class="videos space-top">
          <div class="container">
            <h1><?php echo apply_filters('str_from_lang','Vídeos','Videos'); ?></h1>
            <br>
            <div class="content">
              <div class="slider-videos">
                <?php
                foreach($videos as $video) {
                ?>
                <div class="single">
                  <video controls>
                    <source src="<?php echo $video; ?>" type="video/mp4">
                    <?php echo apply_filters('str_from_lang','Seu navegador não suporta a exibição deste conteúdo','Su navegador no soporta la visualización de este contenido'); ?>
                  </video> 
                </div>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>

        <?php } ?>         

          <?php

          $entries = get_post_meta( get_the_ID(), 'arquivos_files_' . $user_empresa, true );
          $entries2 = get_post_meta( get_the_ID(), 'cartazes_files_' . $user_empresa, true );
          $entries3 = get_post_meta( get_the_ID(), 'reunioes_files_' . $user_empresa, true );

          if( !empty( $entries ) || !empty($entries2) ) { ?>

          <div class="downloads <?php if(current_user_can('comissao') || current_user_can('administrator')) { echo 'user-membro'; } ?>">
            <div class="container">

              <h1><?php echo apply_filters('str_from_lang','Downloads','Descargas'); ?></h1>

                    <div class="single-blocos">
                      <div class="flow-root">
                        <div class="single">
                          <div class="bloco">
                            <h2><?php echo apply_filters('str_from_lang','Arquivos','Archivos'); ?></h2>
                            <div class="links">
                              <?php
                              foreach ( (array) $entries as $attachment_id => $attachment_url ) {
                                $file_name = basename($entries[$attachment_id]); 
                                if(empty($attachment_id)) {
                                  echo '<p id="empty">'.apply_filters('str_from_lang','Nenhum arquivo','Sin archivos').'.</p>';
                                }
                                else {
                                ?>
                                <a href="<?php echo wp_get_attachment_url( $attachment_id ); ?>" download>
                                  <?php echo $file_name; ?>
                                </a>
                              <?php } } ?>
                            </div>
                          </div>
                          <div class="bloco">
                            <h2><?php echo apply_filters('str_from_lang','Cartazes','Carteles'); ?></h2>
                            <div class="links">
                              <?php
                              foreach ( (array) $entries2 as $attachment_id => $attachment_url ) {
                                $file_name = basename($entries2[$attachment_id]);
                                if(empty($attachment_id)) {
                                  echo '<p id="empty">'.apply_filters('str_from_lang','Nenhum arquivo','Sin archivos').'.</p>';
                                }
                                else {
                                ?>
                                <a href="<?php echo wp_get_attachment_url( $attachment_id ); ?>" download>
                                  <?php echo $file_name; ?>
                                </a>
                              <?php } } ?>
                            </div>
                          </div>
                          <?php if(current_user_can('comissao') || current_user_can('administrator') || current_user_can('coordenador')){ ?>
                          <div class="bloco">
                            <h2><?php echo apply_filters('str_from_lang','ATA Reunião','ACTA Reunión'); ?></h2>
                            <div class="links">
                              <?php
                              foreach ( (array) $entries3 as $attachment_id => $attachment_url ) {
                                $file_name = basename($entries3[$attachment_id]);
                                if(empty($attachment_id)) {
                                  echo '<p id="empty">'.apply_filters('str_from_lang','Nenhum arquivo','Sin archivos').'.</p>';
                                }
                                else {
                                ?>
                                <a href="<?php echo wp_get_attachment_url( $attachment_id ); ?>" download>
                                  <?php echo $file_name; ?>
                                </a>
                              <?php } } ?>
                            </div>
                          </div>
                          <?php } ?>
                        </div>
                      </div> 
                    </div> 

          <?php echo '</div></div>'; } ?>    

          <?php

          $entries = get_post_meta( get_the_ID(), 'galeria_' . $user_empresa, true );

          if( !empty( $entries ) ) { ?>

          <div class="gallery">
            <div class="container">

              <h1><?php echo apply_filters('str_from_lang','Galeria','Galería'); ?></h1>

                    <div class="slider-single-fotos galeria">
                      <?php              

                          foreach ( (array) $entries as $key => $entry ) {

                          $thumb = $entry['galeria_file_' . $user_empresa];
                          $link = $entry['galeria_link_' . $user_empresa];
                          $id = $link;

                          $fotos = get_post_meta( $id, 'galeria_fotos', 1 );
                          $first_image_small = reset($fotos);                          
                          $thumb_id = attachment_url_to_postid( $first_image_small );
                          $first_image_url = wp_get_attachment_image_src($thumb_id, 'galeria_thumb');
                          $galeria_thumb = $first_image_url[0];

                          if(!empty($id)) { // Há galeria selecionada

                          ?>

                      <div class="division" style="background-image: url('<?php if(!empty($galeria_thumb)) { echo $galeria_thumb; } else { bloginfo('template_url'); echo '/img/default.png'; } ?>');">
                                <div class="zoom">
                              
                                  <a href="<?php if(!empty($link)) { the_permalink($link); } else { echo '#'; } ?>"<?php if(empty($link)) { echo ' class="notscrollable"'; } ?>>
                                          <img src="<?php bloginfo('template_url'); ?>/img/zoom.png">
                                  </a>

                                </div>
                                <div class="titles">
                                  <h2><?php $title = get_the_title($link);
                                  if(!empty($title)) {
                                    echo $title;
                                  }
                                  else {echo apply_filters('str_from_lang','Sem título','Sin titulo');}
                                  ?></h2>
                                  <p><?php $data = date('d/m/Y', strtotime($entry['galeria_data_' . $user_empresa]));
                                  if(!empty($data)) {
                                    echo $data;
                                  }
                                  else {echo apply_filters('str_from_lang','Data indefinida','Fecha indefinida');}
                                  ?></p>
                                </div>
                              </div>
                            

                      <?php } // Fim do IF

                      } // Endforeach
                          
                      ?>
                    </div>

          <?php echo '</div></div>'; } ?>      

    <?php
    ///////////// VERIFICACAO DE HORÁRIO - PARTE 2/2 ///////////// 
    } // Apenas fecha o else caso não esteja entre o horário bloqueado ?>          

<?php get_footer(); ?>