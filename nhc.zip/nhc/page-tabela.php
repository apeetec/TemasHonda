<?php

/* Template Name: Tabela */

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

if(current_user_can('comissao') || current_user_can('administrator')) {

get_header(); ?>

      <div class="page<?php echo get_the_ID(); ?> page-single" id="scroll">          
        <div class="container">

            <div class="space-top result-btn">
                <a href="<?php echo get_site_url(); ?>/resultados"><?php echo apply_filters('str_from_lang','Gráficos','Gráficos'); ?></a>
                <a class="active" href="<?php echo get_site_url(); ?>/resultados/tabela"><?php echo apply_filters('str_from_lang','Tabela','Tablas'); ?></a>
            </div>

            <?php
            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
            if($user_empresa == 'hsa') {
              $_orientativa_3_texto = 'Classificatória';
            }
            else {
              $_orientativa_3_texto = '3ª Orientativa';
            }
            ################# FIM REGRA ADICIONAL
            ?>

            <div class="tabela-resultados">
              <table id="tabelaresultados" class="display" name="resultados">
                <thead>
                    <tr>
                        <th class="noExl"><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Empresa','Empresa'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmados','Confirmado'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Nome','Coordinador(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Matrícula','Coordinador(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Turno','Coordinador(a): Turno'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Nome','Tutor(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Matrícula','Tutor(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Turno','Tutor(a): Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Camiseta','Tutor(a): Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Qtd. de integrantes do grupo','Cant. de miembros del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Qtd. de confirmados','Cant. de confirmados'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 1ª orientativa?','¿Confirmó la 1ra orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 2ª orientativa?','¿Confirmó la 2da orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a ' . $_orientativa_3_texto,'¿Confirmó la 3ra orientación?'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Nome','1er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Matrícula','1er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Função','1er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Setor','1er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Turno','1er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Camiseta','1er Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Nome','2do Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Matrícula','2do Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Função','2do Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Setor','2do Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Turno','2do Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Camiseta','2do Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Nome','3er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Matrícula','3er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Função','3er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Setor','3er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Turno','3er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Camiseta','3er Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Nome','4to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Matrícula','4to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Função','4to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Setor','4to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Turno','4to Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Camiseta','4to Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Nome','5to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Matrícula','5to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Função','5to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Setor','5to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Turno','5to Integrante: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Camiseta','5to Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1ª Orientativa - Confirma a 1ª orientativa?','1ra Orientativa - Confirma a 1ra orientativa?'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Confirma a 2ª orientativa?','2do Orientativa - Confirma a 2do orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Turno do apresentador','2do Orientativa - Turno do apresentador'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Tema','2do Orientativa - Tema'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Categoria','2do Orientativa - Categoria'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de situação','2do Orientativa - Análise de situação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de causas','2do Orientativa - Análise de causas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Objetivos e metas','2do Orientativa - Objetivos e metas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Estudos e implantação','2do Orientativa - Estudos e implantação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise dos resultados','2do Orientativa - Análise dos resultados'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Confirma a 3ª Orientativa?','3er Orientativa - Confirma a 3er Orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - A causa do problema está relacionada a qual fator?','3er Orientativa - A causa do problema está relacionada a qual fator?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Objetivo','3er Orientativa - Objetivo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Situação atual','3er Orientativa - Situação atual'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Meta planejada','3er Orientativa - Meta planejada'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Prazo para execução da solução','3er Orientativa - Prazo para execução da solução'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - É necessário investimento?','3er Orientativa - É necessário investimento?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Valor do investimento','3er Orientativa - Valor do investimento'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','1ª Classificatória','1ra Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Classificatória','2da Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Semifinal','Semifinal'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Final','Final'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Categoria','Categoria'); ?></th>
                    </tr>
                </thead>                
                <tbody>
                    <!-- https://datatables.net/examples/data_sources/js_array -->
                        <?php
                        $args = array(
                            'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
                            'post_status' => 'publish',
                            'posts_per_page' => -1
                        );

                        $posts = get_posts($args);

                        if($posts) {                            

                            foreach($posts as $post) {

                              // Início da linha do integrante
                                  echo '<tr>';

                                    $orientador_id = get_post_meta( $post->ID, 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
                                    $categoria_grupo = get_post_meta($post->ID,'categorias_grupos_infos_orientador' . $ano . '_' . 'hsa',true);
                                    $orientador_camiseta = get_post_meta( $post->ID, 'grupos_infos_orientador_camiseta_' . $ano . '_' . $user_empresa, true );
                                    $orientador = get_user_meta($orientador_id, 'first_name', true);
                                    if($user_empresa == 'hsa') { $orientador = get_post_meta( $post->ID, 'temp_grupos_infos_orientador_' . $ano . '_' . $user_empresa, true ); }
                                    $orientador_turno = get_user_meta($orientador_id, 'user_infos_turno', true);
                                    
                                    $orientador_matricula_get = get_user_by( 'id', $orientador_id );
                                  // Matricula do orientador
                                    $orientador_matricula = $orientador_matricula_get->user_login;

                                    $integrantes = get_post_meta( $post->ID, 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
                                    $integrantes_qtd = array();                                  

                                  // Id do coordenador
                                    $coordenador_id = get_post_field( 'post_author', get_the_ID() );
                                    $coordenador_matricula_get = get_user_by( 'id', $coordenador_id );
                                  
                                  // Matricula do coordenador
                                    $coordenador_matricula = $coordenador_matricula_get->user_login;
                                    $coordenador = get_user_meta($coordenador_id, 'first_name', true);
                                    $coordenador_turno = get_user_meta($coordenador_id, 'user_infos_turno', true);

                                  
                                  // Quantidade de confirmados
                                    $confirmados = get_post_meta( $post->ID, 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );
                                  // Transforma em array
                                    $confirmados_array = explode(" ", $confirmados);

                                  // Removes all NULL, FALSE and Empty Strings but leaves 0 (zero) values
                                  // Essa limpeza ocorre porque o primeiro/último espaço (caso exista) estava sendo contado
                                    $confirmados_array = array_filter( $confirmados_array, 'strlen' );

                                  // Confirmação de orientativas
                                    $confirma_1_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
                                    if (empty($confirma_1_orientativa)) {
                                      $confirma_1_orientativa = apply_filters('str_from_lang','Pendente','Pendiente');
                                    }
                                    else if ($confirma_1_orientativa == 'Sim') {
                                      $confirma_1_orientativa = apply_filters('str_from_lang','Sim','Sí');
                                    }
                                    else if ($confirma_1_orientativa == 'Não') {
                                      $confirma_1_orientativa = apply_filters('str_from_lang','Não','No');
                                    }

                                    $confirma_2_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
                                    if (empty($confirma_2_orientativa)) {
                                      $confirma_2_orientativa = apply_filters('str_from_lang','Pendente','Pendiente');
                                    }
                                    else if ($confirma_2_orientativa == 'Sim') {
                                      $confirma_2_orientativa = apply_filters('str_from_lang','Sim','Sí');
                                    }
                                    else if ($confirma_2_orientativa == 'Não') {
                                      $confirma_2_orientativa = apply_filters('str_from_lang','Não','No');
                                    }

                                    $confirma_3_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true ); 
                                    if (empty($confirma_3_orientativa)) {
                                      $confirma_3_orientativa = apply_filters('str_from_lang','Pendente','Pendiente');
                                    }
                                    else if ($confirma_3_orientativa == 'Sim') {
                                      $confirma_3_orientativa = apply_filters('str_from_lang','Sim','Sí');
                                    }
                                    else if ($confirma_3_orientativa == 'Não') {
                                      $confirma_3_orientativa = apply_filters('str_from_lang','Não','No');
                                    }

                                  // Classificatorias
                                    $classificatorias = get_post_meta($post->ID,'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true);
                                    if(empty($classificatorias)) {
                                      $classificatorias = array();
                                    }
                                  // Fim classificatorias

                                  echo '<td class="noExl"><a id="ver" href="'.admin_url('post.php?post='.$post->ID.'&action=edit').'">'.apply_filters('str_from_lang','Ver grupo','Ver grupo').'</a></td>';
                                  echo '<td>' .strtoupper(get_user_meta($coordenador_id,'user_infos_empresas', true)). '</td>';
                                  echo '<td>' .get_the_title(). '</td>';
                                  $TurmaConfirmados = get_post_meta( $post->ID, 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );
                                  echo '<td class="center">';
                                  if($TurmaConfirmados != '') {
                                    echo $TurmaConfirmados;
                                  }
                                  else { echo '--'; };
                                  echo '</td>';
                                  echo '<td>' .$coordenador.'</td>';
                                  echo '<td class="center">'. $coordenador_matricula . '</td>';
                                  echo '<td class="center">'.$coordenador_turno .'</td>';
                                  echo '<td>'. mb_strimwidth($orientador, 0, 50, "...").'</td>';
                                  
                                  echo '<td class="center">'. $orientador_matricula.'</td>';
                                  echo'<td class="center">'.$orientador_turno.'</td>';
                                  echo'<td class="center">'.$orientador_camiseta.'</td>';
                                  echo '<td class="center">';
                                      // Gera array dos nomes dos integrantes
                                      $integrante_nome = array();
                                      foreach((array) $integrantes as $key => $entry ){
                                        // Adiciona todos os IDs no array para a contagem
                                        $id = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                        $integrante_nome[] = $id;
                                      }
                                      // Exibe a contagem
                                      echo count($integrante_nome);
                                      echo '</td>';
                                  

                                  echo '<td class="center">';
                                  if(!empty($confirmados)) {
                                    // Exibe a contagem de confirmados
                                    echo count($confirmados_array);
                                  }
                                  else {
                                    echo '0';
                                  }                                  
                                  echo '</td>';
                                  echo '<td class="center">'.$confirma_1_orientativa.'</td>';
                                  echo '<td class="center">'.$confirma_2_orientativa.'</td>';
                                  echo '<td class="center">'.$confirma_3_orientativa.'</td>';

                                  // Loop Função
                                  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );
                                  // print_r($terms);
                                
                                  
                                  //////// 1º Integrante ////////
                                    $integrante_1_id = $integrantes[0]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_1_funcao = $integrantes[0]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_1_camisa = $integrantes[0]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_1_nome = get_user_meta($integrante_1_id, 'first_name', true);
                                    $integrante_1_setor = get_user_meta($integrante_1_id, 'user_infos_setores', true);
                                    $integrante_1_turno = get_user_meta($integrante_1_id, 'user_infos_turno', true);
                                    $integrante_1_get = get_user_by( 'id', $integrante_1_id );
                                    

                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_1_nome) {
                                        echo $integrante_1_nome ;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                      $integrante_1_matricula = $integrante_1_get->user_login;
                                      if($integrante_1_matricula) {
                                        echo $integrante_1_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Funçãoa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_funcao) {
                                        echo $integrante_1_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_setor) {
                                        echo $integrante_1_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_turno) {
                                        echo $integrante_1_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_camisa) {
                                        echo $integrante_1_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 1º Integrante ////////

                                  //////// 2º Integrante ////////
                                    $integrante_2_id = $integrantes[1]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_2_funcao = $integrantes[1]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_2_camisa = $integrantes[1]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_2_nome = get_user_meta($integrante_2_id, 'first_name', true);
                                    $integrante_2_setor = get_user_meta($integrante_2_id, 'user_infos_setores', true);
                                    $integrante_2_turno = get_user_meta($integrante_2_id, 'user_infos_turno', true);
                                    $integrante_2_get = get_user_by( 'id', $integrante_2_id );
                                    
                                  
                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_2_nome) {
                                        echo $integrante_2_nome;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  
                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                      $integrante_2_matricula = $integrante_2_get->user_login;
                                      if($integrante_2_matricula) {
                                        echo $integrante_2_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Função do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_funcao) {
                                        echo $integrante_2_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';
                                    
                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_setor) {
                                        echo $integrante_2_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_turno) {
                                        echo $integrante_2_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_camisa) {
                                        echo $integrante_2_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 2º Integrante ////////

                                  //////// 3º Integrante ////////
                                    $integrante_3_id = $integrantes[2]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_3_funcao = $integrantes[2]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_3_camisa = $integrantes[2]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_3_nome = get_user_meta($integrante_3_id, 'first_name', true);
                                    $integrante_3_setor = get_user_meta($integrante_3_id, 'user_infos_setores', true);
                                    $integrante_3_turno = get_user_meta($integrante_3_id, 'user_infos_turno', true);
                                    $integrante_3_get = get_user_by( 'id', $integrante_3_id );
                                    
                                  
                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_3_nome) {
                                        echo $integrante_3_nome;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  
                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                       $integrante_3_matricula = $integrante_3_get->user_login;
                                      if($integrante_3_matricula) {
                                        echo $integrante_3_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';
                                    
                                    // função do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_funcao) {
                                        echo $integrante_3_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';
                                    
                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_setor) {
                                        echo $integrante_3_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_turno) {
                                        echo $integrante_3_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_camisa) {
                                        echo $integrante_3_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 3º Integrante ////////

                                  
                                  //////// 4º Integrante ////////
                                    $integrante_4_id = $integrantes[3]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_4_funcao = $integrantes[3]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_4_camisa = $integrantes[3]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_4_nome = get_user_meta($integrante_4_id, 'first_name', true);
                                    $integrante_4_setor = get_user_meta($integrante_4_id, 'user_infos_setores', true);
                                    $integrante_4_turno = get_user_meta($integrante_4_id, 'user_infos_turno', true);
                                    $integrante_4_get = get_user_by( 'id', $integrante_4_id );
                                    

                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_4_nome) {
                                        echo $integrante_4_nome;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                        $integrante_4_matricula = $integrante_4_get->user_login;
                                        if($integrante_4_matricula) {
                                          echo $integrante_4_matricula;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Função do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_funcao) {
                                          echo $integrante_4_funcao;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Setor do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_setor) {
                                          echo $integrante_4_setor;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_turno) {
                                          echo $integrante_4_turno;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_camisa) {
                                          echo $integrante_4_camisa;
                                        }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 4º Integrante ////////
                                  
                                  //////// 5º Integrante ////////
                                    $integrante_5_id = $integrantes[4]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_5_funcao = $integrantes[4]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_5_camisa = $integrantes[4]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_5_nome = get_user_meta($integrante_5_id, 'first_name', true);
                                    $integrante_5_setor = get_user_meta($integrante_5_id, 'user_infos_setores', true);
                                    $integrante_5_turno = get_user_meta($integrante_5_id, 'user_infos_turno', true);
                                    $integrante_5_get = get_user_by( 'id', $integrante_5_id );
                                  
                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_5_nome) {
                                        echo $integrante_5_nome ;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                    $integrante_5_matricula = $integrante_5_get->user_login;
                                      if($integrante_5_matricula) {
                                        echo $integrante_5_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Função do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_funcao) {
                                        echo $integrante_5_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_setor) {
                                        echo $integrante_5_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_turno) {
                                        echo $integrante_5_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_camisa) {
                                        echo $integrante_5_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 5º Integrante ////////

                                  /////// 1ª Orientativa  /////////
                                    $ConfirmaA1Orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ConfirmaA1Orientativa != '') {
                                      echo $ConfirmaA1Orientativa;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  /////// Fim 1ª Orientativa  /////////

                                  /////// 2ª Orientativa  /////////
                                    $ConfirmaA2Orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ConfirmaA2Orientativa != '') {
                                      echo $ConfirmaA2Orientativa;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $TurnoDoApresentador = get_post_meta( $post->ID, 'grupos_infos_2_orientativa_turno_apresentador_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($TurnoDoApresentador != '') {
                                      echo $TurnoDoApresentador;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $Tema= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_tema_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($Tema != '') {
                                      echo $Tema;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $Categoria= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_categoria_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($Categoria != '') {
                                      echo $Categoria;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $AnaliseDeSituacao= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_analise_situacao_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($AnaliseDeSituacao != '') {
                                      echo $AnaliseDeSituacao;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $AnaliseDeCausas = get_post_meta( $post->ID, 'grupos_infos_2_orientativa_analise_causas_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($AnaliseDeCausas != '') {
                                      echo $AnaliseDeCausas;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $ObjetivosMetas= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_obj_metas_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ObjetivosMetas != '') {
                                      echo $ObjetivosMetas;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $EstudosImplantacao= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_est_imp_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($EstudosImplantacao != '') {
                                      echo $EstudosImplantacao;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $AnaliseDosResultados = get_post_meta( $post->ID, 'grupos_infos_2_orientativa_analise_result_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($AnaliseDosResultados != '') {
                                      echo $AnaliseDosResultados;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                  /////// Fim 2ª Orientativa  /////////
                                      
                                  /////// 3ª Orientativa  /////////
                                    $ConfirmaA3Orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ConfirmaA3Orientativa != '') {
                                      echo $ConfirmaA3Orientativa;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                    
                                    $CausaProblema = get_post_meta( $post->ID, 'grupos_infos_3_orientativa_fator_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($CausaProblema != '') {
                                      echo $CausaProblema;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $Objetivo= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_objetivo_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($Objetivo != '') {
                                      echo $Objetivo;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $SituacaoAtual= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_situacao_atual_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($SituacaoAtual != '') {
                                      echo $SituacaoAtual;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $MetaPlanejada= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_meta_planejada_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($MetaPlanejada != '') {
                                      echo $MetaPlanejada;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $PrazoExecucaoSolucao = get_post_meta( $post->ID, 'grupos_infos_3_orientativa_prazo_execucao_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($PrazoExecucaoSolucao != '') {
                                      echo $PrazoExecucaoSolucao;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $NecessarioInvestimento= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_investimento_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($NecessarioInvestimento != '') {
                                      echo $NecessarioInvestimento;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $ValorDoInvestimento= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_investimento_valor_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ValorDoInvestimento != '') {
                                      echo $ValorDoInvestimento;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  /////// Fim 3ª Orientativa  /////////

                                  //////// 1ª classificatória ////////
                                    echo '<td>';
                                    if(in_array('1ª Classificatória',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Fim 1ª classificatória ////////

                                  //////// 2ª classificatória ////////
                                    echo '<td>';
                                    if(in_array('2ª Classificatória',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Fim 2ª classificatória ////////

                                  //////// Semifinal ////////
                                    echo '<td>';
                                    if(in_array('Semifinal',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Semifinal ////////

                                  //////// Final ////////
                                    echo '<td>';
                                    if(in_array('Final',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Final ////////
                              // Fim da linha do integrante    
                              echo '<td>'.$categoria_grupo.'</td>';                          
                              echo '</tr>';                              

                            }                            

                        }

                        ?>
                </tbody>
                <tfoot>
                    <tr class="noExl">
                        <th><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Empresa','Empresa'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmados','Confirmados'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Nome','Coordinador(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Matrícula','Coordinador(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Turno','Coordinador(a): Turno'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Nome','Tutor(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Matrícula','Tutor(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Turno','Tutor(a): Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Camiseta','Tutor(a): Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Qtd. de integrantes do grupo','Cant. de miembros del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Qtd. de confirmados','Cant. de confirmados'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 1ª orientativa?','¿Confirmó la 1ra orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 2ª orientativa?','¿Confirmó la 2da orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a ' . $_orientativa_3_texto,'¿Confirmó la 3ra orientación?'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Nome','1er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Matrícula','1er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Função','1er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Setor','1er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Turno','1er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Camiseta','1er Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Nome','2do Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Matrícula','2do Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Função','2do Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Setor','2do Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Turno','2do Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Camiseta','2dc Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Nome','3er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Matrícula','3er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Função','3er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Setor','3er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Turno','3er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Camiseta','3er Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Nome','4to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Matrícula','4to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Função','4to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Setor','4to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Turno','4to Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Camiseta','4to Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Nome','5to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Matrícula','5to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Função','5to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Setor','5to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Turno','5to Integrante: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Camiseta','5to Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1ª Orientativa - Confirma a 1ª orientativa?','1ra Orientativa - Confirma a 1ra orientativa?'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Confirma a 2ª orientativa?','2do Orientativa - Confirma a 2do orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Turno do apresentador','2do Orientativa - Turno do apresentador'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Tema','2do Orientativa - Tema'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Categoria','2do Orientativa - Categoria'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de situação','2do Orientativa - Análise de situação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de causas','2do Orientativa - Análise de causas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Objetivos e metas','2do Orientativa - Objetivos e metas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Estudos e implantação','2do Orientativa - Estudos e implantação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise dos resultados','2do Orientativa - Análise dos resultados'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Confirma a 3ª Orientativa?','3er Orientativa - Confirma a 3er Orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - A causa do problema está relacionada a qual fator?','3er Orientativa - A causa do problema está relacionada a qual fator?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Objetivo','3er Orientativa - Objetivo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Situação atual','3er Orientativa - Situação atual'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Meta planejada','3er Orientativa - Meta planejada'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Prazo para execução da solução','3er Orientativa - Prazo para execução da solução'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - É necessário investimento?','3er Orientativa - É necessário investimento?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Valor do investimento','3er Orientativa - Valor do investimento'); ?></th>
                         
                        <th><?php echo apply_filters('str_from_lang','1ª Classificatória','1ra Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Classificatória','2da Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Semifinal','Semifinal'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Final','Final'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Categoria','Categoria'); ?></th>
                    </tr>
                </tfoot>
              </table>              
            </div>


              <table id="tabelaresultados2" class="display" name="resultados" style="display: none;">
              <thead>
                    <tr>
                        <th class="noExl"><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Empresa','Empresa'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmados','Confirmado'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Nome','Coordinador(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Matrícula','Coordinador(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Turno','Coordinador(a): Turno'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Nome','Tutor(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Matrícula','Tutor(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Turno','Tutor(a): Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Camiseta','Tutor(a): Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Qtd. de integrantes do grupo','Cant. de miembros del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Qtd. de confirmados','Cant. de confirmados'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 1ª orientativa?','¿Confirmó la 1ra orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 2ª orientativa?','¿Confirmó la 2da orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a ' . $_orientativa_3_texto,'¿Confirmó la 3ra orientación?'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Nome','1er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Matrícula','1er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Função','1er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Setor','1er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Turno','1er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Camiseta','1er Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Nome','2do Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Matrícula','2do Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Função','2do Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Setor','2do Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Turno','2do Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Camiseta','2do Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Nome','3er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Matrícula','3er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Função','3er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Setor','3er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Turno','3er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Camiseta','3er Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Nome','4to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Matrícula','4to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Função','4to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Setor','4to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Turno','4to Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Camiseta','4to Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Nome','5to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Matrícula','5to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Função','5to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Setor','5to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Turno','5to Integrante: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Camiseta','5to Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1ª Orientativa - Confirma a 1ª orientativa?','1ra Orientativa - Confirma a 1ra orientativa?'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Confirma a 2ª orientativa?','2do Orientativa - Confirma a 2do orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Turno do apresentador','2do Orientativa - Turno do apresentador'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Tema','2do Orientativa - Tema'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Categoria','2do Orientativa - Categoria'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de situação','2do Orientativa - Análise de situação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de causas','2do Orientativa - Análise de causas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Objetivos e metas','2do Orientativa - Objetivos e metas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Estudos e implantação','2do Orientativa - Estudos e implantação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise dos resultados','2do Orientativa - Análise dos resultados'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Confirma a 3ª Orientativa?','3er Orientativa - Confirma a 3er Orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - A causa do problema está relacionada a qual fator?','3er Orientativa - A causa do problema está relacionada a qual fator?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Objetivo','3er Orientativa - Objetivo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Situação atual','3er Orientativa - Situação atual'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Meta planejada','3er Orientativa - Meta planejada'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Prazo para execução da solução','3er Orientativa - Prazo para execução da solução'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - É necessário investimento?','3er Orientativa - É necessário investimento?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Valor do investimento','3er Orientativa - Valor do investimento'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','1ª Classificatória','1ra Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Classificatória','2da Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Semifinal','Semifinal'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Final','Final'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Categoria','Categoria'); ?></th>
                    </tr>
                </thead>                
                <tbody>
                    <!-- https://datatables.net/examples/data_sources/js_array -->
                        <?php
                        $args = array(
                            'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
                            'post_status' => 'publish',
                            'posts_per_page' => -1
                        );

                        $posts = get_posts($args);

                        if($posts) {                            

                            foreach($posts as $post) {

                              // Início da linha do integrante
                                  echo '<tr>';

                                    $orientador_id = get_post_meta( $post->ID, 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
                                    $orientador_camiseta = get_post_meta( $post->ID, 'grupos_infos_orientador_camiseta_' . $ano . '_' . $user_empresa, true );
                                    $orientador = get_user_meta($orientador_id, 'first_name', true);
                                    if($user_empresa == 'hsa') { $orientador = get_post_meta( $post->ID, 'temp_grupos_infos_orientador_' . $ano . '_' . $user_empresa, true ); }
                                    $orientador_turno = get_user_meta($orientador_id, 'user_infos_turno', true);
                                    $categoria_grupo = get_post_meta($post->ID,'categorias_grupos_infos_orientador' . $ano . '_' . 'hsa',true);
                                    
                                    $orientador_matricula_get = get_user_by( 'id', $orientador_id );
                                  // Matricula do orientador
                                    $orientador_matricula = $orientador_matricula_get->user_login;

                                    $integrantes = get_post_meta( $post->ID, 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
                                    $integrantes_qtd = array();                                  

                                  // Id do coordenador
                                    $coordenador_id = get_post_field( 'post_author', get_the_ID() );
                                    $coordenador_matricula_get = get_user_by( 'id', $coordenador_id );
                                  
                                  // Matricula do coordenador
                                    $coordenador_matricula = $coordenador_matricula_get->user_login;
                                    $coordenador = get_user_meta($coordenador_id, 'first_name', true);
                                    $coordenador_turno = get_user_meta($coordenador_id, 'user_infos_turno', true);

                                  
                                  // Quantidade de confirmados
                                    $confirmados = get_post_meta( $post->ID, 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );
                                  // Transforma em array
                                    $confirmados_array = explode(" ", $confirmados);

                                  // Removes all NULL, FALSE and Empty Strings but leaves 0 (zero) values
                                  // Essa limpeza ocorre porque o primeiro/último espaço (caso exista) estava sendo contado
                                    $confirmados_array = array_filter( $confirmados_array, 'strlen' );

                                  // Confirmação de orientativas
                                    $confirma_1_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
                                    if (empty($confirma_1_orientativa)) {
                                      $confirma_1_orientativa = apply_filters('str_from_lang','Pendente','Pendiente');
                                    }
                                    else if ($confirma_1_orientativa == 'Sim') {
                                      $confirma_1_orientativa = apply_filters('str_from_lang','Sim','Sí');
                                    }
                                    else if ($confirma_1_orientativa == 'Não') {
                                      $confirma_1_orientativa = apply_filters('str_from_lang','Não','No');
                                    }

                                    $confirma_2_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
                                    if (empty($confirma_2_orientativa)) {
                                      $confirma_2_orientativa = apply_filters('str_from_lang','Pendente','Pendiente');
                                    }
                                    else if ($confirma_2_orientativa == 'Sim') {
                                      $confirma_2_orientativa = apply_filters('str_from_lang','Sim','Sí');
                                    }
                                    else if ($confirma_2_orientativa == 'Não') {
                                      $confirma_2_orientativa = apply_filters('str_from_lang','Não','No');
                                    }

                                    $confirma_3_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true ); 
                                    if (empty($confirma_3_orientativa)) {
                                      $confirma_3_orientativa = apply_filters('str_from_lang','Pendente','Pendiente');
                                    }
                                    else if ($confirma_3_orientativa == 'Sim') {
                                      $confirma_3_orientativa = apply_filters('str_from_lang','Sim','Sí');
                                    }
                                    else if ($confirma_3_orientativa == 'Não') {
                                      $confirma_3_orientativa = apply_filters('str_from_lang','Não','No');
                                    }

                                  // Classificatorias
                                    $classificatorias = get_post_meta($post->ID,'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true);
                                    if(empty($classificatorias)) {
                                      $classificatorias = array();
                                    }
                                  // Fim classificatorias

                                  echo '<td class="noExl"><a id="ver" href="'.admin_url('post.php?post='.$post->ID.'&action=edit').'">'.apply_filters('str_from_lang','Ver grupo','Ver grupo').'</a></td>';
                                  echo '<td>' .strtoupper(get_user_meta($coordenador_id,'user_infos_empresas', true)). '</td>';
                                  echo '<td>' .get_the_title(). '</td>';
                                  $TurmaConfirmados = get_post_meta( $post->ID, 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );
                                  echo '<td class="center">';
                                  if($TurmaConfirmados != '') {
                                    echo $TurmaConfirmados;
                                  }
                                  else { echo '--'; };
                                  echo '</td>';
                                  echo '<td>' .$coordenador.'</td>';
                                  echo '<td class="center">'. $coordenador_matricula . '</td>';
                                  echo '<td class="center">'.$coordenador_turno .'</td>';
                                  echo '<td>'. mb_strimwidth($orientador, 0, 50, "...").'</td>';
                                  
                                  echo '<td class="center">'. $orientador_matricula.'</td>';
                                  echo'<td class="center">'.$orientador_turno.'</td>';
                                  echo'<td class="center">'.$orientador_camiseta.'</td>';
                                  echo '<td class="center">';
                                      // Gera array dos nomes dos integrantes
                                      $integrante_nome = array();
                                      foreach((array) $integrantes as $key => $entry ){
                                        // Adiciona todos os IDs no array para a contagem
                                        $id = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                        $integrante_nome[] = $id;
                                      }
                                      // Exibe a contagem
                                      echo count($integrante_nome);
                                      echo '</td>';
                                  

                                  echo '<td class="center">';
                                  if(!empty($confirmados)) {
                                    // Exibe a contagem de confirmados
                                    echo count($confirmados_array);
                                  }
                                  else {
                                    echo '0';
                                  }                                  
                                  echo '</td>';
                                  echo '<td class="center">'.$confirma_1_orientativa.'</td>';
                                  echo '<td class="center">'.$confirma_2_orientativa.'</td>';
                                  echo '<td class="center">'.$confirma_3_orientativa.'</td>';

                                  // Loop Função
                                  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );
                                  // print_r($terms);
                                
                                  
                                  //////// 1º Integrante ////////
                                    $integrante_1_id = $integrantes[0]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_1_funcao = $integrantes[0]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_1_camisa = $integrantes[0]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_1_nome = get_user_meta($integrante_1_id, 'first_name', true);
                                    $integrante_1_setor = get_user_meta($integrante_1_id, 'user_infos_setores', true);
                                    $integrante_1_turno = get_user_meta($integrante_1_id, 'user_infos_turno', true);
                                    $integrante_1_get = get_user_by( 'id', $integrante_1_id );
                                    

                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_1_nome) {
                                        echo $integrante_1_nome ;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                      $integrante_1_matricula = $integrante_1_get->user_login;
                                      if($integrante_1_matricula) {
                                        echo $integrante_1_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Funçãoa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_funcao) {
                                        echo $integrante_1_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_setor) {
                                        echo $integrante_1_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_turno) {
                                        echo $integrante_1_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_1_camisa) {
                                        echo $integrante_1_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 1º Integrante ////////

                                  //////// 2º Integrante ////////
                                    $integrante_2_id = $integrantes[1]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_2_funcao = $integrantes[1]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_2_camisa = $integrantes[1]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_2_nome = get_user_meta($integrante_2_id, 'first_name', true);
                                    $integrante_2_setor = get_user_meta($integrante_2_id, 'user_infos_setores', true);
                                    $integrante_2_turno = get_user_meta($integrante_2_id, 'user_infos_turno', true);
                                    $integrante_2_get = get_user_by( 'id', $integrante_2_id );
                                    
                                  
                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_2_nome) {
                                        echo $integrante_2_nome;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  
                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                      $integrante_2_matricula = $integrante_2_get->user_login;
                                      if($integrante_2_matricula) {
                                        echo $integrante_2_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Função do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_funcao) {
                                        echo $integrante_2_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';
                                    
                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_setor) {
                                        echo $integrante_2_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_turno) {
                                        echo $integrante_2_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_2_camisa) {
                                        echo $integrante_2_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 2º Integrante ////////

                                  //////// 3º Integrante ////////
                                    $integrante_3_id = $integrantes[2]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_3_funcao = $integrantes[2]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_3_camisa = $integrantes[2]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_3_nome = get_user_meta($integrante_3_id, 'first_name', true);
                                    $integrante_3_setor = get_user_meta($integrante_3_id, 'user_infos_setores', true);
                                    $integrante_3_turno = get_user_meta($integrante_3_id, 'user_infos_turno', true);
                                    $integrante_3_get = get_user_by( 'id', $integrante_3_id );
                                    
                                  
                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_3_nome) {
                                        echo $integrante_3_nome;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  
                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                       $integrante_3_matricula = $integrante_3_get->user_login;
                                      if($integrante_3_matricula) {
                                        echo $integrante_3_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';
                                    
                                    // função do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_funcao) {
                                        echo $integrante_3_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';
                                    
                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_setor) {
                                        echo $integrante_3_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_turno) {
                                        echo $integrante_3_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_3_camisa) {
                                        echo $integrante_3_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 3º Integrante ////////

                                  
                                  //////// 4º Integrante ////////
                                    $integrante_4_id = $integrantes[3]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_4_funcao = $integrantes[3]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_4_camisa = $integrantes[3]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_4_nome = get_user_meta($integrante_4_id, 'first_name', true);
                                    $integrante_4_setor = get_user_meta($integrante_4_id, 'user_infos_setores', true);
                                    $integrante_4_turno = get_user_meta($integrante_4_id, 'user_infos_turno', true);
                                    $integrante_4_get = get_user_by( 'id', $integrante_4_id );
                                    

                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_4_nome) {
                                        echo $integrante_4_nome;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                        $integrante_4_matricula = $integrante_4_get->user_login;
                                        if($integrante_4_matricula) {
                                          echo $integrante_4_matricula;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Função do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_funcao) {
                                          echo $integrante_4_funcao;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Setor do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_setor) {
                                          echo $integrante_4_setor;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_turno) {
                                          echo $integrante_4_turno;
                                        }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                        if($integrante_4_camisa) {
                                          echo $integrante_4_camisa;
                                        }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 4º Integrante ////////
                                  
                                  //////// 5º Integrante ////////
                                    $integrante_5_id = $integrantes[4]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                                    $integrante_5_funcao = $integrantes[4]['grupos_integrantes_funcao_' . $ano . '_' . $user_empresa];
                                    $integrante_5_camisa = $integrantes[4]['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];
                                    $integrante_5_nome = get_user_meta($integrante_5_id, 'first_name', true);
                                    $integrante_5_setor = get_user_meta($integrante_5_id, 'user_infos_setores', true);
                                    $integrante_5_turno = get_user_meta($integrante_5_id, 'user_infos_turno', true);
                                    $integrante_5_get = get_user_by( 'id', $integrante_5_id );
                                  
                                    // Nome do integrante
                                    echo '<td>';
                                      if($integrante_5_nome) {
                                        echo $integrante_5_nome ;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Matricula do integrante
                                    echo '<td  class="center">';
                                    $integrante_5_matricula = $integrante_5_get->user_login;
                                      if($integrante_5_matricula) {
                                        echo $integrante_5_matricula;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Função do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_funcao) {
                                        echo $integrante_5_funcao;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Setor do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_setor) {
                                        echo $integrante_5_setor;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Turno do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_turno) {
                                        echo $integrante_5_turno;
                                      }else { echo '--'; }
                                    echo '</td>';

                                    // Camisa do integrante
                                    echo '<td  class="center">';
                                      if($integrante_5_camisa) {
                                        echo $integrante_5_camisa;
                                      }else { echo '--'; }
                                    echo '</td>';
                                  //////// Fim 5º Integrante ////////

                                  /////// 1ª Orientativa  /////////
                                    $ConfirmaA1Orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ConfirmaA1Orientativa != '') {
                                      echo $ConfirmaA1Orientativa;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  /////// Fim 1ª Orientativa  /////////

                                  /////// 2ª Orientativa  /////////
                                    $ConfirmaA2Orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ConfirmaA2Orientativa != '') {
                                      echo $ConfirmaA2Orientativa;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $TurnoDoApresentador = get_post_meta( $post->ID, 'grupos_infos_2_orientativa_turno_apresentador_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($TurnoDoApresentador != '') {
                                      echo $TurnoDoApresentador;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $Tema= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_tema_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($Tema != '') {
                                      echo $Tema;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $Categoria= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_categoria_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($Categoria != '') {
                                      echo $Categoria;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $AnaliseDeSituacao= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_analise_situacao_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($AnaliseDeSituacao != '') {
                                      echo $AnaliseDeSituacao;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $AnaliseDeCausas = get_post_meta( $post->ID, 'grupos_infos_2_orientativa_analise_causas_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($AnaliseDeCausas != '') {
                                      echo $AnaliseDeCausas;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $ObjetivosMetas= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_obj_metas_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ObjetivosMetas != '') {
                                      echo $ObjetivosMetas;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $EstudosImplantacao= get_post_meta( $post->ID, 'grupos_infos_2_orientativa_est_imp_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($EstudosImplantacao != '') {
                                      echo $EstudosImplantacao;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $AnaliseDosResultados = get_post_meta( $post->ID, 'grupos_infos_2_orientativa_analise_result_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($AnaliseDosResultados != '') {
                                      echo $AnaliseDosResultados;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                  /////// Fim 2ª Orientativa  /////////
                                      
                                  /////// 3ª Orientativa  /////////
                                    $ConfirmaA3Orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ConfirmaA3Orientativa != '') {
                                      echo $ConfirmaA3Orientativa;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                    
                                    $CausaProblema = get_post_meta( $post->ID, 'grupos_infos_3_orientativa_fator_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($CausaProblema != '') {
                                      echo $CausaProblema;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $Objetivo= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_objetivo_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($Objetivo != '') {
                                      echo $Objetivo;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $SituacaoAtual= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_situacao_atual_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($SituacaoAtual != '') {
                                      echo $SituacaoAtual;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $MetaPlanejada= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_meta_planejada_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($MetaPlanejada != '') {
                                      echo $MetaPlanejada;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $PrazoExecucaoSolucao = get_post_meta( $post->ID, 'grupos_infos_3_orientativa_prazo_execucao_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($PrazoExecucaoSolucao != '') {
                                      echo $PrazoExecucaoSolucao;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $NecessarioInvestimento= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_investimento_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($NecessarioInvestimento != '') {
                                      echo $NecessarioInvestimento;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';

                                    $ValorDoInvestimento= get_post_meta( $post->ID, 'grupos_infos_3_orientativa_investimento_valor_' . $ano . '_' . $user_empresa, true );
                                    echo '<td class="center">';
                                    if($ValorDoInvestimento != '') {
                                      echo $ValorDoInvestimento;
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  /////// Fim 3ª Orientativa  /////////

                                  //////// 1ª classificatória ////////
                                    echo '<td>';
                                    if(in_array('1ª Classificatória',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Fim 1ª classificatória ////////

                                  //////// 2ª classificatória ////////
                                    echo '<td>';
                                    if(in_array('2ª Classificatória',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Fim 2ª classificatória ////////

                                  //////// Semifinal ////////
                                    echo '<td>';
                                    if(in_array('Semifinal',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                  //////// Semifinal ////////

                                  //////// Final ////////
                                    echo '<td>';
                                    if(in_array('Final',$classificatorias)) {
                                      echo apply_filters('str_from_lang','Aprovado','Aprobado');
                                    }
                                    else { echo '--'; };
                                    echo '</td>';
                                    echo '<td>'.$categoria_grupo.'</td>';     
                                  //////// Final ////////
                              // Fim da linha do integrante                              
                              echo '</tr>';                              

                            }                            

                        }

                        ?>
                </tbody>
                <tfoot>
                    <tr class="noExl">
                        <th><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Empresa','Empresa'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmados','Confirmados'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Nome','Coordinador(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Matrícula','Coordinador(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Coordenador(a): Turno','Coordinador(a): Turno'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Nome','Tutor(a): Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Matrícula','Tutor(a): Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Turno','Tutor(a): Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Orientador(a): Camiseta','Tutor(a): Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','Qtd. de integrantes do grupo','Cant. de miembros del grupo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Qtd. de confirmados','Cant. de confirmados'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 1ª orientativa?','¿Confirmó la 1ra orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a 2ª orientativa?','¿Confirmó la 2da orientación?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Confirmou a ' . $_orientativa_3_texto,'¿Confirmó la 3ra orientación?'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Nome','1er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Matrícula','1er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Função','1er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Setor','1er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Turno','1er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','1º Integrante: Camiseta','1er Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Nome','2do Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Matrícula','2do Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Função','2do Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Setor','2do Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Turno','2do Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2º Integrante: Camiseta','2dc Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Nome','3er Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Matrícula','3er Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Função','3er Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Setor','3er Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Turno','3er Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3º Integrante: Camiseta','3er Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Nome','4to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Matrícula','4to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Função','4to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Setor','4to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Turno','4to Miembro: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','4º Integrante: Camiseta','4to Miembro: Camiseta'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Nome','5to Miembro: Nombre'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Matrícula','5to Miembro: Matricula'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Função','5to Miembro: '); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Setor','5to Miembro: Sector'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Turno','5to Integrante: Turno'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','5º Integrante: Camiseta','5to Miembro: Camiseta'); ?></th>
                        
                        <th><?php echo apply_filters('str_from_lang','1ª Orientativa - Confirma a 1ª orientativa?','1ra Orientativa - Confirma a 1ra orientativa?'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Confirma a 2ª orientativa?','2do Orientativa - Confirma a 2do orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Turno do apresentador','2do Orientativa - Turno do apresentador'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Tema','2do Orientativa - Tema'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Categoria','2do Orientativa - Categoria'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de situação','2do Orientativa - Análise de situação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise de causas','2do Orientativa - Análise de causas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Objetivos e metas','2do Orientativa - Objetivos e metas'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Estudos e implantação','2do Orientativa - Estudos e implantação'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Orientativa - Análise dos resultados','2do Orientativa - Análise dos resultados'); ?></th>

                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Confirma a 3ª Orientativa?','3er Orientativa - Confirma a 3er Orientativa?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - A causa do problema está relacionada a qual fator?','3er Orientativa - A causa do problema está relacionada a qual fator?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Objetivo','3er Orientativa - Objetivo'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Situação atual','3er Orientativa - Situação atual'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Meta planejada','3er Orientativa - Meta planejada'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Prazo para execução da solução','3er Orientativa - Prazo para execução da solução'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - É necessário investimento?','3er Orientativa - É necessário investimento?'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','3ª Orientativa - Valor do investimento','3er Orientativa - Valor do investimento'); ?></th>
                         
                        <th><?php echo apply_filters('str_from_lang','1ª Classificatória','1ra Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','2ª Classificatória','2da Clasificación'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Semifinal','Semifinal'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Final','Final'); ?></th>
                        <th><?php echo apply_filters('str_from_lang','Categoria','Categoria'); ?></th>
                    </tr>
                </tfoot>
              </table>

            <button class="btn btn-success export-btn"><?php echo apply_filters('str_from_lang','Download em Excel','Descargar en Excel'); ?></button></div>
            

        </div>
      </div>

   

<?php get_footer(); } else { wp_redirect(home_url()); } ?>