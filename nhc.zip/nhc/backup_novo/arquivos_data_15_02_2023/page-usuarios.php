<?php

/* Template Name: Usuários */

$current_user_id = get_current_user_id();
$opcoes_gerais = get_option( 'opcoes_gerais', 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente'];
$status = $opcoes_gerais['opcoes_gerais_status'];

if(current_user_can('comissao') || current_user_can('administrator')) {

get_header(); ?>

      <div class="page<?php echo get_the_ID(); ?> page-single" id="scroll">          
        <div class="container">

           <div class="upload space-top">
              
               <?php
                echo do_shortcode('[import-users-from-csv-with-meta]');
                ?> 

           </div>

        </div>
      </div>

<?php get_footer(); } else { wp_redirect(home_url()); } ?>