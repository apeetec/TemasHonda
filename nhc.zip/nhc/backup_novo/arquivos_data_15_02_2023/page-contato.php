<?php

/* Template Name: Contato */

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$contato = $opcoes_gerais['opcoes_gerais_contato_' . $user_empresa];

get_header(); ?>

      <div class="page<?php echo get_the_ID(); ?> page-single">          
        <div class="container">

          <div class="contato space-top">
            <h1 class="main"><?php echo apply_filters('str_from_lang','Contato','Contacto'); ?></h1>

            <div id="contato">
              <?php if(!empty($contato)) { ?>
              <div id="block">
                <?php echo wpautop($contato); ?>
              </div>
              
              <?php } else { echo '<p id="none">'.apply_filters('str_from_lang','Sem informacoes de contato no momento','No hay información de contacto en el momento').'.</p>'; } ?>
            </div>
          </div>

        </div>
      </div>

<?php get_footer(); ?>