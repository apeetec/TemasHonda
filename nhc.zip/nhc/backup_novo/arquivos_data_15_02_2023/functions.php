<?php

/* Plugin Name: Increase Upload Limit */
/*add_filter( 'upload_size_limit', 'custom_upload_size' );
//https://stackoverflow.com/questions/17751779/increase-max-upload-limit-in-wordpress
function custom_upload_size( $bytes )
{
    return 125829120; // 32 megabytes
}*/

############### ADMIN BODY CLASS
add_filter( 'admin_body_class', 'my_admin_body_class' );

/**
 * Adds one or more classes to the body tag in the dashboard.
 *
 * @link https://wordpress.stackexchange.com/a/154951/17187
 * @param  String $classes Current body classes.
 * @return String          Altered body classes.
 */
function my_admin_body_class( $classes ) {
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];

    return "$classes user-empresa-$user_empresa ano-$ano";
    // Or: return "$classes my_class_1 my_class_2 my_class_3";
}
############### FIM ADMIN BODY CLASS

add_action('init','custom_login');

function custom_login(){
 global $pagenow;
 if( 'wp-login.php' == $pagenow && !is_user_logged_in()) {
  wp_redirect(home_url());
  exit();
 }
}

// Custom size - galeria
add_image_size( 'galeria_thumb', 188, 200, true );

/// CMB2
if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
  require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
  require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

$dirbase = get_template_directory();
require_once $dirbase . '/inc/functions-post-type-galerias.php';
require_once $dirbase . '/inc/functions-post-type-grupos.php';
require_once $dirbase . '/inc/functions-post-type-anos.php';
require_once $dirbase . '/inc/functions-css-todos.php';
require_once $dirbase . '/inc/functions-css-orientador.php';
require_once $dirbase . '/inc/functions-css-nao-administradores.php';
require_once $dirbase . '/inc/functions-css-comissao.php';
require_once $dirbase . '/inc/functions-nao-administradores.php';
require_once $dirbase . '/inc/functions-cmb2-users.php';
require_once $dirbase . '/inc/functions-evitar-grupos-duplicados.php';
require_once $dirbase . '/inc/functions-max-5-integrantes.php';
require_once $dirbase . '/inc/functions-setor-automatico.php';

// VALIDACAO: Pede validações de campos apenas se o usuário for DIFERENTE de:
if(!current_user_can('comissao') && !current_user_can('administrator'))  {
require_once $dirbase . '/inc/functions-validacoes-grupos.php';
}

require_once $dirbase . '/inc/functions-opcoes-gerais.php';
require_once $dirbase . '/inc/functions-funcoes-nao-admins.php';
require_once $dirbase . '/inc/functions-funcoes-comissao.php';
require_once $dirbase . '/inc/functions-funcoes-orientador.php';
// require_once $dirbase . '/inc/functions-funcoes-membro-orientador.php';
require_once $dirbase . '/inc/functions-confirma-grupo.php';
require_once $dirbase . '/inc/functions-institucional-slides.php';
require_once $dirbase . '/inc/functions-institucional-cronogramas.php';
require_once $dirbase . '/inc/functions-institucional-midias.php';
require_once $dirbase . '/inc/functions-institucional-arquivos.php';
require_once $dirbase . '/inc/functions-institucional-galerias.php';
require_once $dirbase . '/inc/functions-cmb2-grupos-1-orientativa.php';
require_once $dirbase . '/inc/functions-cmb2-grupos.php';
// require_once $dirbase . '/inc/functions-login-labels.php';
require_once $dirbase . '/inc/functions-resetar-senha.php';
require_once $dirbase . '/inc/functions-css-login.php';
require_once $dirbase . '/inc/functions-author-only-posts.php';
require_once $dirbase . '/inc/functions-esconder-user-fields.php';
// require_once $dirbase . '/inc/functions-users-sem-email.php';
require_once $dirbase . '/inc/functions-listagem-usuarios.php';
require_once $dirbase . '/inc/functions-seguranca.php';
require_once $dirbase . '/inc/functions-log-geral.php';
// require_once $dirbase . '/inc/functions-log-acao.php';
require_once $dirbase . '/inc/functions-user-empresa.php';
require_once $dirbase . '/inc/functions-user-unidade.php';
require_once $dirbase . '/inc/functions-user-setor.php';
require_once $dirbase . '/inc/functions-role-name-traducao.php';
require_once $dirbase . '/inc/functions-traducao.php';
// require_once $dirbase . '/inc/functions-disable-dragging.php';
// require_once $dirbase . '/inc/functions-evita-repeticao-de-membros.php';

/// Redireciona 404 para a Home
if( !function_exists('redirect_404_to_homepage') ){

    add_action( 'template_redirect', 'redirect_404_to_homepage' );

    function redirect_404_to_homepage(){
       if(is_404()):
            wp_safe_redirect( home_url('/') );
            exit;
        endif;
    }
}

// Add menu item for home
function add_menu_item_home() {
  // $page_title, $menu_title, $capability, $menu_slug, $callback_function
  // add_posts_page(__('Drafts'), __('Drafts'), 'read', 'edit.php?post_status=draft&post_type=post');
  add_menu_page( apply_filters('str_from_lang','Voltar para o site','Volver al sitio'), apply_filters('str_from_lang','Voltar para o site','Volver al sitio'), 'read', home_url() );
}
add_action('admin_menu', 'add_menu_item_home');

// Opções de layout mais clean do WordPress
function remove_admin_login_header() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}

add_action('get_header', 'remove_admin_login_header');
add_theme_support( 'post-thumbnails' );
show_admin_bar(false);

add_action( 'cmb2_render_post_search_text', function( $field ) {
  $args = [
    'post_type' => $field->args['post_type'],
    'post_count' => -1,
    'orderby' => 'post__in',
    'post__in' => explode( ',', $field->escaped_value ),
  ];
  $posts = get_posts( $args );
  foreach ( $posts as $post ) {
    printf( '%d: <a href="%s">%s</a><br>', $post->ID, get_edit_post_link( $post->ID ), $post->post_title );
  }
}, 20 );

// Change Url
add_filter( 'login_headerurl', 'custom_loginlogo_url' );
function custom_loginlogo_url($url) {
  return home_url();
}

// Redirect after login
function login_redirect( $redirect_to, $request, $user ){
    return home_url();
}
add_filter( 'login_redirect', 'login_redirect', 10, 3 );

// Redirect Home para ano vigente do usuário
function redirect_to_year() {

  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_home_opcoes = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano_home = $ano_home_opcoes['opcoes_gerais_ano_usuarios_' . $user_empresa];

  $id_from_slug = get_page_by_path( $ano_home, OBJECT, 'anos' );

  if(!is_admin() && is_home() && is_user_logged_in()) {
    wp_redirect(get_permalink( $id_from_slug ));
    exit();
  }
}
add_action('template_redirect', 'redirect_to_year');

// Custom post count
add_action( 'admin_init', 'grupos_post_count' );
  function grupos_post_count() {
    $author_id = get_the_author_meta( 'ID' ); 
    $current_user_id = get_current_user_id();

  $count = count_user_posts( $current_user_id , 'grupos'  );

  if($count >= 1) {
    // echo '<style>.page-title-action {display: none !important}</style>';
  }
}

////////////////////////////////////////////////////
// Extend Search
// Fim Extend Search
///////////////////////////////////////////////////

///////////////////////////////////////////////////
// https://rudrastyh.com/wordpress/pre_user_query.html
// Hide users
function modify_user_list($query){
  if(!current_user_can('administrator')) {
    $user = wp_get_current_user();

    $user_id = $user->ID; 
    $user_infos_empresas = get_user_meta($user_id, 'user_infos_empresas', true);

    $query->query_vars['meta_key'] = 'user_infos_empresas';
    $query->query_vars['meta_value'] = $user_infos_empresas; 
    $query->query_vars['meta_compare'] = '=';

    return $query;
  }
}
add_action('pre_get_users', 'modify_user_list');
///////////////////////////////////////////////////

//////////////////// Exibe author/criador/cordenador do grupo
function add_author_support_to_posts() {
  if(current_user_can('administrator')) {

    /////////////////////////////////////////////////////////////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
    $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];
    /////////////////////////////////////////////////////////////////////

    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

      foreach($terms as $term) {

        add_post_type_support( 'grupos_' . $ano . '_' . $term->slug, 'author' );

      }
  
  }
}
add_action( 'init', 'add_author_support_to_posts' );

//////////////////////////// Restrição post editado
// Retorna membro para listagem de posts evitando que prossiga tomando controle
add_action( 'load-post.php', 'redirect_locked_post_wpse_95718' );

function redirect_locked_post_wpse_95718()
{
    if( isset($_GET['post'] ) && wp_check_post_lock( $_GET['post'] ) )
    {
        global $typenow;
        $goto = ( 'post' == $typenow ) ? '' : "?post_type=$typenow";
        wp_redirect( admin_url( "edit.php$goto" ) );
        exit();
    }
}
// Fim redirecionamento
// Exibe mensagem
foreach( array( 'post', 'page' ) as $hook )
    add_filter( "{$hook}_row_actions", 'locked_post_notice_wpse_95718', 10, 2 );

function locked_post_notice_wpse_95718( $actions, $post ) 
{
    if( wp_check_post_lock( $post->ID ) )
    {
        $actions['locked'] = sprintf(
            '<span style="color: #c23b3b;display: block;margin-top: 10px;margin-bottom: 10px;">'.apply_filters('str_from_lang','Esta página está sendo editada no momento. Este bloqueio ocorre para que nenhuma informação seja perdida. <br>Essa mesma mensagem aparecerá para outros membros quando você estiver realizando suas alterações. Tente novamente mais tarde.','Esta página está siendo editada en el momento. Este bloqueo se produce para que no se pierda información. <br>Este mismo mensaje aparecerá para otros miembros cuando realice sus cambios. Vuelve a intentarlo más tarde.').'</span>',
            strtoupper( $post->post_type )
        );
    }
    return $actions; 
}
// Fim mensagem
//////////////////////////// Fim restrição

//////////////////////////// Remove coluna de author admin
function manage_colum_grupos( $columns ) {
  unset($columns['author']);
  return $columns;
}

function my_columns_grpuos() {
  add_filter( 'manage_posts_columns' , 'manage_colum_grupos' );
}
add_action( 'admin_init' , 'my_columns_grpuos' );
//////////////////////////// Fim remove coluna

########### USER BY NAME ###########
/*
add_action( 'pre_get_users', 'user_by_name' );  
function user_by_name( $query ) {  
  if( ! is_admin() )  
      return;  

  $orderby = $query->get( 'orderby');  

  if( 'user_field_confirmado' == $orderby ) {  
      $query->set('meta_key','user_field_confirmado');
      $query->set('meta_type','text');
      $query->set('orderby','meta_value');  
  } 
  
  ########### CUSTOM META_QUERY ###########
  // META QUERY - RELAÇÃO
  $meta_query = array(
    'relation' => 'AND'
  );

  // Aprovação de selife
  if(!empty($_GET['user_field_selfie_aprov'])) {
    $meta_query[] = array(
    'key'       => 'user_field_selfie_aprov',
      'value'     => $_GET['user_field_selfie_aprov'],
      'compare'   => '==',
    );
  }
	$query->set( 'meta_query', $meta_query );
########### FIM USER BY NAME ###########
} */

function search_by_users_query($query)
{
    global $pagenow;

    if (is_admin() && 'users.php' == $pagenow && $_GET['s']) {

        //Remove trailing and starting empty spaces
        $the_search = trim($query->query_vars['search']);
        $the_search = trim($query->query_vars['search'], '*');

        $query->set('meta_key', array('first_name','user_infos_empresas','user_infos_unidades','login'));
        $query->set('meta_value', $_GET['s']);
        $query->set('meta_compare', 'LIKE');

        $query->set('search', '');
    }
}
add_action('pre_get_users', 'search_by_users_query', 20);