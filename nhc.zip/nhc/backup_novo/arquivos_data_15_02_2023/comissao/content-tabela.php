<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

?>

<div class="page<?php echo get_the_ID(); ?> page-single">          
  <div class="container">

    <div class="orientativas-count space-top">
      <div class="container">
        <h1><?php echo apply_filters('str_from_lang','Quantidade de grupos','Numero de grupos'); ?>: 
        <?php
        $count_posts = wp_count_posts( 'grupos_' . $ano . '_' . $user_empresa)->publish;
        echo $count_posts;
        ?>
        </h1>

        <?php

            $args = array(
                'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
                'post_status' => array('publish'),
                'posts_per_page' => -1
            );

            $loop = new WP_Query( $args );

            if ($loop->have_posts())
            
            while ( $loop->have_posts() ) : $loop->the_post();
               
              $confirma_1_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
              $confirma_2_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
              $confirma_3_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true ); 

              /////////// CONTAGEM DE CONFIRMACOES DA PRIMEIRA ORIENTATIVA
              if($confirma_1_orientativa == 'Sim') {
                $confirma_1_orientativa_sim = $confirma_1_orientativa_sim + 1;
              }
              else if ($confirma_1_orientativa == 'Não') {
                $confirma_1_orientativa_nao = $confirma_1_orientativa_nao + 1;
              }
              else if (empty($confirma_1_orientativa)) {
                $confirma_1_orientativa_vazio = $confirma_1_orientativa_vazio + 1;
              }

              /////////// CONTAGEM DE CONFIRMACOES DA SEGUNDA ORIENTATIVA
              if($confirma_2_orientativa == 'Sim') {
                $confirma_2_orientativa_sim = $confirma_2_orientativa_sim + 1;
              }
              else if ($confirma_2_orientativa == 'Não') {
                $confirma_2_orientativa_nao = $confirma_2_orientativa_nao + 1;
              }
              else if (empty($confirma_2_orientativa)) {
                $confirma_2_orientativa_vazio = $confirma_2_orientativa_vazio + 1;
              }

              /////////// CONTAGEM DE CONFIRMACOES DA TERCEIRA ORIENTATIVA
              if($confirma_3_orientativa == 'Sim') {
                $confirma_3_orientativa_sim = $confirma_3_orientativa_sim + 1;
              }
              else if ($confirma_3_orientativa == 'Não') {
                $confirma_3_orientativa_nao = $confirma_3_orientativa_nao + 1;
              }
              else if (empty($confirma_3_orientativa)) {
                $confirma_3_orientativa_vazio = $confirma_3_orientativa_vazio + 1;
              }

            endwhile;

            wp_reset_postdata();

        ?>

        <h2 id="primeira"><span><?php echo apply_filters('str_from_lang','1ª Orientativa','1ra Orientación'); ?>:</span> <?php echo apply_filters('str_from_lang','Aguardando','Esperando'); ?>: <?php if(empty($confirma_1_orientativa_vazio)) { echo '--'; } else echo $confirma_1_orientativa_vazio; ?> / <?php echo apply_filters('str_from_lang','Sim','Sí'); ?>: <?php if(empty($confirma_1_orientativa_sim)) { echo '--'; } else echo $confirma_1_orientativa_sim; ?> / <?php echo apply_filters('str_from_lang','Não','No'); ?>: <?php if(empty($confirma_1_orientativa_nao)) { echo '--'; } else echo $confirma_1_orientativa_nao; ?> </h2>

        <h2 id="segunda"><span><?php echo apply_filters('str_from_lang','2ª Orientativa','2da Orientación'); ?>:</span> <?php echo apply_filters('str_from_lang','Aguardando','Esperando'); ?>: <?php if(empty($confirma_2_orientativa_vazio)) { echo '--'; } else echo $confirma_2_orientativa_vazio; ?> / <?php echo apply_filters('str_from_lang','Sim','Sí'); ?>: <?php if(empty($confirma_2_orientativa_sim)) { echo '--'; } else echo $confirma_2_orientativa_sim; ?> / <?php echo apply_filters('str_from_lang','Não','No'); ?>: <?php if(empty($confirma_2_orientativa_nao)) { echo '--'; } else echo $confirma_2_orientativa_nao; ?> </h2>

        <?php
        ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
        // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
        if($user_empresa == 'hsa') {
          $_orientativa_3_texto = 'Classificatória';
        }
        else {
          $_orientativa_3_texto = '3ª Orientativa';
        }
        ################# FIM REGRA ADICIONAL
        ?>

        <h2 id="terceira"><span><?php echo apply_filters('str_from_lang',$_orientativa_3_texto,'3ra Orientación'); ?>:</span> <?php echo apply_filters('str_from_lang','Aguardando','Esperando'); ?>: <?php if(empty($confirma_3_orientativa_vazio)) { echo '--'; } else echo $confirma_3_orientativa_vazio; ?> / <?php echo apply_filters('str_from_lang','Sim','Sí'); ?>: <?php if(empty($confirma_3_orientativa_sim)) { echo '--'; } else echo $confirma_3_orientativa_sim; ?> / <?php echo apply_filters('str_from_lang','Não','No'); ?>: <?php if(empty($confirma_3_orientativa_nao)) { echo '--'; } else echo $confirma_3_orientativa_nao; ?> </h2>
      </div>
    </div>

    <?php get_template_part('legenda'); ?>

    <div class="grupos-list comissao space-top">
      <div class="container">
      <h2><?php echo apply_filters('str_from_lang','Listagem de grupos: <span>Ano vigente ('.$ano.')</span>','Lista de grupos: <span>Año corriente ('.$ano.')</span>'); ?></h2>

      <div class="body">
          <?php

            $args = array(
                'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
                'post_status' => array('publish'),
                'orderby' => "date",
                'order' => 'DESC',
                'posts_per_page' => -1
              );

            $loop = new WP_Query( $args );

            if ( $loop->have_posts() ) { ?>

            <div class="flow-root head">
              <div class="single">
                <p><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></p>
              </div>
              <div class="single" id="middle">
                <p><?php echo apply_filters('str_from_lang','Coordenador, orientador e integrantes','Coordinador, tutor y miembros'); ?></p>
              </div>
              <div class="single">
                <p><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></p>
              </div>
            </div>

            <?php

            if ($loop->have_posts()) 
            
            while ( $loop->have_posts() ) : $loop->the_post();

              $ids_integrantes = array();
              $orientador = get_post_meta( get_the_ID(), 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
              $integrantes = get_post_meta( get_the_ID(), 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
              $confirmados = get_post_meta( get_the_ID(), 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );                     
              $confirma_1_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
              $confirma_2_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
              $confirma_3_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );     

              $classificatorias = get_post_meta( get_the_ID(), 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true ); 

              $coordenador = get_post_field( 'post_author', get_the_ID() );

                $count = $count + 1;

                ?>

                <div class="flow-root corpo">
                  <div class="single">
                    <p id="title-name">
                      <?php the_title(); ?>
                    </p>
                  </div>
                  <div class="single" id="integrantes">

                    <?php
                    if(!empty($coordenador)) { ?>
                    <b id="ori"><?php echo apply_filters('str_from_lang','Coordenador','Coordinador'); ?>: </b><p><?php echo get_user_meta($coordenador, 'first_name', true); ?></p>

                    <?php }                          
                    // Exibe orientador
                    if(!empty($orientador)) { ?>
                    <b id="ori"><?php echo apply_filters('str_from_lang','Orientador','Tutor'); ?>: </b><p><?php echo get_user_meta($orientador, 'first_name', true);; ?></p>
                    <?php } 

                    if($integrantes) {
                    
                    echo '<b id="int">'.apply_filters('str_from_lang','Integrantes','Miembros').':</b>';
                    foreach((array) $integrantes as $key => $entry ){ ?>
                     <p>
                      <?php $id = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                      $integrante_nome = get_user_meta($id, 'first_name', true);
                      echo mb_strimwidth($integrante_nome, 0, 30, "...");

                      // Exibe se integrante confirmou ou não
                      $confirmados_array = explode(" ", $confirmados);  

                      // Pega matricula (username) pelo ID do membro no loop
                      $membro_infos = get_user_by( 'id', $id );
                      $membro_matricula = $membro_infos->user_login;

                      // Compara se existe na array de confirmados
                      if (in_array($membro_matricula,$confirmados_array)) {
                        echo '<i class="fas fa-check-circle"></i>';
                      }
                      else {
                        echo '<i class="fas fa-exclamation-circle"></i>';
                      }
                      ?>
                     </p>
                    <?php
                      } }
                    ?>
                  </div>
                  <div class="single">

                      <?php if ($status == 'Inscrição'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '1ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '2ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '3ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                        <?php if($status != 'Inscrição' && $status != 'Bloqueado') { ?>
                          <span id="status-label"><?php echo apply_filters('str_from_lang','Confirmação','Confirmación'); ?>: 
                            <?php

                            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                            if($user_empresa == 'hsa') {
                              if($status == '3ª Orientativa') {
                                echo 'Classificatória';
                              }
                              else {
                                echo $status;
                              }
                            }
                            else {
                              echo $status;
                            }
                            ################# FIM REGRA ADICIONAL

                            ?>:</span>
                          <span id="status-confirma">
                            <?php

                            if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
                            ) {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Não','No').'</span>';
                            }
                            else if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
                            ) {
                              echo '<span class="status-confirma" id="confirmado">Status: '.apply_filters('str_from_lang','Sim','Sí').'</span>';
                            }

                            else {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Pendente','Pendiente').'</span>';
                            }
                            ?>
                          </span>
                        <?php } ?>
                      <?php }else if($status == 'Classificatória'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                        <?php if($status != 'Inscrição' && $status != 'Bloqueado') { ?>
                          <span id="status-label"><?php echo apply_filters('str_from_lang','Confirmação','Confirmación'); ?>: 
                            <?php

                            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                            if($user_empresa == 'hsa') {
                              if($status == '3ª Orientativa') {
                                echo 'Classificatória';
                              }
                              else {
                                echo $status;
                              }
                            }
                            else {
                              echo $status;
                            }
                            ################# FIM REGRA ADICIONAL

                            ?>:</span>
                          <span id="status-confirma">
                            <?php

                            if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
                            ) {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Não','No').'</span>';
                            }
                            else if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
                            ) {
                              echo '<span class="status-confirma" id="confirmado">Status: '.apply_filters('str_from_lang','Sim','Sí').'</span>';
                            }

                            else {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Pendente','Pendiente').'</span>';
                            }
                            ?>
                          </span>
                        <?php } ?>
                      <?php }else{ }?>
                      
                  </div>
                </div> 

            <?php endwhile;

                } else {
                    echo '<div id="text"><p>'.apply_filters('str_from_lang','Ainda não há grupos cadastrados!','¡Aún no hay grupos registrados!').'</div>';
                }

            wp_reset_postdata();

          ?>
        </div>
      </div>
    </div>

  </div>
</div>