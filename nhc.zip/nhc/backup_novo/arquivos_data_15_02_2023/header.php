<?php

if (!is_user_logged_in()) {
wp_redirect( home_url('login') );
//wp_redirect( admin_url() );
exit;
}

////////////// Identifica o idioma
$locale_browser = Locale::acceptFromHttp($_SERVER['HTTP_ACCEPT_LANGUAGE']);
// Ajustar locale também no 'functions-traducao.php'
$locale_wordpress = get_user_locale(get_current_user_id());

// Idiomas aceitos no site, todas as verificacoes sao feitas para detectar o idioma e ver se está na lista de idiomas disponíveis
$languages = ['pt_BR', 'es_ES', 'es_CL', 'es_AR']; 

if(!empty($locale_wordpress) && in_array($locale_wordpress, $languages)) {
  $locale = $locale_wordpress;
  // echo 'Wordpress: ' . $locale_wordpress . ' existe e está na array ' . print_r($languages);
}
else if(!empty($locale_browser) && in_array($locale_browser, $languages)) {
  $locale = $locale_browser;
  // echo 'Browser: ' . $locale_browser . ' existe e está na array ' . print_r($languages);
}
else {
  $locale = 'pt_BR';
  // echo 'Locale nao existe e nao está em array';
}
////////////// Fim identificação do idioma

?>

<!DOCTYPE html>
<html lang="<?php echo $locale; ?>">

<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

?>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="HONDA - NHC">
    <meta name="robots" content="noindex, nofollow">
    <meta name="keywords" content="honda, nhc" />
    <meta name="author" content="Moacir Sant'anna">

    <title><?php if(is_front_page()) { echo bloginfo("name") . ' » Honda'; } else { echo the_title() . ' » Honda';} ?></title>
    <link rel="icon" type="image/png" href="<?php bloginfo('template_url'); ?>/img/favicon.png">

    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,600&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">

    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap-theme.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" rel="stylesheet">
    <?php if(is_page('tabela')) { ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
    <?php } ?>
    <link href="<?php bloginfo('template_url'); ?>/style.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet">

    <!-- SLICK SLIDE 1/3 -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick-theme.css">
    <!-- SLICK SLIDE -->

    <?php wp_head(); ?>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GB1F7PR93N"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-GB1F7PR93N');
    </script>

  </head>

  <body <?php body_class(); ?>>

    <div class="top">
      <div class="container">
        <a href="<?php echo get_site_url(); ?>"><img id="logo" src="<?php bloginfo('template_url'); ?>/img/logo.png"></a>
        <a href="<?php echo get_site_url(); ?>"><img id="nhc" src="<?php bloginfo('template_url'); ?>/img/nhc.png"></a>
      </div>
    </div>

    <div class="conteudo">

      <?php
      $entries = get_post_meta( get_the_ID(), 'tema_slider_slides_' . $user_empresa, true );
      if( !empty( $entries ) ) {
      ?>
      <div id="HomeSlider" class="carousel slide" data-ride="carousel">
        <!-- Indicators
        <ol class="carousel-indicators">
          <li data-target="#HomeSlider" data-slide-to="0" class="active"></li>
          <li data-target="#HomeSlider" data-slide-to="1"></li>
          <li data-target="#HomeSlider" data-slide-to="2"></li>
        </ol> -->

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
          <?php
         
          foreach ( (array) $entries as $key => $entry ) {
          $link = $entry['tema_slider_link_' . $user_empresa];
          $newtab = $entry['tema_slider_newtab_' . $user_empresa];
          $counter = $counter + 1;
          ?>

          <div class="item<?php if($counter == 1) {echo ' active';} ?>">
                        <?php if(!empty($link)) { ?>
                        <a target="<?php if(!empty($newtab)) {echo '_blank';} ?>" href="<?php echo $link; ?>"><img src="<?php echo $entry['tema_slider_image_' . $user_empresa]; ?>" alt="Banner"></a>
                        <?php } else { ?>
                        <img src="<?php echo $entry['tema_slider_image_' . $user_empresa]; ?>" alt="Banner">
                        <?php } ?>
                    </div>

          <?php
          }
          ?>


        </div>

        <?php if($counter > 1) { ?>
        <!-- Left and right controls -->
        <a class="left carousel-control notscrollable" href="#HomeSlider" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control notscrollable" href="#HomeSlider" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="sr-only">Next</span>
        </a>
       <?php } ?>
      </div>

      <?php } else { echo '<br><br>'; } ?>

      <div class="ano space">
        <div class="container">
          <div class="anos">
            <div class="slider-single-anos">

              <?php

              // echo do_shortcode('[products limit="4" columns="2" visibility="featured" ]');

                  $ano_home_opcoes = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
                  $ano_home = $ano_home_opcoes['opcoes_gerais_ano_usuarios_' . $user_empresa];
                  $page_id = get_the_ID();

                    $args = array(
                        'post_type' => 'anos',
                        'orderby' => 'menu_order',
                        'order' => 'ASC',
                        'suppress_filters' => true
                        //'posts_per_page' => 8,
                        );
                    $loop = new WP_Query( $args );
                    if ( $loop->have_posts() ) {
                        while ( $loop->have_posts() ) : $loop->the_post();

                        $pagina_loop = get_the_ID();
                        ?>
                        
                        <div class="single">
                          <a id="ano" href="<?php the_permalink(); ?>" class="<?php if (is_home() && $ano_home == $pagina_loop) { echo 'current'; } else if (is_singular('anos') && $pagina_loop == $page_id) { echo 'current'; } ?>">                            
                            <?php the_title(); ?>
                          </a>
                        </div>

                        <?php
                        endwhile;
                    } else {
                        echo apply_filters('str_from_lang','Sem anos cadastrados no momento','No hay años registrados en el momento');
                    }
                    wp_reset_postdata();
              ?>
            </div>
          </div>
        </div>
      </div>

      <!-- Navigation -->
      <nav class="navbar navbar-default fixed-top">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
      
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="navbar-collapse-1">
            <ul class="nav navbar-nav navbar-left">
              <?php
              $user = wp_get_current_user();
              $allowed_roles = array('administrator', 'comissao');
              if( array_intersect($allowed_roles, $user->roles ) )
              { ?>
              <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle notscrollable" href="#"><?php echo apply_filters('str_from_lang','Administrativo','Administrativo'); ?></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo admin_url('admin.php?page=opcoes_gerais_' . $user_empresa); ?>"><?php echo apply_filters('str_from_lang','Configuração','Configuración'); ?></a></li>
                        <li><a href="<?php echo admin_url('edit.php?post_type=anos'); ?>"><?php echo apply_filters('str_from_lang','Informações do ano','Informaciones del año'); ?></a></li>
                        <li><a href="<?php echo get_site_url(); ?>/resultados"><?php echo apply_filters('str_from_lang','Resultados/Tabelas','Resultados/Tablas'); ?></a></li>
                        <li><a href="<?php echo get_site_url(); ?>/inscricoes"><?php echo apply_filters('str_from_lang','Inscrições','Inscripciones'); ?></a></li>    
                        <li><a href="<?php echo admin_url('users.php'); ?>"><?php echo apply_filters('str_from_lang','Usuários','Usuarios'); ?></a></li>          
                        <?php
                        /*
                        $count = count_user_posts( get_current_user_id() , 'grupos_' . $ano . '_' . $user_empresa );
                        if($count >= 1){ ?>
                        <li><a href="<?php echo admin_url('edit.php?post_type=grupos_' . $ano . '_' . $user_empresa); ?>"><?php echo apply_filters('str_from_lang','Grupos','Grupos'); ?>
                        </a></li>                        
                        <?php } else { ?>
                        <li><a href="<?php echo admin_url('edit.php?post_type=grupos_' . $ano . '_' . $user_empresa); ?>"><?php echo apply_filters('str_from_lang','Grupos','Grupos'); ?></a></li>
                        <?php } */ ?>
                    </ul>
              </li>
              <?php } ?>              
              <li><a href="<?php echo get_site_url(); ?>"><?php echo apply_filters('str_from_lang','Home','Pagina principal'); ?></a></li>
              <?php if(current_user_can('comissao') || current_user_can('administrator')) { ?>
              <li><a href="<?php echo get_site_url(); ?>/registros"><?php echo apply_filters('str_from_lang','Log de atividades','Registro de actividad'); ?></a></li>
              <?php } ?>
              <li><a href="<?php echo get_site_url(); ?>/contato"><?php echo apply_filters('str_from_lang','Contato','Contacto'); ?></a></li>
              <li><a href="<?php echo wp_logout_url( home_url('login')); ?>"><?php echo apply_filters('str_from_lang','Sair','Salir'); ?></a></li>
            </ul>
          </div><!--/.navbar-collapse -->
        </div><!-- /.container -->
      </nav><!-- /.navbar -->

      <?php if(

        // Condições para exibição de conteúdo
        $status != 'Bloqueado'
        || // ou - Exibe se estiver bloqueado mas é 'administrator'
        $status == 'Bloqueado' && current_user_can('administrator')
        || // ou - Exibe se estiver bloqueado mas é 'comissao'
        $status == 'Bloqueado' && current_user_can('comissao')

      ) { ?>
      <div class="fase-header">
        <div class="container space-top">
          <h1 id="user"><?php echo apply_filters('str_from_lang','Olá','Hola'); ?>, <span id="nome"><?php echo get_user_meta($current_user_id, 'first_name', true); ?></span> - <span id="empresa"><?php echo $user_empresa; ?></span></h1>

          <?php
          ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
          // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
          if($user_empresa == 'hsa') {
            $_orientativa_3_texto = 'Classificatória';
          }
          else {
            $_orientativa_3_texto = '3ª Orientativa';
          }
          ################# FIM REGRA ADICIONAL
          ?>

          <h1><?php echo apply_filters('str_from_lang','Fase','Etapa'); ?>: 
            <?php 
              if($status == 'Inscrição') {
                echo apply_filters('str_from_lang','Inscrição','Inscripción');
              }
              else if($status == '1ª Orientativa') {
                echo apply_filters('str_from_lang','1ª Orientativa','1ra Orientación');
              }
              else if($status == '2ª Orientativa') {
                echo apply_filters('str_from_lang','2ª Orientativa','2da Orientación');
              }
              else if($status == '3ª Orientativa') {
                echo apply_filters('str_from_lang',$_orientativa_3_texto,'3ra Orientación');
              }
              else if($status == 'Bloqueado') {
                echo apply_filters('str_from_lang','Bloqueado','Bloqueado');
              }
            ?></h1>
        </div>
      </div>
      <?php } ?>