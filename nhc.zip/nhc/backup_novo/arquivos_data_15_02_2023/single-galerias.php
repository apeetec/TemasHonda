<?php get_header(); ?>

      <div class="single-galeria space">
        <div class="container">
          <h1><?php the_title(); ?></h1>

          <div class="flow-root all">            
            <?php
            $files = get_post_meta( get_the_ID(), 'galeria_fotos', 1 );

            if(!empty($files)) {
            // Loop through them and output an image
            foreach ( (array) $files as $attachment_id => $attachment_url ) { $counter = $counter + 1;

            $galeria_thumb = wp_get_attachment_image_src($attachment_id, 'galeria_thumb');

            ?>
            <div class="single" style="background-image: url('<?php echo $galeria_thumb[0]; ?>');">
              <div class="shadow">
                <div class="icons">
                  <a href="<?php echo wp_get_attachment_url( $attachment_id ); ?>" data-toggle="lightbox" data-gallery="foto"><i class="fas fa-eye"></i></a>
                  <a href="<?php echo wp_get_attachment_url( $attachment_id ); ?>" download><i class="fas fa-download"></i></i></a>
                </div>
              </div>
            </div>              
            <?php } }
            ?>
          </div>
        </div>
      </div>             

   <?php get_footer(); ?>