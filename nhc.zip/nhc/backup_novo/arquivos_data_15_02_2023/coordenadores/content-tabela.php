<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

?>

<div class="grupos-list created space-top">
  <div class="container">

  <h2><?php echo apply_filters('str_from_lang','Grupos criados por mim: <span>Ano vigente ('.$ano.')</span>','Grupos creados por mí: <span>Año actual ('.$ano.')</span>'); ?></h2>

  <div class="body">
      <?php

        $args = array(
            'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
            'post_status' => array('publish'),
            'orderby' => "title",
            'order' => 'ASC',
            'author__in'     => $current_user_id,
            'posts_per_page' => -1
            );
        $loop = new WP_Query( $args );

        if ( $loop->have_posts() ) { /*

        echo '<div id="text"><p>Você possui grupos criados!</p>
        <br> 
        <a target="_blank" id="link-btn" href="' . admin_url('edit.php?post_type=grupos_' . $ano) . '">Meus grupos</a>              
        </div>'; */ ?>

        <div class="flow-root head">
          <div class="single">
            <p><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></p>
          </div>
          <div class="single" id="middle">
            <p><?php echo apply_filters('str_from_lang','Integrantes','Miembros'); ?></p>
          </div>
          <div class="single">
            <p><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></p>
          </div>
        </div>

        <?php

         while ( $loop->have_posts() ) : $loop->the_post();

              $ids_integrantes = array();
              $orientador = get_post_meta( get_the_ID(), 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
              $integrantes = get_post_meta( get_the_ID(), 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
              $confirmados = get_post_meta( get_the_ID(), 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );

              $confirma_1_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
              $confirma_2_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
              $confirma_3_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );                     

              $classificatorias = get_post_meta( get_the_ID(), 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true );

                $count = $count + 1;

                ?>

                <div class="flow-root corpo">
                  <div class="single">
                    <p id="title-name">
                      <?php the_title(); ?>
                    </p>
                  </div>
                  <div class="single" id="integrantes">

                    <?php
                    // Exibe orientador

                    if(!empty($orientador)) { ?>
                    <b id="ori"><?php echo apply_filters('str_from_lang','Orientador(a)','Tutor(a)'); ?>: </b><p><?php echo get_user_meta($orientador, 'first_name', true); ?></p>
                    <?php } 

                    if($integrantes) {
                    
                    echo '<b id="int">'.apply_filters('str_from_lang','Integrantes','Miembros').':</b>';
                    foreach((array) $integrantes as $key => $entry ){ ?>
                     <p>
                      <?php $id = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                      $integrante_nome = get_user_meta($id, 'first_name', true);
                      echo mb_strimwidth($integrante_nome, 0, 30, "...");

                      // Exibe se integrante confirmou ou não
                      $confirmados_array = explode(" ", $confirmados);  

                      // Pega matricula (username) pelo ID do membro no loop
                      $membro_infos = get_user_by( 'id', $id );
                      $membro_matricula = $membro_infos->user_login;

                      // Compara se existe na array de confirmados
                      if (in_array($membro_matricula,$confirmados_array)) {
                        echo '<i class="fas fa-check-circle"></i>';
                      }
                      else {
                        echo '<i class="fas fa-exclamation-circle"></i>';
                      }
                      ?>
                     </p>
                    <?php
                      } }
                    ?>
                  </div>
                  <div class="single">
<!--                     
                      <?php if ($status == 'Inscrição'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '1ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '2ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '3ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                        <?php if($status != 'Inscrição' && $status != 'Bloqueado') { ?>
                          <span id="status-label"><?php echo apply_filters('str_from_lang','Confirmação','Confirmación'); ?>: 
                            <?php

                            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                            if($user_empresa == 'hsa') {
                              if($status == '3ª Orientativa') {
                                echo 'Classificatória';
                              }
                              else {
                                echo $status;
                              }
                            }
                            else {
                              echo $status;
                            }
                            ################# FIM REGRA ADICIONAL

                            ?>:</span>
                          <span id="status-confirma">
                            <?php

                            if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
                            ) {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Não','No').'</span>';
                            }
                            else if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
                            ) {
                              echo '<span class="status-confirma" id="confirmado">Status: '.apply_filters('str_from_lang','Sim','Sí').'</span>';
                            }

                            else {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Pendente','Pendiente').'</span>';
                            }
                            ?>
                          </span>
                        <?php } ?>
                      <?php }else if($status == 'Classificatória'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                        <?php if($status != 'Inscrição' && $status != 'Bloqueado') { ?>
                          <span id="status-label"><?php echo apply_filters('str_from_lang','Confirmação','Confirmación'); ?>: 
                            <?php

                            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                            if($user_empresa == 'hsa') {
                              if($status == '3ª Orientativa') {
                                echo 'Classificatória';
                              }
                              else {
                                echo $status;
                              }
                            }
                            else {
                              echo $status;
                            }
                            ################# FIM REGRA ADICIONAL

                            ?>:</span>
                          <span id="status-confirma">
                            <?php

                            if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
                            ) {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Não','No').'</span>';
                            }
                            else if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
                            ) {
                              echo '<span class="status-confirma" id="confirmado">Status: '.apply_filters('str_from_lang','Sim','Sí').'</span>';
                            }

                            else {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Pendente','Pendiente').'</span>';
                            }
                            ?>
                          </span>
                        <?php } ?>
                      <?php }else{ }?>
                     -->
                  </div>
                </div> 

        <?php endwhile;

        if($status == 'Inscrição') {
        // Só exibe botão de criar grupos se for fase de "Inscrição"
        ?>
        <div class="botoes">
          <div class="container">
            <a id="link-btn" href="<?php echo admin_url('post-new.php?post_type=grupos_' . $ano . '_' . $user_empresa); ?>"><?php echo apply_filters('str_from_lang','Criar novo grupo','Crear nuevo grupo'); ?></a>
          </div>
        </div>

        <?php }

        } // Fim do IF principal caso haja grupos criados

        else {

          echo '<div id="text"><p>'.apply_filters('str_from_lang','Você ainda não criou grupos!','¡Aún no has creado ningún grupo!');
            if($status != 'Inscrição') {
            echo ' ' . apply_filters('str_from_lang','Grupos podem ser criados apenas na fase de "Inscrição"','Los grupos solo se pueden crear en la fase de "Inscripción"');
            }
          echo '</p>';

          if($status == 'Inscrição') {            

            // Só exibe botão de criar grupos se for fase de "Inscrição"
            echo '<br><a id="link-btn" href="' . admin_url('post-new.php?post_type=grupos_' . $ano . '_' . $user_empresa) . '">'.apply_filters('str_from_lang','Criar grupos','Crear grupos').'</a>';

          }

          echo '</div>';
                
        } // Fim else

        wp_reset_postdata();

      ?>

    </div>
  </div>
</div>