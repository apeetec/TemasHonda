<div class="status-bloqueado space-top">
  <div class="container">
    <h1><?php echo apply_filters('str_from_lang','Conteúdo bloqueado','Contenido bloqueado'); ?></h1>
    <p><?php echo apply_filters('str_from_lang','Aguarde a liberação da comissão','Espere a que la comisión lo libere'); ?></p>
    <i class="fas fa-lock"></i>
  </div>
</div>