</div>

<footer>

<?php
$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];
?>

  <?php wp_footer(); ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
    /* ############ SCRIPT ADICIONAL PARA DROPDOWN - MENU ADMINISTRATIVO (Por algum motivo parou para Honda) */
    $('.navbar-default li.dropdown a').on('click', function(){
      $(this).parent().toggleClass("aberto");
    });
    /* ############ FIM SCRIPT ADICIONAL PARA DROPDOWN - MENU ADMINISTRATIVO (Por algum motivo parou para Honda) */
    </script>

    <?php if(is_page('tabela')) {
    // Scripts e CSS para DATABALE
    ?>
    <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script> 

    <script>
      $(function() {
        $("button").click(function(){
        $("#tabelaresultados2").table2excel({
          // Classes a serem excluidas durante a exportacao para excel
          exclude: ".noExl",
            name: "<?php echo apply_filters('str_from_lang','Resultados','Resultados'); ?>",
            filename: "<?php echo apply_filters('str_from_lang','Resultados','Resultados'); ?>-" + <?php echo $ano; ?>, // Nome do arquivo
        }); 
         });
      });
    </script>

    <script>
    $(document).ready(function() {
      // Setup - add a text input to each footer cell
      $('#tabelaresultados thead tr').clone(true).appendTo( '#tabelaresultados thead' );
      // Adiciona classe noExl para o tr que contém os campos de busca
      $('#tabelaresultados thead > tr:last-child').addClass('noExl');

      $('#tabelaresultados thead tr:eq(1) th').each( function (i) {
          var title = $(this).text();
          $(this).html( '<input type="text" placeholder="<?php echo apply_filters('str_from_lang','Buscar','Buscar'); ?> '+title+'" />' );
   
          $( 'input', this ).on( 'keyup change', function () {
              if ( table.column(i).search() !== this.value ) {
                  table
                      .column(i)
                      .search( this.value )
                      .draw();
              }
          } );
      } );
   
        var table = $('#tabelaresultados').DataTable( {
            "lengthMenu": [[25, 50, 100, 200, 500], [25, 50, 100, 200, 500]],
            orderCellsTop: true,
            fixedHeader: true,
            language: {
            url: '<?php echo apply_filters('str_from_lang','//cdn.datatables.net/plug-ins/1.10.22/i18n/Portuguese-Brasil.json','https://cdn.datatables.net/plug-ins/1.10.22/i18n/Spanish.json'); ?>'
          }
        } );

        // Espera tabela carregar e só exibe após 1 segundo
        setTimeout(
          function() 
          {
            $('.tabela-resultados').fadeIn(300);
        }, 500);
  
    } );
    </script>
    <?php
    // Fim Scripts e CSS para DATABALE
    } ?>

    <script>
    // Botao de confirmar só aparece após marcar as 9 checkbox
    $( ".form-check .check-confirm" ).on( "click", function() {
      if($( ".form-check .check-confirm:checked" ).length == 8)
      {
        $('.covid .confirm').addClass('on');
        $('.covid .confirm').removeClass('off');
      }
      else
      {
        $('.covid .confirm').removeClass('on');
        $('.covid .confirm').addClass('off');
      }  
    });
    </script>

    <?php if(is_singular('galerias')) { ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js.map"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.min.js.map"></script>
    <?php } ?>

    <!-- SLICK SLIDE 4/5 -->

    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <script>
    $('.slider-videos').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      infinite: true,      
     });
    </script>

    <script type="text/javascript">
      <?php

        $pagina_atual = get_the_ID();
        // Começa no slider 1
        $inicializador = 1;

          $args = array(
            'post_type' => 'anos',
            'orderby' => 'publish_date',
            'order' => 'DESC',
            'suppress_filters' => true
            //'posts_per_page' => 8,
          );

          $loop = new WP_Query( $args );
              if ( $loop->have_posts() ) {
                while ( $loop->have_posts() ) : $loop->the_post();
                  $pagina_loop = get_the_ID();

                  $counter = $counter + 1;

                  // Soma a posição inicial (1) + a posição de ordem da página atual
                  $posicao = $inicializador + $counter;
                  if($pagina_atual == $pagina_loop) {

                    if($counter <= 2 ) { ?>

                    // Adiciona o valor em PHP para uma variável JS - posicao
                    posicao = 1;

                    <?php } else if ($counter == 3 ) { ?>

                    // posicao = '<?php echo $counter; ?>';

                    <?php } else { ?>

                    posicao = '<?php echo $counter; ?>';

                    <?php } ?>

              <?php
              break;
              }
          ?>

          <?php
              endwhile;
          } 
        wp_reset_postdata();
      ?>

      // Slider Navigation
      $('.slider-single-anos').slick({  
      initialSlide: posicao  - 1,    
      slidesToShow: 3,
      slidesToScroll: 1,
      arrows: true,
      infinite: true,
      prevArrow:"<i class=\"fas fa-chevron-left\"></i>",
      nextArrow:"<i class=\"fas fa-chevron-right\"></i>",      
      responsive: [{
          breakpoint: 991,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 750,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 350,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
        }
      }]  
     });
      
      $('.slider-single-content').slick({
      slidesToShow: 3,
      slidesToScroll: 1,
      centerMode: true,
      focusOnSelect: true,
      arrows: true,
      centerPadding: 0,
      fade: false,
      adaptiveHeight: true,
      infinite: true,
      useTransform: true,
      speed: 400,
      cssEase: 'cubic-bezier(0.77, 0, 0.18, 1)',
      swipeToSlide: true,
      prevArrow:"<i class=\"fas fa-chevron-left\"></i>",
      nextArrow:"<i class=\"fas fa-chevron-right\"></i>",
     });

      $('.slider-single-fotos').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      arrows: true,
      infinite: true,
      swipeToSlide: true,
      prevArrow:"<i class=\"fas fa-chevron-left\"></i>",
      nextArrow:"<i class=\"fas fa-chevron-right\"></i>",
      responsive: [{
          breakpoint: 991,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 678,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 475,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
        }
      }]  
     });
    </script>
    <!-- SLICK SLIDE 4/5 -->

    <script type="text/javascript">
      var slideCount = jQuery(".slider-single-anos .single").length;

      if (slideCount == 1) {

        $('.slider-single-anos').addClass('only-one');

        $('.slider-single-anos').slick({
          slidesToShow: 1
        });

      }

      if (slideCount == 2) {

        $('.slider-single-anos').addClass('only-two');

        $('.slider-single-anos').slick({
          slidesToShow: 2,
        });

      }

      if (slideCount == 3) {

        $('.slider-single-anos').addClass('three-or-less');

        // Clona
        $(".slider-single-anos").find('.single').clone(true, true).appendTo(".slider-single-anos .slick-track");

        $('.slider-single-anos').slick({
          slidesToShow: 3,
        });

      }

      else if (slideCount > 3) {

        $('.slider-single-anos').addClass('more-than-three');

        $('.slider-single-anos').slick({
          slidesToShow: 3
        });

      }

    </script>

    <script src="<?php bloginfo('template_url'); ?>/js/jquery.mask.js"></script>

    <script>
      var SPMaskBehavior = function (val) {
      return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
    },
    spOptions = {
      onKeyPress: function(val, e, field, options) {
          field.mask(SPMaskBehavior.apply({}, arguments), options);
        },clearIfNotMatch: true
    };

    // Adiciona a máscara ao telefone do contato e formulário do checkout
    $(document).ready(function(){
    $('input.telefone').mask(SPMaskBehavior, spOptions);
    });
    </script>
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.touchswipe/1.6.4/jquery.touchSwipe.min.js"></script>
    <script>
    $(".carousel").swipe({

      swipe: function(event, direction, distance, duration, fingerCount, fingerData) {

        if (direction == 'left') $(this).carousel('next');
        if (direction == 'right') $(this).carousel('prev');

      },
      allowPageScroll:"vertical"

    });
    </script>
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
    
    <script>
      $('#grupospendentes .confirm').on('click', function(){
          var postID = $(this).attr('data-confirm');
          var id_to_add = $(this).attr('id-to-add');

          $.ajax({
               type: "POST",
               url: "<?php echo admin_url('admin-ajax.php'); ?>",
               data:{action:'confirm_grupo', post_id: postID, add: id_to_add},
               beforeSend: function (html) {
                // Evita vários cliques consecutivos
                $('.modal.covid #edit').css('pointer-events','none');
                $('.modal.covid #edit').css('opacity','0.5');
               },
               success:function(html) {
                // alert('Confirmado com sucesso');
                window.location.href = window.location.href + '/?confirm=true'
                // location.reload();
               }
          });
      });
    </script>

    <script>
      $('.navbar-nav li a').on('click', function(){
          if(!$( this ).hasClass('dropdown-toggle')){
              $('.navbar-collapse').collapse('hide');
          }
      });
    </script>

    <script>// handle links with @href started with '#' only
        $('a').not('.notscrollable').click(function(){
            $('html, body').animate({
                scrollTop: $( $(this).attr('href') ).offset().top - 55
            }, 1000);
            return false;
        });
    </script>

    <script>
      $('.notscrollable').click(function(event) {

          // This will prevent the default action of the anchor
          event.preventDefault();

      });
    </script>

    <!-- SCROLL SEM HASH -->
    <script>
      $(document).ready(function() {
            $('html, body').hide();

            if (window.location.hash) {
                setTimeout(function() {
                    $('html, body').scrollTop(0).show();
                    $('html, body').animate({
                        scrollTop: $(window.location.hash).offset().top - 55
                        }, 1000)
                }, 0);
            }
            else {
                $('html, body').show();
            }
        });
    </script>
    <!-- FIM SCROLL SEM HASH -->

    <?php if(is_singular('galerias')) { ?>
    <script>$(document).on("click",'[data-toggle="lightbox"]',function(t){t.preventDefault(),$(this).ekkoLightbox()});</script>
    <?php } ?>

  </footer>
  </body>
</html>