<div class="legenda-check space-top">
  <div class="container center">
    <p id="main"><?php echo apply_filters('str_from_lang','Status de confirmação de leitura dos termos de cada integrante','Estado de confirmación de lectura de los términos de cada miembro'); ?></p>
    <p><i class="fas fa-check-circle"></i> = <?php echo apply_filters('str_from_lang','Leu e concordou','Leyó y aceptó'); ?><br>
    <i class="fas fa-exclamation-circle"></i> = <?php echo apply_filters('str_from_lang','Ainda não confirmou','Todavia no está confirmado'); ?></p>
  </div>
</div>