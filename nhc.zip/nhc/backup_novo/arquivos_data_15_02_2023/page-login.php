<?php

/* Template Name: Login */

if(is_user_logged_in()) {
  wp_safe_redirect(home_url());
}

else {

////////// Ação de login
if($_POST) 
  
  {  
     
      global $wpdb;  
     
      //We shall SQL escape all inputs  
      $empresa = $wpdb->escape($_REQUEST['empresa']);
      $matricula = $wpdb->escape($_REQUEST['matricula']);  
      $password = $wpdb->escape($_REQUEST['password']);  
      $remember = $wpdb->escape($_REQUEST['rememberme']);  

      $username = $empresa . $matricula;

      if ( ! empty( $username ) && is_email( $username ) ) {
        if ( $user = get_user_by_email( $username ) ) {
          $username = $user->user_login;
        }
      }
     
      if($remember) $remember = "true";  
      else $remember = "false";  
     
      $login_data = array();  
      $login_data['user_login'] = $username;  
      $login_data['user_password'] = $password;  
      $login_data['remember'] = $remember;  
     
      $user_verify = wp_signon( $login_data, false );   

      $error = false;
     
      if ( is_wp_error($user_verify) )   
      {  
          $error = true;  
         // Note, I have created a page called "Error" that is a child of the login page to handle errors. This can be anything, but it seemed a good way to me to handle errors.  
       } else
      { 

        wp_setcookie($username, $password, true);
        wp_set_current_user($user_verify->ID); 
        do_action('wp_login', $username);

        //////////////////// LOG
        // $user_verify->ID != 1
        if(!current_user_can('administrator')) { // Se ID do usuario nao for 1 (admin) executa log

        $current_user_id = $user_verify->ID;
        $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

        $ip = $_SERVER['REMOTE_ADDR'];
        $ip_lista = file_get_contents("http://ip-api.com/json/" . $ip);
        $json = json_decode($ip_lista,true);
        $nome = get_user_meta($current_user_id, 'first_name', true);

        $user_info = get_user_by( 'id', $current_user_id );
        $matricula = $wpdb->escape($_REQUEST['matricula']);

        $dispositivo = $_SERVER['HTTP_USER_AGENT'];
        $estado = $json['regionName'];
        $cidade_json = $json['city'];
        $timezone = $json['timezone'];
        $provedor = $json['isp'];
        $empresa_net = $json['org'];
        date_default_timezone_set('America/Sao_Paulo');
        $data = date('d/m/Y');
        $hora = date('H:i:s');

        //////////////////////////// INICIO #################### ////////////////////////////
        // Pego o log atual
        $log_atual = get_user_meta($current_user_id, 'user_log', true);

        // Log a ser acrescentado
$update = 'IP: ' . $ip . '
' . 'Empresa: ' . strtoupper($user_empresa) . '
' . 'Dispositivo: ' . $dispositivo . '
' . 'Cidade: ' . $cidade_json . ' (' . $estado . ') - ' . $timezone . '
'. 'Internet: ' . $provedor . ' - ' . $empresa_net . '
' . 'Data: ' . $data . '
' . 'Hora: ' . $hora . '

####################################

          ';

          // Log finalizado com a junção dos dois
          $log_final = $update . $log_atual;

          update_user_meta( $current_user_id, 'user_log', $log_final );
          //////////////////////////// FIM #################### ////////////////////////////

          //////////////////////////// INICIO #################### ////////////////////////////
          // Pego o log atual
          $log_atual_option = get_post_meta(451, 'registro_de_atividade_log_' . $user_empresa, true);

                // Log a ser acrescentado no option
$update_log_geral = 'IP: ' . $ip . '
' . 'Empresa: ' . strtoupper($user_empresa) . '
' . 'Nome: ' . $nome . '
' . 'Matrícula: ' . $matricula . '
' . 'Dispositivo: ' . $dispositivo . '
' . 'Cidade: ' . $cidade_json . ' (' . $estado . ') - ' . $timezone . '
' . 'Internet: ' . $provedor . ' - ' . $empresa_net . '
' . 'Data: ' . $data . '
' . 'Hora: ' . $hora . '

####################################

          ';
              
          // Log finalizado com a junção dos dois
          $log_final_geral = $update_log_geral . $log_atual_option;

          update_post_meta( 451, 'registro_de_atividade_log_' . $user_empresa, $log_final_geral );    
          //////////////////////////// FIM #################### ////////////////////////////

        } // Fim - se nao for admin
        //////////////////// FIM LOG

        wp_redirect(home_url());
        exit();

       }  
             
}
////////// Fim ação

?>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="HONDA NHC: Acesso restrito apenas a membros e administradores">
    <meta name="robots" content="noindex, nofollow">
    <meta name="keywords" content="honda, nhc" />
    <meta name="author" content="Moacir Sant'anna">

    <title>Honda - Login</title>
    <link rel="icon" type="image/png" href="<?php bloginfo('template_url'); ?>/img/favicon.png">

    <link href="https://fonts.googleapis.com/css?family=Montserrat:200,300,400,600&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">

    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap-theme.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url'); ?>/style.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" rel="stylesheet">

    <style>
      html, body, .conteudo {height: 100%}
    </style>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-GB1F7PR93N"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'G-GB1F7PR93N');
    </script>

  </head>

  <body <?php body_class(); ?>>

    <div class="conteudo">

      <div class="page<?php echo get_the_ID(); ?> page-single page-login">          
        <div class="container">

          <a href="<?php echo get_site_url(); ?>"><img src="<?php bloginfo('template_url'); ?>/img/nhc.png" id="logo"></a>

          <?php if($error == true) { echo '<p id="invalid">'.apply_filters('str_from_lang','Dados inválidos! Tente novamente.','¡Datos inválidos! Inténtalo de nuevo. ').'</p>'; } ?>
          <form id="login" name="form" action="" method="post"> 
                  <select id="empresa" name="empresa" required>
                    <option vale="" disabled selected><?php echo apply_filters('str_from_lang','--- Empresa ---','--- Empresa ---'); ?></option>
                    <option value="hab">HAB</option>
                    <option value="hsa">HSA</option>
                    <option value="hmdc">HMDC</option>
                    <?php
                    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );
                      foreach($terms as $term) {
                        // echo '<option value='.$term->slug.'>'.$term->name.'</option>';
                      }
                    ?>
                  </select>
                  <input id="matricula" type="text" placeholder="<?php echo apply_filters('str_from_lang','Matrícula','Matrícula'); ?>" name="matricula" required>  
                  <input id="password" type="password" placeholder="<?php echo apply_filters('str_from_lang','Data de nascimento','Fecha de nacimiento'); ?>" name="password" required>
                  <span id="ex"><?php echo apply_filters('str_from_lang','Ex: DDMMAAAA (sem barras)','Ej: DDMMAAAA (sin barras)'); ?></span>
                  <!--<label><input id="rememberme" type="checkbox" name="rememberme" checked>Lembrar minha conta</label>-->
                  <input id="submit" type="submit" name="submit" value="<?php echo apply_filters('str_from_lang','Entrar','Acceder'); ?>">  
          </form> 

        </div>
      </div>

    </div>

  <footer></footer>
  </body>
</html>

<?php } ?>