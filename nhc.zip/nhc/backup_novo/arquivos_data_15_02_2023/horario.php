<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$begin = $opcoes_gerais['opcoes_gerais_abertura_' . $user_empresa];
$end = $opcoes_gerais['opcoes_gerais_fechamento_' . $user_empresa];

################ BLOQUEIO CUSTOMIZADO HAB ################
if($user_empresa == 'hab') {
  $begin = get_query_var( 'begin' );
  $end = get_query_var( 'end' );
}

?>
<div class="horario space-top">
  <div class="container">
    <h1><?php echo apply_filters('str_from_lang','Fechado','Cerrado'); ?></h1>
    <p><?php echo apply_filters('str_from_lang','O horário de funcionamento do portal é:','Los horarios de apertura del portal son:'); ?> 
    <?php echo apply_filters('str_from_lang','<span id="horario">das <span>'.$begin.'</span> às <span>'.$end.'</span></span>','<span id="horario">de <span>'.$begin.'</span> a <span>'.$end.'</span></span>'); ?>
    </p>
    <i class="fas fa-lock"></i>
  </div>
</div>