<?php

/* Template Name: Resultados */

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

if(current_user_can('comissao') || current_user_can('administrator')) {

get_header(); ?>

      <div class="page<?php echo get_the_ID(); ?> page-single page-graficos" id="scroll">          
        <div class="container">

            <div class="space-top result-btn">
                <a class="active" href="<?php echo get_site_url(); ?>/resultado"><?php echo apply_filters('str_from_lang','Gráficos','Gráficos'); ?></a>
                <a href="<?php echo get_site_url(); ?>/resultados/tabela"><?php echo apply_filters('str_from_lang','Tabela','Tabla'); ?></a>
            </div>

            <?php
            //////////////// Armazenamento de dados ////////////////
            $args = array(
                'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
                'post_status' => 'publish',
                'posts_per_page' => -1
            );

            $posts = get_posts($args);

            if($posts) {

                $orientadores = array();
                $todas_camisetas = array();
                $todas_camisetas_orientador = array();
                $coordenadores_ids = array();
                $classificatorias = array();
                $setores = array();
                // Cada coordenador terá uma variável array onde conterá os tamanhos de camisetas
                $camisetas_por_coord = array();

                $locale_wordpress = get_user_locale(get_current_user_id());

                foreach($posts as $post) {

                    $confirma_1_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true );
                    $confirma_2_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
                    $confirma_3_orientativa = get_post_meta( $post->ID, 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );

                    /////// 1ª Orientativa ///////
                    if($confirma_1_orientativa == 'Sim') {
                        $confirma_1_orientativa_sim = $confirma_1_orientativa_sim + 1;
                    }
                    else if ($confirma_1_orientativa == 'Não') {
                        $confirma_1_orientativa_nao = $confirma_1_orientativa_nao + 1;
                    }
                    else if (empty($confirma_1_orientativa)) {
                        $confirma_1_orientativa_vazio = $confirma_1_orientativa_vazio + 1;
                    }

                    /////// 2ª Orientativa ///////
                    if($confirma_2_orientativa == 'Sim') {
                        $confirma_2_orientativa_sim = $confirma_2_orientativa_sim + 1;
                    }
                    else if ($confirma_2_orientativa == 'Não') {
                        $confirma_2_orientativa_nao = $confirma_2_orientativa_nao + 1;
                    }
                    else if (empty($confirma_2_orientativa)) {
                        $confirma_2_orientativa_vazio = $confirma_2_orientativa_vazio + 1;
                    }

                    /////// 3ª Orientativa ///////
                    if($confirma_3_orientativa == 'Sim') {
                        $classificatorias = get_post_meta( get_the_ID(), 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true ); 
                        if(in_array('1ª Classificatória' ,$classificatorias, true)){
                            $confirma_3_orientativa_sim = $confirma_3_orientativa_sim + 1;
                        }
                    }
                    else if ($confirma_3_orientativa == 'Não') {
                        $classificatorias = get_post_meta( get_the_ID(), 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true ); 
                        if(in_array('1ª Classificatória' ,$classificatorias, true)){
                            $confirma_3_orientativa_nao = $confirma_3_orientativa_nao + 1;
                        }
                    }
                    else if (empty($confirma_3_orientativa)) {
                        $classificatorias = get_post_meta( get_the_ID(), 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true ); 
                        if(in_array('1ª Classificatória' ,$classificatorias, true)){
                            $confirma_3_orientativa_vazio = $confirma_3_orientativa_vazio + 1;
                        }
                    }

                    /////// Classificatorias ///////
                    $classificatorias_loop = get_post_meta($post->ID, 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true);

                    if(!empty($classificatorias_loop)) {
                        foreach($classificatorias_loop as $class_single) {
                            $classificatorias[] = $class_single;
                        }
                    }
                    
                    /////// Fim Classificatorias ///////

                    /////// Orientadores ///////
                    // Quantas vezes cada orientador aparece                                        
                    $orientador_id = get_post_meta($post->ID, 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true);
                    $orientadores[] = get_user_meta($orientador_id, 'first_name', true);

                    /////// Coordenadores ///////
                    // Quantas vezes cada coordenador aparece                                        
                    $coordenador_id = get_post_field( 'post_author', $post->ID );
                    $coordenadores[] = get_user_meta($coordenador_id, 'first_name', true);
                    $coordenadores_ids[] = $coordenador_id;

                    /////// Orientador por coordenador ///////
                    $ori_size = get_post_meta($post->ID,'grupos_infos_orientador_camiseta_' . $ano . '_' . $user_empresa, true);

                    // Camisetas membros
                    $camiseta_grupo = get_post_meta($post->ID,'grupos_integrantes_' . $ano . '_' . $user_empresa, true);                    

                    foreach($camiseta_grupo as $key => $camiseta_single) {
                        // Pega o tamanho da camiseta
                        $camiseta_tamanho = $camiseta_single['grupos_integrantes_camiseta_' . $ano . '_' . $user_empresa];

                        $setor = $camiseta_single['grupos_integrantes_setor_' . $ano . '_' . $user_empresa];

                        $setores[] = $setor;

                        // Adiciona camisetas ao array de tamanhos do coordenador atual
                        // Será possível retornar todos os tamanhos de camisetas do coordenador apenas usando $camisetas_por_coord[ID_DO_COORDENADOR]                        

                        $camisetas_por_coord[$coordenador_id][] = $camiseta_tamanho;
                        $todas_camisetas[] = $camiseta_tamanho;

                    }          

                    // Adiciona o tamanho da camiseta do orientador
                    $camisetas_por_coord[$coordenador_id][] = $ori_size;
                    $todas_camisetas[] = $ori_size;

                    /* echo 'Coordenador: ' . $coordenador_id;
                    echo '<br>';
                    print_r($camisetas_por_coord[$coordenador_id]); */
                         
                } // Fim foreach

                /////// Quantidade de orientadores sem repetição ///////
                $orientadores_count = array_count_values($orientadores);

                /////// Quantidade de coordenadores sem repetição ///////
                $coordenadores_count = array_count_values($coordenadores);

                /////// Camisetas de todos orientadores ///////
                $todas_camisetas_orientador_count = array_count_values($todas_camisetas_orientador);

            }
            //////////////// Fim armazenamento de dados ////////////////
            ?>

            <h1 class="title space-top"><?php echo apply_filters('str_from_lang','Quantidade de grupos','Numero de grupos'); ?>: <span><?php $count_posts = wp_count_posts( 'grupos_' . $ano . '_' . $user_empresa )->publish; echo $count_posts; ?></span></h1>

            <div class="graficos pie space-top">
                <div class="row">
                    <div class="col-md-4">
                        <h1><?php echo apply_filters('str_from_lang','1ª Orientativa','1ra Orientación'); ?></h1>
                        <canvas id="orientativas1" height="250"></canvas>
                    </div>
                    <div class="col-md-4">
                        <h1><?php echo apply_filters('str_from_lang','2ª Orientativa','2da Orientación'); ?></h1>
                        <canvas id="orientativas2" height="250"></canvas>
                    </div>
                    <div class="col-md-4">

                        <?php
                        ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                        // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                        if($user_empresa == 'hsa') {
                          $_orientativa_3_texto = 'Classificatória';
                        }
                        else {
                          $_orientativa_3_texto = '3ª Orientativa';
                        }
                        ################# FIM REGRA ADICIONAL
                        ?>

                        <h1><?php echo apply_filters('str_from_lang',$_orientativa_3_texto,'3ra Orientación'); ?></h1>
                        <canvas id="orientativas3" height="250"></canvas>
                    </div>
                </div>                
            </div>

            <hr id="divisao" class="space-top">

            <div class="graficos qtd-ori space-top">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo apply_filters('str_from_lang','Grupos por orientador','Grupos por tutor'); ?></h1>
                        <canvas id="qtd-orientador" height="100"></canvas>
                    </div>
                </div>
            </div>

            <hr id="divisao" class="space-top">

            <div class="graficos qtd-cord space-top">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo apply_filters('str_from_lang','Grupos por coordenador','Grupos por coordinador'); ?></h1>
                        <canvas id="qtd-coordenador" height="100"></canvas>
                    </div>
                </div>
            </div>

            <hr id="divisao" class="space-top">

            <div class="graficos qtd-cord space-top">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo apply_filters('str_from_lang','Camisetas por coordenador','Camisetas por coordinador'); ?></h1>
                        <?php
                        ////////////////////// Verificação de camisetas (descomente para visualizar a contagem)
                        /*
                        foreach($coordenadores_ids as $key_cord => $coordenador) {  

                            echo 'Tamanho do orientador: ' . print_r($contagem_tamanhos_orientador);
                            echo '<br><br>';

                            $contagem_tamanhos = array_count_values($camisetas_por_coord[$coordenador]);

                            echo 'Coordenador: ' . get_user_meta($coordenador, 'first_name', true);
                            echo '<br>';
                            print_r($contagem_tamanhos);
                            echo '<br><br>';
                        } */                        
                        ?>
                        <canvas id="qtd-camisetas-coord" height="100"></canvas>
                    </div>
                </div>
            </div>

            <hr id="divisao" class="space-top">

            <div class="graficos qtd-cord space-top">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo apply_filters('str_from_lang','Tamanhos de camisetas geral','Tamaños generales de camiseta'); ?></h1>      
                        <canvas id="qtd-camisetas-geral" height="100"></canvas>
                    </div>
                </div>
            </div>

            <hr id="divisao" class="space-top">

            <div class="graficos qtd-cord space-top">
                <div class="row">
                    <div class="col-md-12">
                        <h1><?php echo apply_filters('str_from_lang','Membros por setor','Miembros por sector '); ?></h1>  
                        <?php
                        // print_r(array_count_values($setores));
                        ?>  
                        <canvas id="qtd-grupos-setor" height="100"></canvas>
                    </div>
                </div>
            </div>

            <hr id="divisao" class="space-top">

            <div class="graficos final space-top">
                <div class="row">
                    <div class="col-md-12">
                        <img id="trofeu" src="<?php bloginfo('template_url'); ?>/img/trofeu.png">
                        <h1>
                            <?php echo apply_filters('str_from_lang','Fase de classificação','Fase de clasificación'); ?>
                        </h1> 

                        <h2><?php echo apply_filters('str_from_lang','Quantidade de grupos','Cantidad de grupos'); ?>: <span><?php $count_posts = wp_count_posts( 'grupos_' . $ano . '_' . $user_empresa)->publish; echo $count_posts; ?></span></h2>
                        <?php                        
                        $classificatorias_unique = array_count_values($classificatorias);
                        
                        
                        // $classificatorias_grupos = get_post_meta($post->ID,'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true);
                        // print_r($classificatorias_grupos);

                       
                        // print_r($classificatorias_unique);
                        // echo '<br><br>';
                        // echo $classificatorias_unique['1ª Classificatória'] . '<br>';
                        // echo $classificatorias_unique['2ª Classificatória'] . '<br>';
                        // echo $classificatorias_unique['Semifinal'] . '<br>';
                        // echo $classificatorias_unique['Final'] . '<br>'; 
                        ?>
                        <canvas id="grupos-classificacao" height="100"></canvas>
                    </div>
                </div>
            </div>

        </div>
      </div>

    <!-- //////////////////// JS para aplicação das informações //////////////////// -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
    <script src="https://cdn.jsdelivr.net/gh/emn178/chartjs-plugin-labels/src/chartjs-plugin-labels.js"></script>

    <script>

    /////////////////////////////// PRIMEIRA ORIENTATIVA
        var confirma_1_orientativa_sim = '<?php echo $confirma_1_orientativa_sim; ?>';
        var confirma_1_orientativa_nao = '<?php echo $confirma_1_orientativa_nao; ?>';
        var confirma_1_orientativa_vazio = '<?php echo $confirma_1_orientativa_vazio; ?>';

        var ctx = document.getElementById('orientativas1').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie', //doughnut
            data: {
                // nome
                labels: ['<?php echo apply_filters('str_from_lang','Confirmados','Confirmados'); ?>', '<?php echo apply_filters('str_from_lang','Não confirmados','No confirmados'); ?>', '<?php echo apply_filters('str_from_lang','Pendentes','Pendientes'); ?>'],
                datasets: [{
                    // label: '# of Votes',
                    // Valores 
                    data: [confirma_1_orientativa_sim, confirma_1_orientativa_nao, confirma_1_orientativa_vazio],
                    backgroundColor: [
                        'rgba(0, 128, 0, 0.5)',
                        'rgba(255, 0, 0, 0.5)',
                        'rgba(255, 165, 0, 0.5)',
                    ],
                    borderColor: [
                        'rgba(0, 128, 0, 0.2)',
                        'rgba(255, 0, 0, 0.2)',
                        'rgba(255, 165, 0, 0.2)',
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                // scales: {
                //     yAxes: [{
                //         ticks: {
                //             beginAtZero: true
                //         }
                //     }]
                // },
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'percentage',
                    fontColor: 'black',
                    fontSize: 25,
                    precision: 2
                    }
                },
            }

        });
        /////////////////////////////// FIM PRIMEIRA ORIENTATIVA

        /////////////////////////////// SEGUNDA ORIENTATIVA
        var confirma_2_orientativa_sim = '<?php echo $confirma_2_orientativa_sim; ?>';
        var confirma_2_orientativa_nao = '<?php echo $confirma_2_orientativa_nao; ?>';
        var confirma_2_orientativa_vazio = '<?php echo $confirma_2_orientativa_vazio; ?>';

        var ctx = document.getElementById('orientativas2').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie', //doughnut
            data: {
                // nome
                labels: ['<?php echo apply_filters('str_from_lang','Confirmados','Confirmados'); ?>', '<?php echo apply_filters('str_from_lang','Não confirmados','No confirmados'); ?>', '<?php echo apply_filters('str_from_lang','Pendentes','Pendientes'); ?>'],
                datasets: [{
                    // label: '# of Votes',
                    // Valores 
                    data: [confirma_2_orientativa_sim, confirma_2_orientativa_nao, confirma_2_orientativa_vazio],
                    backgroundColor: [
                        'rgba(0, 128, 0, 0.5)',
                        'rgba(255, 0, 0, 0.5)',
                        'rgba(255, 165, 0, 0.5)',
                    ],
                    borderColor: [
                        'rgba(0, 128, 0, 0.2)',
                        'rgba(255, 0, 0, 0.2)',
                        'rgba(255, 165, 0, 0.2)',
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                // scales: {
                //     yAxes: [{
                //         ticks: {
                //             beginAtZero: true
                //         }
                //     }]
                // },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'percentage',
                    fontColor: 'black',
                    fontSize: 25,
                    precision: 2
                    }
                },
            },

        });
        /////////////////////////////// FIM SEGUNDA ORIENTATIVA

        /////////////////////////////// TERCEIRA ORIENTATIVA
        var confirma_3_orientativa_sim = '<?php echo $confirma_3_orientativa_sim; ?>';
        var confirma_3_orientativa_nao = '<?php echo $confirma_3_orientativa_nao; ?>';
        var confirma_3_orientativa_vazio = '<?php echo $confirma_3_orientativa_vazio; ?>';

        var ctx = document.getElementById('orientativas3').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie', //doughnut
            data: {
                // nome
                labels: ['<?php echo apply_filters('str_from_lang','Confirmados','Confirmados'); ?>', '<?php echo apply_filters('str_from_lang','Não confirmados','No confirmados'); ?>', '<?php echo apply_filters('str_from_lang','Pendentes','Pendientes'); ?>'],
                datasets: [{
                    // label: '# of Votes',
                    // Valores 
                    data: [confirma_3_orientativa_sim, confirma_3_orientativa_nao, confirma_3_orientativa_vazio],
                    backgroundColor: [
                        'rgba(0, 128, 0, 0.5)',
                        'rgba(255, 0, 0, 0.5)',
                        'rgba(255, 165, 0, 0.5)',
                    ],
                    borderColor: [
                        'rgba(0, 128, 0, 0.2)',
                        'rgba(255, 0, 0, 0.2)',
                        'rgba(255, 165, 0, 0.2)',
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                // scales: {
                //     yAxes: [{
                //         ticks: {
                //             beginAtZero: true
                //         }
                //     }]
                // },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'percentage',
                    fontColor: 'black',
                    fontSize: 25,
                    precision: 2
                    }
                },
            },

        });
    /////////////////////////////// FIM TERCEIRA ORIENTATIVA

    /////////////////////////////// GRUPOS POR ORIENTADOR
        var ctx = document.getElementById('qtd-orientador').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar', // doughnut
            data: {
                // nome
                labels: [<?php foreach($orientadores_count as $key => $orientador) {
                    echo "'".$key."', ";
                } ?>],
                datasets: [{
                    // Valores 
                    data: [<?php foreach($orientadores_count as $key => $orientador) {
                    echo "'".$orientador."', ";
                } ?>],
                    backgroundColor: [
                    <?php foreach($orientadores_count as $key => $orientador) {
                        echo "'rgba(14, 49, 122, 0.65)', ";
                    } ?>
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                layout: {
                padding: {                
                    top: 20                
                }
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItems, data) { 
                            return "<?php echo apply_filters('str_from_lang','Grupos','Grupos'); ?>: " + tooltipItems.yLabel;
                        }
                    }
                },
                legend: {
                display: false,              
                position: 'top',
                labels: {
                    // fontColor: "#000080",
                }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            // Arredonda lateral para numeros inteiros
                            callback: function(value) {if (value % 1 === 0) {return value;}}
                        }
                    }]
                },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'value',
                    // position: 'center',
                    fontColor: '#494949',
                    precision: 2
                    }
                },
            },

        });

        /* //////// Barras com habilita/desabilita
        var ctx = document.getElementById("qtd-orientador").getContext("2d");

        var mybarChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [<?php foreach($orientadores_count as $key => $orientador) {
                    echo "'".$key."', ";
                } ?>],
            datasets: [ // Inicia datasets

            <?php
            // Variavel para ver a quantidade de orientadores existentes
            $valores_orientador = array();
            // Posição de array, sempre inicam em 0
            $array_position_orientador = 0;
            // Outra para contagem de orientadores, apenas para não misturar 2 situações abaixo
            $quantidade_orientadores = count($orientadores_count);

            // Foreach que passa por cada orientador para criar os valores do 'data:', já deve ser iniciado na quantidade exata de orientador
            foreach($orientadores_count as $key => $orientador) {
                // Faz uma contagem de quantas vezes o loop roda
                $loop_count_orientador = $loop_count_orientador + 1;
                // Só prossegue se a quantidade do loop for igual a quantidade de orientadores
                if($loop_count_orientador <= $quantidade_orientadores) {
                    // Adiciona o valor 0 para a array $valores declarada acima
                    $valores_orientador[] = 0;
                }            
            }

            // Inicia outro loop de orientadores para inserção das informações
            foreach($orientadores_count as $key => $orientador) {
                // Contador
                $array_count_orientador = $array_count_orientador + 1;           

            ?>

            { // Início de cada grupo { }
            label: '<?php echo $key; ?>', // Adiciona a key (nome)
            backgroundColor: "rgba(14, 49, 122, 0.75)",
            borderWidth: 0,
            // Foreach dos valores com a quantidade pré definida no primeiro loop
            data: [<?php foreach($valores_orientador as $value_orientador) {
                // Conta quantos valores tem
                $valores_count_orientador = $valores_count_orientador + 1;
                // Se esse valor atual for igual a contagem do foreach pai, exibe o valor            
                if($valores_count_orientador == $array_count_orientador){
                echo $orientador . ',';
                }
                else {
                // Se nao, mantém 0
                echo $value_orientador . ',';
                }
            }

            // Reseta a contagem para 0 ao finalizar o loop
            $valores_count_orientador = 0;
            ?>]
            }, // Fim dos de cada grupo { }

            <?php $array_position_orientador = $array_position_orientador + 1; /* Adiciona 1 apenas após o loop finalizar */ } ?>

            ] // Fim datasets
        },

        options: {
            tooltips: {
                enabled: true,
                mode: 'single',
                callbacks: {
                    label: function(tooltipItems, data) { 
                        return "<?php echo apply_filters('str_from_lang','Grupos','Grupos'); ?>: " + tooltipItems.yLabel;
                    }
                }
            },
            legend: {
            display: true,
            position: 'top',
            labels: {
                // fontColor: "#000080",
            }
            },
            scales: {
            xAxes: [{
                "maxBarThickness": 100,
            }],
            yAxes: [{
                ticks: {
                beginAtZero: true,
                // callback: function(value) {if (value % 1 === 0) {return value;}}
                }
            }]
            },
            responsive: true,
            // maintainAspectRatio: true,
            plugins: {
                labels: {
                render: 'value',              
                // fontColor: 'white',
                // precision: 2
                },
                datalabels: {
                display: function(context) {
            var index = context.dataIndex;
            var value = context.dataset.data[index];
            return value > 0; // display labels with a value greater than 0
            }
                }
            },
        }
        }); */
    /////////////////////////////// FIM GRUPOS POR ORIENTADOR

    /////////////////////////////// GRUPOS POR COORDENADOR    
        var ctx = document.getElementById('qtd-coordenador').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar', // doughnut
            data: {
                // nome
                labels: [<?php foreach($coordenadores_count as $key => $coordenador) {
                    echo "'".$key."', ";
                } ?>],
                datasets: [{
                    // Valores 
                    data: [<?php foreach($coordenadores_count as $key => $coordenador) {
                    echo "'".$coordenador."', ";
                } ?>],
                    backgroundColor: [
                    <?php foreach($coordenadores_count as $key => $coordenador) {
                        echo "'rgba(201, 25, 25, 0.65)', ";
                    } ?>
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                layout: {
                padding: {                
                    top: 20                
                }
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItems, data) { 
                            return "<?php echo apply_filters('str_from_lang','Grupos','Grupos'); ?>: " + tooltipItems.yLabel;
                        }
                    }
                },
                legend: {
                display: false,
                position: 'top',
                labels: {
                    // fontColor: "#000080",
                }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            // Arredonda lateral para numeros inteiros
                            callback: function(value) {if (value % 1 === 0) {return value;}}
                        }
                    }]
                },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'value',
                    // position: 'center',
                    fontColor: '#494949',
                    precision: 2
                    }
                },
            },

        });
    /////////////////////////////// FIM GRUPOS POR COORDENADOR

    /////////////////////////////// CAMISETAS POR COORDENADOR
        var ctx = document.getElementById("qtd-camisetas-coord").getContext("2d");

        var mybarChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [<?php foreach($coordenadores_count as $key => $coordenador) {
                    echo "'".$key."', ";
                } ?>],
            datasets: [

            /////////// ############## INÍCIO LABEL ############## ///////////
            <?php
            ////////////////////// TAMANHO P
            $coordenadores_ids = array_unique($coordenadores_ids);
            $todas_camisetas_list = array_unique($todas_camisetas);
            // $todas_camisetas_list_flip = array_flip($todas_camisetas_list); ?>

            {
            label: '<?php echo apply_filters('str_from_lang','Tamanho','Tamaño'); ?> P',
            backgroundColor: "rgba(82, 160, 39, 0.62)",
            data: [                       

            <?php
            ////////////////////// TAMANHO P
            foreach($coordenadores_ids as $key_cord => $coordenador) { // Main foreach    

                $contagem_tamanhos = array_count_values($camisetas_por_coord[$coordenador]);

                $tamanho_p = $contagem_tamanhos['p'];

                if(!empty($tamanho_p)) {
                    echo "'".$tamanho_p."', ";
                }
                else {
                    echo "'0', ";
                }


            } // Fim main foreach
            ////////////////////// FIM TAMANHO P ?>

            ]},
            /////////// ############## FIM LABEL ############## ///////////

            /////////// ############## INÍCIO LABEL ############## ///////////
            <?php
            ////////////////////// TAMANHO M
            $coordenadores_ids = array_unique($coordenadores_ids);
            $todas_camisetas_list = array_unique($todas_camisetas);
            // $todas_camisetas_list_flip = array_flip($todas_camisetas_list); ?>

            {
            label: '<?php echo apply_filters('str_from_lang','Tamanho','Tamaño'); ?> M',
            backgroundColor: "rgba(82, 160, 39, 0.62)",
            data: [                       

            <?php
            ////////////////////// TAMANHO M
            foreach($coordenadores_ids as $key_cord => $coordenador) { // Main foreach    

                $contagem_tamanhos = array_count_values($camisetas_por_coord[$coordenador]);

                $tamanho_m = $contagem_tamanhos['m'];

                if(!empty($tamanho_m)) {
                    echo "'".$tamanho_m."', ";
                }
                else {
                    echo "'0', ";
                }


            } // Fim main foreach
            ////////////////////// FIM TAMANHO M ?>

            ]},
            /////////// ############## FIM LABEL ############## ///////////  

            /////////// ############## INÍCIO LABEL ############## ///////////
            <?php
            ////////////////////// TAMANHO G
            $coordenadores_ids = array_unique($coordenadores_ids);
            $todas_camisetas_list = array_unique($todas_camisetas);
            // $todas_camisetas_list_flip = array_flip($todas_camisetas_list); ?>

            {
            label: '<?php echo apply_filters('str_from_lang','Tamanho','Tamaño'); ?> G',
            backgroundColor: "rgba(82, 160, 39, 0.62)",
            data: [                       

            <?php
            ////////////////////// TAMANHO GG
            foreach($coordenadores_ids as $key_cord => $coordenador) { // Main foreach    

                $contagem_tamanhos = array_count_values($camisetas_por_coord[$coordenador]);

                $tamanho_g = $contagem_tamanhos['g'];

                if(!empty($tamanho_g)) {
                    echo "'".$tamanho_g."', ";
                }
                else {
                    echo "'0', ";
                }


            } // Fim main foreach
            ////////////////////// FIM TAMANHO G ?>

            ]},
            /////////// ############## FIM LABEL ############## ///////////

            /////////// ############## INÍCIO LABEL ############## ///////////
            <?php
            ////////////////////// TAMANHO GG
            $coordenadores_ids = array_unique($coordenadores_ids);
            $todas_camisetas_list = array_unique($todas_camisetas);
            // $todas_camisetas_list_flip = array_flip($todas_camisetas_list); ?>

            {
            label: '<?php echo apply_filters('str_from_lang','Tamanho GG','Tamaño XG'); ?>',
            backgroundColor: "rgba(82, 160, 39, 0.62)",
            data: [                       

            <?php
            ////////////////////// TAMANHO GG
            foreach($coordenadores_ids as $key_cord => $coordenador) { // Main foreach    

                $contagem_tamanhos = array_count_values($camisetas_por_coord[$coordenador]);

                $tamanho_gg = $contagem_tamanhos['gg'];

                if(!empty($tamanho_gg)) {
                    echo "'".$tamanho_gg."', ";
                }
                else {
                    echo "'0', ";
                }


            } // Fim main foreach
            ////////////////////// FIM TAMANHO GG ?>

            ]},
            /////////// ############## FIM LABEL ############## ///////////                    

            ]
        },

        options: {
            layout: {
                padding: {                
                    top: 30                
                }
            },
            legend: {
            display: true,
            position: 'bottom',
            labels: {
                // fontColor: "#000080",
            }
            },
            scales: {
            yAxes: [{
                ticks: {
                beginAtZero: true,
                callback: function(value) {if (value % 1 === 0) {return value;}}
                }
            }]
            },
            plugins: {
                labels: {
                render: 'value',
                // position: 'center',
                fontColor: '#494949',
                precision: 2
                }
            },
        }
        });
    /////////////////////////////// FIM CAMISETAS POR COORDENADOR

    /////////////////////////////// GRUPOS QUANTIDADES CAMISETAS GERAL
        var ctx = document.getElementById('qtd-camisetas-geral').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar', // doughnut
            data: {
                // nome
                labels: [<?php

                    $todas_camisetas_unique = array_count_values($todas_camisetas);
                    asort($todas_camisetas_unique);

                    foreach($todas_camisetas_unique as $key_cam => $camiseta) {

                    ////////////
                    if($locale_wordpress == 'es_ES') {
                        if($key_cam == 'gg') {
                            $key_cam = 'xg';
                        }
                    }
                    ////////////

                    echo "'".strtoupper($key_cam)."', ";
                } ?>],
                datasets: [{
                    // Valores 
                    data: [<?php foreach($todas_camisetas_unique as $key_cam => $qtd) {
                    echo "'".$qtd."', ";
                } ?>],
                    backgroundColor: [
                    <?php foreach($todas_camisetas_unique as $key_cam => $qtd) {
                        echo "'rgba(82, 160, 39, 0.62)', ";
                    } ?>
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                layout: {
                padding: {                
                    top: 20                
                }
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItems, data) { 
                            return "<?php echo apply_filters('str_from_lang','Quantidade','Cantidad'); ?>: " + tooltipItems.yLabel;
                        }
                    }
                },
                legend: {
                display: false,
                position: 'top',
                labels: {
                    // fontColor: "#000080",
                }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            // Arredonda lateral para numeros inteiros
                            callback: function(value) {if (value % 1 === 0) {return value;}}
                        }
                    }]
                },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'value',
                    // position: 'center',
                    fontColor: '#494949',
                    precision: 2
                    }
                },
            },

        });
    /////////////////////////////// FIM QUANTIDADES CAMISETAS GERAL

    /////////////////////////////// GRUPOS SETOR
        var ctx = document.getElementById('qtd-grupos-setor').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar', // doughnut
            data: {
                // nome
                labels: [<?php

                $setores = array_count_values($setores);
                asort($setores);

                foreach($setores as $key => $qtd) {
                    echo "'".strtoupper($key)."', "; 
                    
                } ?>],
                datasets: [{
                    // Valores 
                    data: [<?php foreach($setores as $key => $qtd) {
                    echo "'".$qtd."', ";
                } ?>],
                    backgroundColor: [
                    <?php foreach($setores as $key => $qtd) {
                        echo "'rgba(169, 58, 4, 0.68)', ";
                    } ?>
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                layout: {
                padding: {                
                    top: 20                
                }
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItems, data) { 
                            return "<?php echo apply_filters('str_from_lang','Quantidade','Cantidad'); ?>: " + tooltipItems.yLabel;
                        }
                    }
                },
                legend: {
                display: false,
                position: 'top',
                labels: {
                    // fontColor: "#000080",
                }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            // Arredonda lateral para numeros inteiros
                            callback: function(value) {if (value % 1 === 0) {return value;}}
                        }
                    }]
                },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'value',
                    // position: 'center',
                    fontColor: '#494949',
                    precision: 2
                    }
                },
            },

        });
    /////////////////////////////// FIM GRUPOS SETOR

    /////////////////////////////// GRUPOS CLASSIFICAÇÃO
        var ctx = document.getElementById('grupos-classificacao').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar', // doughnut
            data: {
                // nome
                labels: ['1ª Classificatória','2ª Classificatória','Semifinal','Final'],
                datasets: [{
                    // Valores 
                    data: [<?php

                        $posts = get_posts($args);

                        if($posts) {                            

                            foreach($posts as $post) {
                                $grupos_cassificatorias_etapas = get_post_meta( $post->ID, 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true );

                                foreach($grupos_cassificatorias_etapas as $grupos_cassificatorias_etapa){

                                    if($grupos_cassificatorias_etapa == '1ª Classificatória') {
                                        $confirma_cassificatorias_etapas_1 = $confirma_cassificatorias_etapas_1 + 1; 
                                    }
                                    else if ($grupos_cassificatorias_etapa == '2ª Classificatória') {
                                        $confirma_cassificatorias_etapas_2 = $confirma_cassificatorias_etapas_2 + 1; ;
                                    }
                                    else if ($grupos_cassificatorias_etapa == 'Semifinal') {
                                        $confirma_cassificatorias_etapas_semiFinal = $confirma_cassificatorias_etapas_semiFinal + 1;
                                    }
                                    else if ($grupos_cassificatorias_etapa == 'Final') {
                                        $confirma_cassificatorias_etapas_final = $confirma_cassificatorias_etapas_final + 1;
                                    }
                                }
                            }  
                        }

                    $classificatoria_1 = $confirma_cassificatorias_etapas_1; 
                    $classificatoria_2 = $confirma_cassificatorias_etapas_2;
                    $semifinal = $confirma_cassificatorias_etapas_semiFinal;
                    $final = $confirma_cassificatorias_etapas_final; 

                    /////////////// 1ª Classificatória ///////////////
                    if(!empty($classificatoria_1)) {
                        echo "'".$classificatoria_1."', ";
                    }
                    else {
                        echo "'0', ";
                    }
                    /////////////// 1ª Classificatória ///////////////

                    /////////////// 2ª Classificatória ///////////////
                    if(!empty($classificatoria_2)) {
                        echo "'".$classificatoria_2."', ";
                    }
                    else {
                        echo "'0', ";
                    }
                    /////////////// 2ª Classificatória ///////////////

                    /////////////// Semifinal ///////////////
                    if(!empty($semifinal)) {
                        echo "'".$semifinal."', ";
                    }
                    else {
                        echo "'0', ";
                    }
                    /////////////// Semifinal ///////////////

                    /////////////// Final ///////////////
                    if(!empty($final)) {
                        echo "'".$final."', ";
                    }
                    else {
                        echo "'0', ";
                    }
                    /////////////// Final ///////////////

                    ?>],
                    backgroundColor: [
                    'rgba(3, 87, 137, 0.40)',
                    'rgba(3, 87, 137, 0.60)',
                    'rgba(3, 87, 137, 0.85)',
                    'rgba(3, 87, 137, 1)'],
                    borderWidth: 0
                }]
            },
            options: {
                layout: {
                padding: {                
                    top: 20                
                }
                },
                tooltips: {
                    enabled: true,
                    mode: 'single',
                    callbacks: {
                        label: function(tooltipItems, data) { 
                            return "<?php echo apply_filters('str_from_lang','Quantidade','Cantidad'); ?>: " + tooltipItems.yLabel;
                        }
                    }
                },
                legend: {
                display: false,
                position: 'top',
                labels: {
                    // fontColor: "#000080",
                }
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true,
                            // Arredonda lateral para numeros inteiros
                            callback: function(value) {if (value % 1 === 0) {return value;}}
                        }
                    }]
                },
                responsive: true,
                // maintainAspectRatio: true,
                plugins: {
                    labels: {
                    render: 'value',
                    // position: 'center',
                    fontColor: '#494949',
                    precision: 2
                    }
                },
            },

        });
    /////////////////////////////// FIM QUANTIDADES CLASSIFICAÇÃO
    </script>

<?php get_footer(); } else { wp_redirect(home_url()); } ?>