<?php

/* Template Name: Orientador */

// ORIENTADORES
if(current_user_can('orientador') || current_user_can('administrator')) {

get_header(); ?>
        
      <?php 

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      ///////////// VERIFICACAO DE HORÁRIO - PARTE 1/2 /////////////

      // Variáveis dos horários selecionados
      $begin = $opcoes_gerais['opcoes_gerais_abertura_' . $user_empresa];
      $end = $opcoes_gerais['opcoes_gerais_fechamento_' . $user_empresa];
      $liberacao = $opcoes_gerais['opcoes_gerais_ignorar_' . $user_empresa];

      ////// Verifica Timezone
      if($user_empresa == 'har') {
        date_default_timezone_set('America/Argentina/Buenos_Aires');
      }
      else if($user_empresa == 'hmdc') {
        date_default_timezone_set('America/Santiago');
      }
      else {
        date_default_timezone_set('America/Sao_Paulo');
      }
      ////// Fim timezone
      $now = Date('H:i'); // Date('H:i')

      /*echo 'Begin: ' . $begin;
      echo '<br>Agora: ' . $now;
      echo '<br>End: ' . $end;*/ 

    // Condição: Se tempo de inicio for maior que hora atual, opção de liberacao nao estiver marcada e usuario nao for comissao nem administrador... ou
    // Condição: Se hora atual for maior que término, opção de liberacao nao estiver marcada e usuario nao for comissao nem administrador...
    if (
      $begin >= $now && !empty($begin) && $liberacao == 'Não' && !current_user_can('administrator') && !current_user_can('comissao') || 
      $now >= $end && !empty($end) && $liberacao == 'Não' && !current_user_can('administrator') && !current_user_can('comissao')
      ) {

      get_template_part('horario');

    }

      else {

        if(

          // Condições para exibição de conteúdo
          // Exibe conteúdo apenas se o status for diferente de bloqueado
          $status != 'Bloqueado'
          || // ou - Exibe se estiver bloqueado mas é 'administrator'
          $status == 'Bloqueado' && current_user_can('administrator')
          || // ou - Exibe se estiver bloqueado mas é 'comissao'
          $status == 'Bloqueado' && current_user_can('comissao')

        ) { 

        // Exibe a tabela de grupos da página do orientador
        get_template_part('orientadores/content','tabela');

        } else { get_template_part('bloqueado'); }

      } // END Else bloqueio de horarios

      ?>

<?php get_footer(); } else { wp_redirect(home_url()); } ?>