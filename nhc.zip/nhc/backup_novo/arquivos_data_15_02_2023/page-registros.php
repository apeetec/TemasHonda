<?php

/* Template Name: Registros */

// COMISSAO
if(current_user_can('comissao') || current_user_can('administrator')) {

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

get_header(); ?>

      <div class="page<?php echo get_the_ID(); ?> page-single">          
        <div class="container">

          <div class="registros space-top">
            <h1 class="main"><?php echo apply_filters('str_from_lang','Registro de atividades','Registro de actividad'); ?></h1>

            <div id="registros">
              <?php

                $registros = get_post_meta(get_the_ID(), 'registro_de_atividade_log_'  .$user_empresa, true);
                echo wpautop($registros);
              ?>
            </div>
          </div>

        </div>
      </div>

<?php get_footer(); } else { wp_redirect(home_url()); } ?>