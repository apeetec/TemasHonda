<?php 

///////////////////// USER TAXONOMY - UNIDADE
// Tutorial user taxonomy
// https://codebriefly.com/how-to-create-taxonomy-for-users-in-wordpress/

// Register Custom Taxonomy
function register_user_taxonomy_unidades() {

  $labels = array(
    'name'                       => apply_filters('str_from_lang','Unidade','Unidad'),
    'singular_name'              => apply_filters('str_from_lang','Unidade','Unidad'),
    'menu_name'                  => apply_filters('str_from_lang','Unidades','Unidades'),
    'all_items'                  => apply_filters('str_from_lang','Todas unidades','Todas las unidades'),
    'parent_item'                => apply_filters('str_from_lang','Unidade pai','Unidad padre'),
    'parent_item_colon'          => apply_filters('str_from_lang','Item pai','Elemento padre'),
    'new_item_name'              => apply_filters('str_from_lang','Nova unidade','Nueva unidad'),
    'add_new_item'               => apply_filters('str_from_lang','Adicionar unidade','Añadir unidad'),
    'edit_item'                  => apply_filters('str_from_lang','Editar unidade','Editar unidad'),
    'update_item'                => apply_filters('str_from_lang','Atualizar unidade','Actualizar unidad'),
    'view_item'                  => apply_filters('str_from_lang','Ver unidade','Ver unidad'),
    'separate_items_with_commas' => apply_filters('str_from_lang','Separar itens com vírgula','Separar los elementos con una coma'),
    'add_or_remove_items'        => apply_filters('str_from_lang','Adicionar ou remover unidades','Añadir o eliminar unidades'),
    'choose_from_most_used'      => apply_filters('str_from_lang','Escolher as mais usadas','Elegir a las más utilizadas'),
    'popular_items'              => apply_filters('str_from_lang','Unidades populares','Unidades populares'),
    'search_items'               => apply_filters('str_from_lang','Buscar unidades','Buscar unidades'),
    'not_found'                  => apply_filters('str_from_lang','Não encontrado','No encontrado'),
    'no_terms'                   => apply_filters('str_from_lang','Não encontrado','No encontrado'),
    'items_list'                 => apply_filters('str_from_lang','Lista de unidades','Lista de unidades'),
    'items_list_navigation'      => apply_filters('str_from_lang','Lista de unidades','Lista de unidades'),
  );
  $args = array(
    'labels'                     => $labels,
    'hierarchical'               => false,
    'public'                     => false,
    'show_ui'                    => true,
    'show_admin_column'          => false,
    'show_in_nav_menus'          => true,
    'show_tagcloud'              => true,
    'capabilities' => array(
          'manage_terms' => 'manage_unidade',
          'edit_terms' => 'edit_unidade',
          'delete_terms' => 'delete_unidade',
          'assign_terms' => 'assign_unidade',
      )
  );
  register_taxonomy( 'user_unidade', array( 'user' ), $args );

}
add_action( 'init', 'register_user_taxonomy_unidades', 0 );

//////////// Adiciona a página para acrescentar/editar taxonomias
function cb_add_user_unidade_taxonomy_admin_page() {
  $tax = get_taxonomy( 'user_unidade' );
  add_users_page(
    esc_attr( $tax->labels->menu_name ),
    esc_attr( $tax->labels->menu_name ),
    $tax->cap->manage_terms,
    'edit-tags.php?taxonomy=' . $tax->name
  );
}
add_action( 'admin_menu', 'cb_add_user_unidade_taxonomy_admin_page' );

//////////// Remove a coluna posts e adiciona a usuários
function cb_manage_user_unidade_user_column( $columns ) {

  unset( $columns['posts'] );

  // $columns['users'] = __( 'Usuários' );

  return $columns;
}
add_filter( 'manage_edit-user_unidade_columns', 'cb_manage_user_unidade_user_column' );

//////////// Atualiza a contagem de membros naquela unidade
function cb_manage_user_unidade_column( $display, $column, $term_id ) {

  if ( 'users' === $column ) {
    $term = get_term( $term_id, 'user_unidade' );
    echo $term->count;
  }
}
add_filter( 'manage_user_unidade_custom_column', 'cb_manage_user_unidade_column', 10, 3 );
///////////////////// END USER TAXONOMY

?>