<?php 

################ ADICIONAR SETOR AUTOMATICAMENTE ################
//////////////// PEGA OS DADOS O USUÁRIO ////////////////
add_action('wp_ajax_get_user_setor', 'get_user_setor_by_id');
add_action( 'wp_ajax_nopriv_get_user_setor', 'get_user_setor_by_id' );

function get_user_setor_by_id() {

  $id = $_REQUEST['id'];
  $setor = get_user_meta( $id, 'user_infos_setores', true );
  // Pega o setor
  echo $setor;

  wp_die();

}
//////////////// FIM PEGA OS DADOS DO USUARIO ////////////////

//////////////// Seleção de Setor ////////////////
// inline script via wp_print_scripts
function shapeSpace_print_scripts() { 
  
  ?>
  
  <script>
    ///////////////////////// SETOR AUTOMATICO
    jQuery(document).ready(function ($) {

    /////////////////////// MUDAR SETOR #1 ///////////////////////
    jQuery(document).on("change", ".nome_integrante_js select", function(){

      var parent = jQuery(this).closest('.cmb-repeatable-grouping').find('.setor_integrante_js input');

      var userId = jQuery(this).val();

      $.ajax({
                 type: "POST",
                 url: '<?php echo admin_url('admin-ajax.php'); ?>',
                 data:{action:'get_user_setor', id: userId},
                 success:function(html) {
                  // Adiciona o setor com base no usuário
                   jQuery(parent).val(html);
                   // alert(jQuery(parent).val());
                 }

            });

    });
    /////////////////////// MUDAR SETOR #1 ///////////////////////
           
    });
    ///////////////////////// FIM SETOR
  </script>

  <script src="<?php bloginfo('template_url'); ?>/js/jquery.mask.js"></script>
  <script>
  // Adiciona máscara para valores
  jQuery(document).ready(function(){
    jQuery('.investimento_mask input').mask('#.##0,00', {clearIfNotMatch: true, reverse: true});
  });
  </script>

  <script type='text/javascript'>
    // Desativa os membros que já se encontram em grupos
    // Membros removidos através do arquivo inc/functions-cmb2-grupos.php linha 610
    // Se tiver apenas um [ no nome, já entende que contém o aviso de restrição do membro
    jQuery( document ).ready(function() {
      jQuery(".nome_integrante_js select option:contains('[')").attr('disabled','disabled');
      jQuery(".nome_orientador_js select option:contains('[')").attr('disabled','disabled');
    });
  </script>

  <script>
    // Classificatórias    
    jQuery('.cmb2-wrap .trofeus ul li input').change(function() {
      jQuery(this).closest('ul').find('input:checkbox').not(this).prop('checked', true); // Check all
      jQuery(this).parent().nextAll().find('input:checkbox').prop('checked', false); // Uncheck next ones
    });
  </script>
  
  <?php
  
}
add_action('admin_footer', 'shapeSpace_print_scripts');
//////////////// Fim Seleção de Setor ////////////////
################ ADICIONAR SETOR AUTOMATICAMENTE ################

?>