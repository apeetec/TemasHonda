<?php 

//////////////// POSTS UNICOS - AVOID DUPLICATES ////////////////

// VERIFICACAO DE REPETIÇÃO DESATIVADA
add_action('pre_post_update', 'check_post_title_duplicate', 10, 2);
function check_post_title_duplicate($post_ID, $data) {

    // Check if the post is a revision or autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE || $data['post_status'] == 'trash') {
        return;
    }

    global $wpdb;

    $post_title_value = $data['post_title'];
    $post_type_value = $data['post_type'];

    // Check if the post already exists with the same title, excluding the current post ID
    $query = "SELECT COUNT(*) FROM $wpdb->posts WHERE post_title LIKE %s AND post_type = %s AND post_status != 'trash' AND ID != %d";
    $count = $wpdb->get_var($wpdb->prepare($query, $post_title_value, $post_type_value, $post_ID));

    // If a post with the same title already exists, display an error
    if ($count > 0) {
        wp_die(__('Um grupo com este nome já existe! <a href="javascript:history.back()">Clique aqui</a> para voltar e escolha outro.'));
    }
}
//////////////// FIM POSTS UNICOS - AVOID DUPLICATES ////////////////

?>