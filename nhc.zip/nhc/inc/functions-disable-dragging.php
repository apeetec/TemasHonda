<?php 

function disable_dragging_script_init() 
{
  wp_enqueue_script('jquery');
}

function disable_dragging_script( $post ) {

  // if(!current_user_can('administrator')) { }

?>

    <script type='text/javascript'>
    jQuery( document ).ready(function() {
      
      // jQuery('.postbox-container *').draggable( "disable" );

    });
  </script>

<?php }

add_action( 'admin_init', 'disable_dragging_script_init' );
add_action( 'edit_form_after_title', 'disable_dragging_script' );

?>