<?php

/////////////// STATUS ///////////////
$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$bloqueio = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$bloqueio_status = $bloqueio['opcoes_gerais_status_' . $user_empresa];

// ANO
$ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
/////////////// STATUS ///////////////

// Início condicional

if(

  // Condições para exibição de grupos
  $bloqueio_status != 'Bloqueado' && !empty($ano)
  || // ou - Exibe se estiver bloqueado mas é 'administrator'
  $bloqueio_status == 'Bloqueado' && !empty($ano) && current_user_can('administrator')
  || // ou - Exibe se estiver bloqueado mas é 'comissao'
  $bloqueio_status == 'Bloqueado' && !empty($ano) && current_user_can('comissao')

) {

// Cria Post
add_action('init', 'type_post_grupos');
 
  function type_post_grupos() { 

    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

      foreach($terms as $term) {
      
        $count = 3;
        $count = $count + 1;

        if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

          $current_user_id = get_current_user_id();
          $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

          /////////////// ANO VIGENTE ///////////////
          $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
          $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
          /////////////// ANO VIGENTE ///////////////

          $labels = array(
              'name' => apply_filters('str_from_lang','Grupos','Grupos') . ' ' . $ano . ' - ' . $term->name,
              'singular_name' => apply_filters('str_from_lang','Grupo','Grupo') . ' - ' . $term->name,
              'add_new' => apply_filters('str_from_lang','Adicionar Grupo','Añadir grupo'),
              'add_new_item' => apply_filters('str_from_lang','Novo Grupo','Nuevo Grupo'),
              'edit_item' => apply_filters('str_from_lang','Editar Grupo','Editar Grupo') . ' - ' . $term->name,
              'new_item' => apply_filters('str_from_lang','Novo Grupo','Nuevo Grupo') . ' - ' . $term->name,
              'view_item' => apply_filters('str_from_lang','Ver Grupo','Ver Grupo') . ' - ' . $term->name,
              'search_items' => apply_filters('str_from_lang','Procurar Grupos','Buscar Grupos') . ' - ' . $term->name,
              'not_found' =>  apply_filters('str_from_lang','Nenhum grupo encontrado','No se encontraron grupos') . ' - ' . $term->name,
              'not_found_in_trash' => apply_filters('str_from_lang','Nenhum grupo encontrado na lixeira','No se encontraron grupos en la papelera'),
              'parent_item_colon' => '',
              'menu_name' => apply_filters('str_from_lang','Grupos','Grupos') . ' ' . $ano . ' - ' . $term->name,
          );

          $args = array(
              'labels' => $labels,
              'public' => false,
              'menu_icon' => 'dashicons-buddicons-buddypress-logo',
              'public_queryable' => true,
              'show_ui' => true,           
              'query_var' => true,
              'rewrite' => array( 'slug' => false, 'with_front' => false ),// true,
              'capability_type' => 'post',
              'has_archive' => false,
              'hierarchical' => false,
              'menu_position' => null,    
              'menu_position' => $count,   
              'supports' => array('title'),
              'map_meta_cap'    => true,
                'capability_type' => 'grupos_cap',
                  'capabilities' => array(
                    'create_posts' => 'create_grupos',
                    'publish_posts' => 'publish_grupos',
                    'edit_posts' => 'edit_grupos',
                    'edit_others_posts' => 'edit_others_grupos',
                    'edit_private_posts' => 'edit_private_grupos',
                    'delete_posts' => 'delete_grupos',
                    'delete_others_posts' => 'delete_others_grupos',
                    'delete_private_posts' => 'delete_private_grupos',
                    'delete_published_posts' => 'delete_published_grupos',
                    'read_private_posts' => 'read_private_grupos',
                    'edit_posts' => 'edit_grupos',
                    'edit_private_post' => 'edit_private_grupos',
                    'edit_published_posts' => 'edit_published_grupos',
                    'delete_posts' => 'delete_grupos',
                    'read_posts' => 'read_grupos',
                  ),
            );
 
            register_post_type( 'grupos_' . $ano . '_' . $term->slug, $args );
            flush_rewrite_rules();
        } // IF

      } // End foreach

  } // End function

} // Fim condicional


///// Edita textos de atualização / criação
add_filter( 'post_updated_messages', 'rw_post_updated_messages' );

function rw_post_updated_messages( $messages ) {

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

    foreach($terms as $term) {

        if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true)) {

            /////////////// ANO VIGENTE ///////////////
            $ano_selecao = get_option( 'opcoes_gerais_' . $term->slug, 1 );
            $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $term->slug];
            /////////////// ANO VIGENTE ///////////////

            $post             = get_post();
            $post_type        = get_post_type( $post );
            $post_type_object = get_post_type_object( $post_type );
            
            $messages['grupos_'  . $ano . '_' . $term->slug] = array(
              0  => '', // Unused. Messages start at index 1.
              1  => __( apply_filters('str_from_lang','Grupo atualizado com sucesso!','¡Grupo actualizado con éxito!') ),
              2  => __( apply_filters('str_from_lang','Campos customizados atualizados!','¡Campos personalizados actualizados!') ),
              3  => __( apply_filters('str_from_lang','Campo customizado deletado!','¡Campo personalizado eliminado!') ),
              4  => __( apply_filters('str_from_lang','Grupo atualizado com sucesso!','¡Grupo actualizado con éxito!') ),
              /* translators: %s: date and time of the revision */
              5  => isset( $_GET['revision'] ) ? sprintf( __( apply_filters('str_from_lang','Grupo recuperado de revisão para %s','Grupo recuperado de la revisión para %s') ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
              6  => __( apply_filters('str_from_lang','Grupo publicado com sucesso!','¡Grupo publicado con éxito!') ),
              7  => __( apply_filters('str_from_lang','Grupo salvo!','¡Grupo guardado!') ),
              8  => __( apply_filters('str_from_lang','Grupo enviado!','¡Grupo enviado!') ),
              9  => sprintf(
                __( apply_filters('str_from_lang','Publicação do grupo agendado para: <strong>%1$s</strong>.','Publicación del grupo programada para: <strong>%1$s</strong>.') ),
                // translators: Publish box date format, see http://php.net/date
                date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) )
              ),
              10 => __( apply_filters('str_from_lang','Rascunho de grupo atualizado.','Borrador del grupo actualizado.') )
            );

            return $messages;

        } // End if term

    } // End foreach

}
///// Fim edita textos do grupo

/////// Edita texto de entrada
function wpb_change_title_text_animais( $title ){

    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

      foreach($terms as $term) {

        if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true)) {

           $screen = get_current_screen();

           /////////////// ANO VIGENTE ///////////////
           $ano_selecao = get_option( 'opcoes_gerais_' . $term->slug, 1 );
           $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $term->slug];
           /////////////// ANO VIGENTE ///////////////
        
           if  ( 'grupos_' . $ano . '_' . $term->slug == $screen->post_type ) {
                $title = 'Nome do grupo';
           }
        
           return $title;

        } // End IF term

    } // End foreach

} // End function
add_filter( 'enter_title_here', 'wpb_change_title_text_animais' );
/////// Fim texto de entrada

?>