<?php 

// INÍCIO CAMPOS DOS GRUPOS
// INICIO SLIDES
add_action( 'cmb2_admin_init', 'custom_post_grupos_fields' );

function custom_post_grupos_fields() {

  ///////////////////////// VALORES FORA DO LOOP
  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
  ///////////////////////// VALORES FORA DO LOOP

  ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
  // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
  if($user_empresa == 'hsa') {
    $_orientativa_3_texto = 'Classificatória';
  }
  else {
    $_orientativa_3_texto = '3ª Orientativa';
  }
  ################# FIM REGRA ADICIONAL

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

      foreach($terms as $term) {

        /////////////// ANO VIGENTE ///////////////
        $current_user_id = get_current_user_id();
        $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

        $ano_selecao = get_option( 'opcoes_gerais_' . $term->slug, 1 );
        $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $term->slug];
        /////////////// ANO VIGENTE ///////////////

        if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

          /////////// PERMISSÃO DE IDS PARA EDITAR CAMPOS
          // ID DO AUTOR DO GRUPO
          $auth_user_ids = array();
          if ( is_admin() ) {
              if( isset( $_GET['post'] ) && isset( $_GET['action'] ) && $_GET['action'] === 'edit' ) {
                  $post_id = $_GET['post'];
                  $current_post = get_post($post_id);
                  $author_id = $current_post->post_author;
                  $auth_user_ids[] = $author_id;
              } 
          }
          $current_user_id = get_current_user_id(); // Store current user's ID#
          $auth_user_ids[] = 1; // Permite editar para esses usuários: admin + autor
          /////////// FIM PERMISSÃO DE IDS PARA EDITAR CAMPOS

          /////////////////////// Bloco administrativo
          $cmb_group = new_cmb2_box( array(
            'id'           => 'grupos_infos_admin_' . $ano . '_' . $term->slug,
            'title'        => apply_filters('str_from_lang','Administrativo','Administrativo'),
            'object_types' => array( 'grupos_' . $ano . '_' . $term->slug ),
            'show_on_cb' => 'show_if_is_administrator'
          ) );

            ## CAMPOS ADMINISTRATIVOS 

            $cmb_group->add_field( array(
              'name' => apply_filters('str_from_lang','Confirmados','Confirmados'),
              'id'   => 'integrantes_confirmados_' . $ano . '_' . $term->slug,
              'type'    => 'text',
              'desc' => apply_filters('str_from_lang','Lista de matrículas confirmadas. Separe novas matrículas utilizando um <b>espaço.</b>','Lista de registros confirmados. Separe los nuevos registros con un <b>espacio.</b>'),
            ) );

            ## FIM CAMPOS ADMINISTRATIVOS
          /////////////////////// Fim Bloco administrativo

          /////////////////////// Início Blocos troféis
          $cmb_group = new_cmb2_box( array(
            'id'           => 'grupos_classificatorias_' . $ano . '_' . $term->slug,
            'title'        => apply_filters('str_from_lang','Fases das classificatórias','Clasificación'),
            'object_types' => array( 'grupos_' . $ano . '_' . $term->slug ),
            // capability'      => 'comissao', // Cap required to view options-page.
            'show_on_cb' => 'box_for_adm_comissao',
            // 'closed' => true,
          ) );

          $dirbase = get_template_directory_uri();
          $trofeu_1 = $dirbase . '/img/trofeu.png';

          $cmb_group->add_field( array(
            'name' => apply_filters('str_from_lang','Fases das classificatórias','Clasificación'),
            'id'   => 'integrantes_classificatorias_' . $ano . '_' . $term->slug,
            'type'    => 'multicheck',
            'classes' => 'trofeus',
            'select_all_button' => false,
            'options' => array(
                    '1ª Classificatória' => '<img id="trofeu" src="'.$trofeu_1.'"> '.apply_filters('str_from_lang','1ª Classificatória','1ra Clasificación'),
                    '2ª Classificatória' => '<img id="trofeu" src="'.$trofeu_1.'"> '.apply_filters('str_from_lang','2ª Classificatória','2da Clasificación'),
                    'Semifinal' => '<img id="trofeu" src="'.$trofeu_1.'"> '.apply_filters('str_from_lang','Semifinal','Semifinal'),
                    'Final' => '<img id="trofeu" src="'.$trofeu_1.'"> '.apply_filters('str_from_lang','Final','Final'),
              ),
            // 'show_on_cb' => 'show_if_is_administrator',
          ) );
          /////////////////////// Fim Blocos troféis

          /////////////////////// Início 3ª Orientativa
            $cmb_group = new_cmb2_box( array(
              'id'           => 'grupos_infos_3_orientativa_' . $ano . '_' . $term->slug,
              'title'        => apply_filters('str_from_lang', $_orientativa_3_texto . ' <span id="expand-warning">(Clique para expandir/ocultar)</span>','3ra Orientación <span id="expand-warning">(Haga clic para expandir/ocultar)</span>'),
              'object_types' => array( 'grupos_' . $ano . '_' . $term->slug ),
              'show_on_cb' => 'show_if_is_3_orientativa_only',
              // Fecha abas apenas para comissão
              'closed' => (!current_user_can('comissao') ? false : true),
            ) );

              ## CAMPOS 3ª ORIENTATIVA 
              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang', $_orientativa_3_texto . ' - Verifique todos os campos pendentes abaixo','3ra Orientación - Verifique todos los campos pendientes abajo'),
                'id'   => 'grupos_infos_3_orientativa_title_1_' . $ano . '_' . $term->slug,
                'type'    => 'title',
                'attributes' => 'style=text-align: center;font-style: italic;font-size: 16px;padding: 0px 0px 12px 0px;margin: 0px;',
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','A causa do problema está relacionada a qual fator?','¿Qué factor está relacionado con la causa del problema?'),
                'id'   => 'grupos_infos_3_orientativa_fator_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'desc' => apply_filters('str_from_lang','Campo da ' . $_orientativa_3_texto,'Campo de la 3ra orientación'),
                'show_on_cb' => 'show_if_is_3_orientativa_only',
                'options' => array(
                  ''  =>  apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  'Máquina' => apply_filters('str_from_lang','Máquina','Máquina'),
                  'Método' => apply_filters('str_from_lang','Método','Método'),
                  'Mão de obra' => apply_filters('str_from_lang','Mão de obra','Mano de obra'),
                  'Material' => apply_filters('str_from_lang','Material','Material'),
                  'Meio Ambiente' => apply_filters('str_from_lang','Meio Ambiente','Medio ambiente'),
                  'Medida' => apply_filters('str_from_lang','Medida','Medida'),
                )
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Objetivo','Objetivo'),
                'id'   => 'grupos_infos_3_orientativa_objetivo_' . $ano . '_' . $term->slug,
                'type'    => 'text',
                'desc' => apply_filters('str_from_lang','Campo da ' . $_orientativa_3_texto,'Campo de la 3ra orientación'),
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Seu tema de custos foi homologado no PLI?','Tu tema de costos ha sido aprobado en el PLI?'),
                'id'   => 'grupos_infos_3_orientativa_custo_pli_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'options' => array(
                  '' => apply_filters('str_from_lang','Escolha uma opção','Escoge una opción'),
                  'Sim' => apply_filters('str_from_lang','Sim','Sí'),
                  'Não' => apply_filters('str_from_lang','Não','No'),
                ),
                'desc' => apply_filters('str_from_lang','Campo da ' . $_orientativa_3_texto,'Campo de la 3ra orientación'),
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Seu tema de meio ambiente foi homologado no PLA?','Tu tema ambiental ha sido aprobado en el PLA'),
                'id'   => 'grupos_infos_3_orientativa_ambiente_pla_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'options' => array(
                  '' => apply_filters('str_from_lang','Escolha uma opção','Escoge una opción'),
                  'Sim' => apply_filters('str_from_lang','Sim','Sí'),
                  'Não' => apply_filters('str_from_lang','Não','No'),
                ),
                'desc' => apply_filters('str_from_lang','Campo da ' . $_orientativa_3_texto,'Campo de la 3ra orientación'),
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Situação atual','Situación actual'),
                'id'   => 'grupos_infos_3_orientativa_situacao_atual_' . $ano . '_' . $term->slug,
                'type'    => 'text',
                'desc' => apply_filters('str_from_lang','Ex: 10 peças por dia ou 10 minutos por dia','Ej: 10 piezas al día o 10 minutos al día'),
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Meta planejada','Meta planificada'),
                'id'   => 'grupos_infos_3_orientativa_meta_planejada_' . $ano . '_' . $term->slug,
                'type'    => 'text',
                'desc' => apply_filters('str_from_lang','Ex: 1 peça por dia ou 1 minuto por dia','Ej: 1 pieza al día o 1 minuto al día'),
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Prazo para execução da solução','Plazo de ejecución de la solución'),
                'id'   => 'grupos_infos_3_orientativa_prazo_execucao_' . $ano . '_' . $term->slug,
                'type'    => 'text_date',
                'desc' => apply_filters('str_from_lang','dd-mm-aaaa','dd-mm-aaaa'),
                'date_format' => 'd-m-Y',
                'show_on_cb' => 'show_if_is_3_orientativa_only',
                // Inicio traducao
                'attributes' => array(
                  // CMB2 checks for datepicker override data here:
                  'data-datepicker' => json_encode( array(
                    'dayNames' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa')
                      
                    ),
                    'dayNamesMin' => array(
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa')
                    ),
                    'monthNamesShort' => explode( ',',
                      apply_filters('str_from_lang','Jan','En') . ',' .
                      apply_filters('str_from_lang','Fev','Feb') . ',' .
                      apply_filters('str_from_lang','Mar','Mar') . ',' .
                      apply_filters('str_from_lang','Abr','Abr') . ',' .
                      apply_filters('str_from_lang','Mai','May') . ',' .
                      apply_filters('str_from_lang','Jun','Jun') . ',' .
                      apply_filters('str_from_lang','Jul','Jul') . ',' .
                      apply_filters('str_from_lang','Ago','Ago') . ',' .
                      apply_filters('str_from_lang','Set','Sept') . ',' .
                      apply_filters('str_from_lang','Out','Oct') . ',' .
                      apply_filters('str_from_lang','Nov','Nov') . ',' .
                      apply_filters('str_from_lang','Dez','Dic')
                    ),
                    // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                    // 'maxDate' => '+1m',
                  ) ),                
                ),
                // Fim traducao
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','É necessário investimento?','¿Es necesaria la inversión?'),
                'id'   => 'grupos_infos_3_orientativa_investimento_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'desc' => apply_filters('str_from_lang','Caso a resposta seja "Sim", informar o valor abaixo','Si la respuesta es "Sí", informar el valor en el campo de abajo'),
                'show_on_cb' => 'show_if_is_3_orientativa_only',
                'options' => array(
                  ''  =>  apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  'Não' => apply_filters('str_from_lang','Não','No'),
                  'Sim' => apply_filters('str_from_lang','Sim','Sí'),
                ),
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Valor do investimento','Valor de la inversión'),
                'id'   => 'grupos_infos_3_orientativa_investimento_valor_' . $ano . '_' . $term->slug,
                'type'    => 'text_small',
                'classes' => 'investimento_mask',
                'desc' => apply_filters('str_from_lang','Digite o valor','Introduzca el valor'),
                'show_on_cb' => 'show_if_is_3_orientativa_only',
                'attributes' => array(
                  'placeholder' => apply_filters('str_from_lang','R$','$'),
                ),
              ) );

              $cmb_group->add_field( array(
                'name'       => apply_filters('str_from_lang','Confirma a ' . $_orientativa_3_texto . '?','¿Confirma la 3ra orientación?'),
                'id'         => 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'options' => array(
                  ''  =>  apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  'Não' => apply_filters('str_from_lang','Não','No'),
                  'Sim' => apply_filters('str_from_lang','Sim','Sí'),
                ),
                'show_on_cb' => 'show_if_is_3_orientativa_only'
              ) );

              ## FIM CAMPOS 3ª ORIENTATIVA
          /////////////////////// Fim 3ª Orientativa

          /////////////////////// Início 2ª Orientativa
            $cmb_group = new_cmb2_box( array(
              'id'           => 'grupos_infos_2_orientativa_' . $ano . '_' . $term->slug,
              'title'        => apply_filters('str_from_lang','2ª Orientativa <span id="expand-warning">(Clique para expandir/ocultar)</span>','2da Orientación <span id="expand-warning">(Haga clic para expandir/ocultar)</span>'),
              'object_types' => array( 'grupos_' . $ano . '_' . $term->slug ),
              'show_on_cb' => 'show_if_is_2_orientativa_only',
              // Fecha abas apenas para comissão
              'closed' => (!current_user_can('comissao') ? false : true),
            ) );

              ## CAMPOS 2ª ORIENTATIVA 
                $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','2ª Orientativa - Verifique todos os campos pendentes abaixo','2da Orientación - Verifique todos los campos pendientes abajo'),
                'id'   => 'grupos_infos_2_orientativa_title_1_' . $ano . '_' . $term->slug,
                'type'    => 'title',
                'attributes' => 'style=text-align: center;font-style: italic;font-size: 16px;padding: 0px 0px 12px 0px;margin: 0px;',
                'show_on_cb' => 'show_if_is_2_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Turno do apresentador','Turno del presentador'),
                'id'   => 'grupos_infos_2_orientativa_turno_apresentador_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'desc' => apply_filters('str_from_lang','Campo da 2ª orientativa','Campo de la 2da orientación'),
                'options' => array(
                  '' => apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  '1-turno' => apply_filters('str_from_lang','1º Turno','1er Turno'),
                  '2-turno' => apply_filters('str_from_lang','2º Turno','2do Turno'),
                  '3-turno' => apply_filters('str_from_lang','3º Turno','3er Turno'),
                  'adm' => apply_filters('str_from_lang','Adm','Adm'),                
                  'especial' => apply_filters('str_from_lang','Especial','Especial'),
                  //'LIC' => 'LIC',
                ),
                'show_on_cb' => 'show_if_is_2_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Tema','Tema'),
                'id'   => 'grupos_infos_2_orientativa_tema_' . $ano . '_' . $term->slug,
                'type'    => 'text',
                'desc' => apply_filters('str_from_lang','Campo da 2ª orientativa','Campo de la 2da orientación'),
                'show_on_cb' => 'show_if_is_2_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Categoria','Categoría'),
                'id'   => 'grupos_infos_2_orientativa_categoria_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'desc' => apply_filters('str_from_lang','Campo da 2ª orientativa','Campo de la 2da orientación'),
                'options' => array(
                  '' => apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  'Custo' => apply_filters('str_from_lang','Custo','Costo'),
                  'Qualidade' => apply_filters('str_from_lang','Qualidade','Calidad'),
                  'Eficiência' => apply_filters('str_from_lang','Eficiência','Eficiencia'),
                  'Meio Ambiente' => apply_filters('str_from_lang','Meio Ambiente','Medio ambiente'),
                  'Segurança' => apply_filters('str_from_lang','Segurança','Seguridad'),
                ),
                'show_on_cb' => 'show_if_is_2_orientativa_only'
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Análise de situação','Análisis de la situación'),
                'id'   => 'grupos_infos_2_orientativa_analise_situacao_' . $ano . '_' . $term->slug,
                'type'    => 'text_date',
                'desc' => apply_filters('str_from_lang','dd-mm-aaaa','dd-mm-aaaa'),
                'date_format' => 'd-m-Y',
                'show_on_cb' => 'show_if_is_2_orientativa_only',
                // Inicio traducao
                'attributes' => array(
                  // CMB2 checks for datepicker override data here:
                  'data-datepicker' => json_encode( array(
                    'dayNames' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa') 
                      
                    ),
                    'dayNamesMin' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa')
                      
                    ),
                    'monthNamesShort' => explode( ',',
                      apply_filters('str_from_lang','Jan','En') . ',' .
                      apply_filters('str_from_lang','Fev','Feb') . ',' .
                      apply_filters('str_from_lang','Mar','Mar') . ',' .
                      apply_filters('str_from_lang','Abr','Abr') . ',' .
                      apply_filters('str_from_lang','Mai','May') . ',' .
                      apply_filters('str_from_lang','Jun','Jun') . ',' .
                      apply_filters('str_from_lang','Jul','Jul') . ',' .
                      apply_filters('str_from_lang','Ago','Ago') . ',' .
                      apply_filters('str_from_lang','Set','Sept') . ',' .
                      apply_filters('str_from_lang','Out','Oct') . ',' .
                      apply_filters('str_from_lang','Nov','Nov') . ',' .
                      apply_filters('str_from_lang','Dez','Dic')
                    ),
                    // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                    // 'maxDate' => '+1m',
                  ) ),                
                ),
                // Fim traducao
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Análise de causas','Análisis de causa'),
                'id'   => 'grupos_infos_2_orientativa_analise_causas_' . $ano . '_' . $term->slug,
                'type'    => 'text_date',
                'desc' => apply_filters('str_from_lang','dd-mm-aaaa','dd-mm-aaaa'),
                'date_format' => 'd-m-Y',
                'show_on_cb' => 'show_if_is_2_orientativa_only',
                // Inicio traducao
                'attributes' => array(
                  // CMB2 checks for datepicker override data here:
                  'data-datepicker' => json_encode( array(
                    'dayNames' => array(
                      apply_filters('str_from_lang','Dom','Do'), 
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa')
                      
                    ),
                    'dayNamesMin' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa')
                      
                    ),
                    'monthNamesShort' => explode( ',',
                      apply_filters('str_from_lang','Jan','En') . ',' .
                      apply_filters('str_from_lang','Fev','Feb') . ',' .
                      apply_filters('str_from_lang','Mar','Mar') . ',' .
                      apply_filters('str_from_lang','Abr','Abr') . ',' .
                      apply_filters('str_from_lang','Mai','May') . ',' .
                      apply_filters('str_from_lang','Jun','Jun') . ',' .
                      apply_filters('str_from_lang','Jul','Jul') . ',' .
                      apply_filters('str_from_lang','Ago','Ago') . ',' .
                      apply_filters('str_from_lang','Set','Sept') . ',' .
                      apply_filters('str_from_lang','Out','Oct') . ',' .
                      apply_filters('str_from_lang','Nov','Nov') . ',' .
                      apply_filters('str_from_lang','Dez','Dic')
                    ),
                    // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                    // 'maxDate' => '+1m',
                  ) ),                
                ),
                // Fim traducao
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Objetivos e metas','Objetivos y metas'),
                'id'   => 'grupos_infos_2_orientativa_obj_metas_' . $ano . '_' . $term->slug,
                'type'    => 'text_date',
                'desc' => apply_filters('str_from_lang','dd-mm-aaaa','dd-mm-aaaa'),
                'date_format' => 'd-m-Y',
                'show_on_cb' => 'show_if_is_2_orientativa_only',
                // Inicio traducao
                'attributes' => array(
                  // CMB2 checks for datepicker override data here:
                  'data-datepicker' => json_encode( array(
                    'dayNames' => array( 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa'), 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu')
                    ),
                    'dayNamesMin' => array( 
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa'), 
                      apply_filters('str_from_lang','Dom','Do')
                    ),
                    'monthNamesShort' => explode( ',',
                      apply_filters('str_from_lang','Jan','En') . ',' .
                      apply_filters('str_from_lang','Fev','Feb') . ',' .
                      apply_filters('str_from_lang','Mar','Mar') . ',' .
                      apply_filters('str_from_lang','Abr','Abr') . ',' .
                      apply_filters('str_from_lang','Mai','May') . ',' .
                      apply_filters('str_from_lang','Jun','Jun') . ',' .
                      apply_filters('str_from_lang','Jul','Jul') . ',' .
                      apply_filters('str_from_lang','Ago','Ago') . ',' .
                      apply_filters('str_from_lang','Set','Sept') . ',' .
                      apply_filters('str_from_lang','Out','Oct') . ',' .
                      apply_filters('str_from_lang','Nov','Nov') . ',' .
                      apply_filters('str_from_lang','Dez','Dic')
                    ),
                    // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                    // 'maxDate' => '+1m',
                  ) ),                
                ),
                // Fim traducao
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Estudos e implantação','Estudios y implementación'),
                'id'   => 'grupos_infos_2_orientativa_est_imp_' . $ano . '_' . $term->slug,
                'type'    => 'text_date',
                'desc' => apply_filters('str_from_lang','dd-mm-aaaa','dd-mm-aaaa'),
                'date_format' => 'd-m-Y',
                'show_on_cb' => 'show_if_is_2_orientativa_only',
                // Inicio traducao
                'attributes' => array(
                  // CMB2 checks for datepicker override data here:
                  'data-datepicker' => json_encode( array(
                    'dayNames' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa')
                      
                    ),
                    'dayNamesMin' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa') 
                      
                    ),
                    'monthNamesShort' => explode( ',',
                      apply_filters('str_from_lang','Jan','En') . ',' .
                      apply_filters('str_from_lang','Fev','Feb') . ',' .
                      apply_filters('str_from_lang','Mar','Mar') . ',' .
                      apply_filters('str_from_lang','Abr','Abr') . ',' .
                      apply_filters('str_from_lang','Mai','May') . ',' .
                      apply_filters('str_from_lang','Jun','Jun') . ',' .
                      apply_filters('str_from_lang','Jul','Jul') . ',' .
                      apply_filters('str_from_lang','Ago','Ago') . ',' .
                      apply_filters('str_from_lang','Set','Sept') . ',' .
                      apply_filters('str_from_lang','Out','Oct') . ',' .
                      apply_filters('str_from_lang','Nov','Nov') . ',' .
                      apply_filters('str_from_lang','Dez','Dic')
                    ),
                    // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                    // 'maxDate' => '+1m',
                  ) ),                
                ),
                // Fim traducao
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Análise dos resultados','Análisis de los resultados'),
                'id'   => 'grupos_infos_2_orientativa_analise_result_' . $ano . '_' . $term->slug,
                'type'    => 'text_date',
                'desc' => apply_filters('str_from_lang','dd-mm-aaaa','dd-mm-aaaa'),
                'date_format' => 'd-m-Y',
                'show_on_cb' => 'show_if_is_2_orientativa_only',
                // Inicio traducao
                'attributes' => array(
                  // CMB2 checks for datepicker override data here:
                  'data-datepicker' => json_encode( array(
                    'dayNames' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa') 
                      
                    ),
                    'dayNamesMin' => array( 
                      apply_filters('str_from_lang','Dom','Do'),
                      apply_filters('str_from_lang','Seg','Lu'), 
                      apply_filters('str_from_lang','Ter','Ma'), 
                      apply_filters('str_from_lang','Qua','Mi'), 
                      apply_filters('str_from_lang','Qui','Ju'), 
                      apply_filters('str_from_lang','Sex','Vi'), 
                      apply_filters('str_from_lang','Sab','Sa') 
                      
                    ),
                    'monthNamesShort' => explode( ',',
                      apply_filters('str_from_lang','Jan','En') . ',' .
                      apply_filters('str_from_lang','Fev','Feb') . ',' .
                      apply_filters('str_from_lang','Mar','Mar') . ',' .
                      apply_filters('str_from_lang','Abr','Abr') . ',' .
                      apply_filters('str_from_lang','Mai','May') . ',' .
                      apply_filters('str_from_lang','Jun','Jun') . ',' .
                      apply_filters('str_from_lang','Jul','Jul') . ',' .
                      apply_filters('str_from_lang','Ago','Ago') . ',' .
                      apply_filters('str_from_lang','Set','Sept') . ',' .
                      apply_filters('str_from_lang','Out','Oct') . ',' .
                      apply_filters('str_from_lang','Nov','Nov') . ',' .
                      apply_filters('str_from_lang','Dez','Dic')
                    ),
                    // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                    // 'maxDate' => '+1m',
                  ) ),                
                ),
                // Fim traducao
              ) );

              $cmb_group->add_field( array(
                'name'       => apply_filters('str_from_lang','Confirma a 2ª orientativa?','¿Confirma la 2da orientación?'),
                'id'         => 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'options' => array(
                  ''  =>  apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  'Não' => apply_filters('str_from_lang','Não','No'),
                  'Sim' => apply_filters('str_from_lang','Sim','Sí'),
                ),
                'show_on_cb' => 'show_if_is_2_orientativa_only'
              ) );

              ## FIM CAMPOS 2ª ORIENTATIVA
          /////////////////////// Fim 2ª Orientativa

          /////////////////////// Início 1ª Orientativa
            $cmb_group = new_cmb2_box( array(
              'id'           => 'grupos_infos_1_orientativa_' . $ano . '_' . $term->slug,
              'title'        => apply_filters('str_from_lang','1ª Orientativa <span id="expand-warning">(Clique para expandir/ocultar)</span>','1ra Orientación <span id="expand-warning">(Haga clic para expandir/ocultar)</span>'),
              'object_types' => array( 'grupos_' . $ano . '_' . $term->slug ),
              'show_on_cb' => 'show_if_is_1_orientativa_only',
              // Fecha abas apenas para comissão
              'closed' => (!current_user_can('comissao') ? false : true),
            ) );

              ## CAMPOS 1ª ORIENTATIVA 

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','1ª Orientativa','1ra Orientación'),
                'id'   => 'grupos_infos_1_orientativa_title_1_' . $ano . '_' . $term->slug,
                'type'    => 'title',
                'attributes' => 'style=text-align: center;font-style: italic;font-size: 16px;padding: 0px 0px 12px 0px;margin: 0px;',
                'show_on_cb' => 'show_if_is_1_orientativa_only'
              ) );  

              $cmb_group->add_field( array(
                'name'       => apply_filters('str_from_lang','Confirma a 1ª orientativa?','¿Confirma la 1ra orientación?'),
                'id'         => 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'options' => array(
                  ''  =>  apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                  'Não' => apply_filters('str_from_lang','Não','No'),
                  'Sim' => apply_filters('str_from_lang','Sim','Sí'),
                ),
                'show_on_cb' => 'show_if_is_1_orientativa_only'
              ) );

              ## FIM CAMPOS 1ª ORIENTATIVA
          /////////////////////// Fim 1ª Orientativa

          /////////////////////// INSCRIÇÕES
            $cmb_group = new_cmb2_box( array(
              'id'           => 'grupos_infos_' . $ano . '_' . $term->slug,
              'title'        => apply_filters('str_from_lang','Inscrições <span id="expand-warning">(Clique para expandir/ocultar)</span>','Inscripciones <span id="expand-warning">(Haga clic para expandir/ocultar)</span>'),
              'object_types' => array( 'grupos_' . $ano . '_' . $term->slug ),
              'rows_limit'   => 5, // custom attribute to use in our JS
              'groupId' => 'grupos_integrantes_' . $ano . '_' . $term->slug,
              'show_on_cb' => 'show_if_is_1_orientativa_or_inscricao',
              // Fecha abas apenas para comissão
              'closed' => (!current_user_can('comissao') ? false : true),
            ) );    

            ///////////// CAMPOS INSCRIÇÕES
              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Inscrições - Campos principais','Inscripciones - Campos principales'),
                'id'   => 'grupos_infos_inscricoes_title_1_' . $ano . '_' . $term->slug,
                'type'    => 'title',
                'attributes' => 'style=text-align: center;font-style: italic;font-size: 16px;padding: 0px 0px 12px 0px;margin: 0px;',
              ) );
              
              /* Campo oculto com CSS para HSA | functions-css-nao-administradores.php */
              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Orientador(a)','Tutor(a)'),
                'id'   => 'grupos_infos_orientador_' . $ano . '_' . $term->slug,
                //'desc'       => '<b>IMPORTANTE:</b> Caso o nome do(a) orientador(a) não apareça, significa que já faz parte de 3 grupos<br>Campo obrigatório para finalização',
                'type'    => 'pw_select',
                'classes' => array('role_is_orientador','nome_orientador_js'),
                /*'attributes' => array(
                    // 'required' => 'required',
                    // 'placeholder' => ' ',
                    // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),*/
                'column' => array(
                  'position' => 2,
                  'name' => 'Orientador',
                ),
                'display_cb' => 'display_coluna_orientador',
                'options_cb' => 'get_list_users_select_orientador',
              ) );              
                            
              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Confirmação do orientador','Confirmación del tutor'),
                'desc' => apply_filters('str_from_lang','Atenção! Essa confirmação será feita pelo orientador antes de aplicar as alterações no grupo, não mexa nesse campo ao menos que seja realmente necessário e o orientador esteja ciente que você estará realizando essa confirmação por ele.','¡Aviso! Esta confirmación la realizará el tutor antes de aplicar los cambios en el grupo, no modifiques este campo a menos que sea realmente necesario y el tutor sepa que realizarás esta confirmación por él.'),
                'id'   => 'grupos_infos_orientador_check_' . $ano . '_' . $term->slug,
                'show_on_cb' => 'box_for_adm_comissao',
                'type'    => 'checkbox',
              ) );


              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Categoria','categoría'),
                'desc' => apply_filters('str_from_lang','Selecione a categoria que deseja participar:(lembrando que 50% dos prêmios serão para as categorias de Transformação digital, Tripla ação para zero e Segurança no trânsito e os outros 50% dos prêmios para categoria de QCDMS)','(Recuerda que el 50% de los premios se destinará a las categorías de Transformación digital, Triple acción hacia cero y Seguridad vial, y el otro 50% de los premios a la categoría de QCDMS).'),
                'id'   => 'categorias_grupos_infos_orientador' . $ano . '_' . $term->slug,
                'show_on_cb' => 'show_only_for_hsa',
                'type'    => 'select',
                'show_option_none' => true,
                'default'          => 'custom',
                'options'          => array(
                  'transformacao-digital' => __( 'Transformação digital', 'cmb2' ),
                  'seguranca-no-transito'   => __( 'Segurança no trânsito', 'cmb2' ),
                  'tripla-acao-para-zero'     => __( 'Tripla ação para zero', 'cmb2' ),
                  'qcdms-(melhoria-de-processos)'     => __( 'QCDMS (melhoria de processos)', 'cmb2' ),
                ),
              ) );

              $cmb_group->add_field( array(
                'name' => apply_filters('str_from_lang','Orientador(a)','Tutor(a)'),
                'id'   => 'temp_grupos_infos_orientador_' . $ano . '_' . $term->slug,
                'desc'       => '<b>OBS:</b> O orientador deve ser alguém que tenha conhecimento e vivência no NHC, ou seja, deve ter participado de edições anteriores.',
                'type'    => 'text',
                'show_on_cb' => 'show_only_for_hsa',
              ) );

              $cmb_group->add_field( array(
                'name'       => apply_filters('str_from_lang','Sexo do(a) orientador(a)','Género del tutor(a)'),
                'id'         => 'grupos_infos_orientador_sexo_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'classes_cb' => 'box3',
                'classes' => 'role_is_orientador',
                'options' => array(
                  'masculino' => apply_filters('str_from_lang','Masculino','Masculino'),
                  'feminino' => apply_filters('str_from_lang','Feminino','Femenino')
                ),
                'attributes' => array(
                  // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),
                'show_on_cb' => 'empresas_para_limitar_sexo_camisa'
                /*'column' => array(
                  'position' => 1,
                  'name'     => 'Cliente',
                ),*/
              ) );          

              $cmb_group->add_field( array(
                'name'       => apply_filters('str_from_lang','Camiseta do(a) orientador(a)','Camiseta del tutor(a)'),
                'id'         => 'grupos_infos_orientador_camiseta_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'classes' => 'role_is_orientador',
                'options' => array(
                  'pp' => apply_filters('str_from_lang','PP','PP'),
                  'p' => apply_filters('str_from_lang','P','P'),
                  'm' => apply_filters('str_from_lang','M','M'),
                  'g' => apply_filters('str_from_lang','G','G'),
                  'gg' => apply_filters('str_from_lang','GG','XG'),
                  'egg' => apply_filters('str_from_lang','EGG','EXG'),
                ),
                'attributes' => array(
                  // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),
                'show_on_cb' => 'empresas_para_limitar_sexo_camisa'
              ) );

              // $group_field_id is the field id string, so in this case: $prefix . 'demo'
              $group_field_id = $cmb_group->add_field( array(
                'id'          => 'grupos_integrantes_' . $ano . '_' . $term->slug,
                'type'        => 'group',
                'description' => apply_filters('str_from_lang','O grupo deve conter no mínimo 3 integrantes e no máximo 5','El grupo debe contener un mínimo de 3 miembros y un máximo de 5'),
                'options'     => array(
                  'group_title'    => apply_filters('str_from_lang','Integrante #{#}','Miembro #{#}'), // {#} gets replaced by row number
                  'add_button'     => apply_filters('str_from_lang','Adicionar integrante','Añadir miembro'),
                  'remove_button'  => apply_filters('str_from_lang','Remover integrante','Eliminar miembro'),
                  'sortable'       => false,
                  'closed'      => true, // true to have the groups closed by default
                  'remove_confirm' => apply_filters('str_from_lang','Deseja realmente remover este integrante?','¿Realmente desea eliminar a este miembro?'), // Performs confirmation before removing group.
                ),
              ) );

              $cmb_group->add_group_field( $group_field_id, array(
                'name'       => apply_filters('str_from_lang','Nome','Nombre'),
                'desc'       => apply_filters('str_from_lang','<b>IMPORTANTE:</b> Membros que já estão em grupos não podem ser selecionados novamente','<b>IMPORTANTE:</b> Los miembros que ya están en grupos no se pueden volver a seleccionar'),
                'id'         => 'grupos_integrantes_nome_' . $ano . '_' . $term->slug,
                'type'    => 'pw_select',
                'options_cb' => 'get_list_users_select_membros',
                'classes' => array('role_is_orientador','nome_integrante_js'),
                'attributes'  => array(
                  // 'required' => 'required',
                  'autocomplete' => 'off',
                  'placeholder' => ' ',
                  // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),
                /*'column' => array(
                  'position' => 1,
                  'name'     => 'Cliente',
                ),*/
              ) );

              $cmb_group->add_group_field( $group_field_id, array(
                'name'       => apply_filters('str_from_lang','Setor','Sector'),
                'id'         => 'grupos_integrantes_setor_' . $ano . '_' . $term->slug,
                'type'       => 'text',
                'desc'       => apply_filters('str_from_lang','Campo de inscrição. Este valor não pode ser editado manualmente. <br>Valor relativo ao integrante selecionado.','Campo de Inscripción. Este valor no se puede editar manualmente. <br>Valor relativo al miembro seleccionado.'),
                'classes_cb' => 'setor_integrante_js',
                'attributes'  => array(
                  // 'readonly' => 'readonly',
                  // 'disabled' => 'disabled',
                  // 'required' => 'required',
                  'style' => 'pointer-events: none;opacity: 0.7;',
                  // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),
              ) );

              ////////////// CAMPO 1ª ORIENTATIVA 

                $cmb_group->add_group_field( $group_field_id, array(
                  'name'       => apply_filters('str_from_lang','Função','Rol del miembro'),
                  'id'         => 'grupos_integrantes_funcao_' . $ano . '_' . $term->slug,
                  'type'    => 'select',
                  'desc' => apply_filters('str_from_lang','Campo da 1ª orientativa','Campo de la 1ra orientación'),
                  'classes_cb' => 'box3',
                  'classes_cb' => 'funcao_integrante_js',
                  'options' => array(
                    '' => apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
                    'Líder' => apply_filters('str_from_lang','Líder','Líder'),
                    'Apresentador' => apply_filters('str_from_lang','Apresentador','Presentador'),
                    'Secretário' => apply_filters('str_from_lang','Secretário','Secretario'),
                    'Membro' => apply_filters('str_from_lang','Membro','Miembro'),
                  ),
                  'show_on_cb' => 'show_if_is_1_orientativa_only'
                ) );

                
              ////////////// FIM CAMPO 1ª ORIENTATIVA 

              $cmb_group->add_group_field( $group_field_id, array(
                'name'       => apply_filters('str_from_lang','Sexo','Género'),
                'id'         => 'grupos_integrantes_sexo_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'classes_cb' => 'box3',
                'classes' => 'role_is_orientador',
                'options' => array(
                  'masculino' => apply_filters('str_from_lang','Masculino','Masculino'),
                  'feminino' => apply_filters('str_from_lang','Feminino','Femenino')
                ),
                'attributes' => array(
                  // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),
                'show_on_cb' => 'empresas_para_limitar_sexo_camisa'
                /*'column' => array(
                  'position' => 1,
                  'name'     => 'Cliente',
                ),*/
              ) );

              $cmb_group->add_group_field( $group_field_id, array(
                'name'       => apply_filters('str_from_lang','Camiseta','Camiseta'),
                'id'         => 'grupos_integrantes_camiseta_' . $ano . '_' . $term->slug,
                'type'    => 'select',
                'classes' => 'role_is_orientador',
                'options' => array(
                  'pp' => apply_filters('str_from_lang','PP','PP'),
                  'p' => apply_filters('str_from_lang','P','P'),
                  'm' => apply_filters('str_from_lang','M','M'),
                  'g' => apply_filters('str_from_lang','G','G'),
                  'gg' => apply_filters('str_from_lang','GG','XG'),
                  'egg' => apply_filters('str_from_lang','EGG','EXG'),
                ),
                'show_on_cb' => 'empresas_para_limitar_sexo_camisa',
                'attributes' => array(
                  // 'disabled'    => (in_array($current_user_id, $auth_user_ids) ? false : true),
                ),
              ) );

            ///////////// FIM CAMPOS INSCRIÇÕES
          ///////////// FIM INSCRIÇÕES

        } // End IF term

    } // End foreach

    /////////////////////// TODAS AS FUNCOES SHOW_ON FORA DO LOOP

    function display_coluna_orientador($field_args, $field) {
      if($field->escaped_value()) {
        echo get_user_meta($field->escaped_value(), 'first_name', true);
      }
    }

    ////////////////////// REMOVE SEXO E CAMISA
    function empresas_para_limitar_sexo_camisa() { 
      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);             

      if($user_empresa != 'hsa') {
        return true;
      }
    }

    ////////////////////// MOSTRA CAMPOS APENAS PARA HSA
    function show_only_for_hsa() { 
      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);   

      if($user_empresa == 'hsa' || current_user_can('administrator')) {
        return true;
      }
    }


    // Exibe box de troféis apenas para comissão e administrator
    function box_for_adm_comissao() {
      if(current_user_can('administrator') || current_user_can('comissao')) {
        return true;
      }
    }

    function show_if_is_coordenador_above() {
      if(current_user_can('administrator') || current_user_can('comissao') || current_user_can('coordenador')) {
        return true;
      }
    } 

    function show_if_is_administrator() {
      return current_user_can('administrator');
    }

    function show_if_is_comissao() {
      if(current_user_can('administrator') || current_user_can('comissao')) {
        return true;
      }
    } 

    ///////////// LISTA MEMBROS
    function get_list_users_select_membros() {

    //// PEGA OS MEMBROS JÁ CADASTRADOS

    /////////////// ANO VIGENTE ///////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
    /////////////// ANO VIGENTE ///////////////

    $posts = get_posts(
          array(
              'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
              'posts_per_page' => -1,
          )
      );

    $integrantes = array();

      // Visita cada grupo
      foreach( $posts as $post ) {

        $current_post_id = $_GET['post'];

        // É o grupo atual aberto na pág do admin, mantém os membros que foram selecionados
        if($current_post_id == $post->ID) {

          // Nada acontece

        }

        // Não é o grupo aberto sendo editado, remover membros já cadastrados em outros grupos
        else {

          $integrantes_loop = get_post_meta( $post->ID, 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );

          // Pega os 5 campos de nomes dos grupos
          $integrantes[] = $integrantes_loop[0]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
          $integrantes[] = $integrantes_loop[1]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
          $integrantes[] = $integrantes_loop[2]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
          $integrantes[] = $integrantes_loop[3]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
          $integrantes[] = $integrantes_loop[4]['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];

        }

      }
      
      //////// SELECIONAR O MEMBRO
      /*
      Essa versão foi ignorada e foi utilizado o array_merge pois o get_users nao suporta array de mais roles em 'role =>'
      $args = array(
        'role' => 'membro'
      ); */

      $args_1 = array(
        'role' => 'membro',
        'orderby' => 'meta_value',
        'meta_key' => 'first_name',
        'order' => 'ASC'
      );

      /////////// SE NAO FOR ADMINISTRATOR, RESTRINGIR PARA LISTA MESMA EMPRESA
      if( !current_user_can('administrator') )
        $args_1['meta_query'][] = array(
          'key' => 'user_infos_empresas',
          'value' => get_user_meta(get_current_user_id(), 'user_infos_empresas', true),
          'compare' => '=='
      );
      /////////// FIM

      $args_2 = array(
        'role' => 'membro-coordenador',
        'orderby' => 'meta_value',
        'meta_key' => 'first_name',
        'order' => 'ASC'
      );

      /////////// SE NAO FOR ADMINISTRATOR, RESTRINGIR PARA LISTA MESMA EMPRESA
      if( !current_user_can('administrator') )
        $args_2['meta_query'][] = array(
          'key' => 'user_infos_empresas',
          'value' => get_user_meta(get_current_user_id(), 'user_infos_empresas', true),
          'compare' => '=='
      );
      /////////// FIM      

      $clientes = array_merge( get_users($args_1), get_users($args_2) );
      $list_users = [];

      // Pega a listagem de membros
      foreach ($clientes as $cliente) :
        $list_users[$cliente->data->ID] = $cliente->first_name . ' - ' . $cliente->user_login ;
      endforeach;

      // Antes de retornar a lista de membros,
      // remove os que já foram cadastrados e identificados pelo loop acima
      foreach($integrantes as $membro) {
        // Essa linha abaixo remove usuários da listagem (usuários que já estão em outros grupos)
        // unset($list_users[$membro]);

         // Os comandos abaixo mantém os usuários, apenas os deixa inclicáveis
         // Um script para desativá-los foi adicionado no arquivo inc/funcoes-validacoes-grupos.php
         $membro_infos = get_user_by( 'id', $membro );
         $membro_matricula = $membro_infos->user_login;
         // Antes de adicionar a tag [já em um grupo], verifica se o membro verificado não tem uma matricula vazia (select2 estava adicionando uma última tag vazia e nao entendi porque, essa verificação concertou)
         if(!empty($membro_matricula)) {
          $list_users[$membro] = apply_filters('str_from_lang','[Já em um grupo] ','[Ya en un grupo] ') . mb_strimwidth(get_user_meta($membro, 'first_name', true), 0, 15, "...") . ' - ' . $membro_matricula;
         }         
      }
      return $list_users;

      wp_reset_postdata();

    }
    ///////////// FIM LISTA MEMBROS

    ///////////// LISTA ORIENTADORES
    function get_list_users_select_orientador() {

    //// PEGA OS ORIENTADORES JÁ CADASTRADOS

    /////////////// ANO VIGENTE ///////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
    /////////////// ANO VIGENTE ///////////////

    $posts = get_posts(
          array(
              'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
              'posts_per_page' => -1,
          )
      );

    $orientadores_posts = array();

      // Visita cada grupo
      foreach( $posts as $post ) {

        $current_post_id = $_GET['post'];

        // É o grupo atual aberto na pág do admin, mantém os orientadores que foram selecionados
        if($current_post_id == $post->ID) {

          // Nada acontece

        }

        // Não é o grupo aberto sendo editado, remover orientadores já cadastrados mais de 3 vezes em outros grupos
        else {

          // Salva os orientadores
          $orientadores_posts[] = get_post_meta( $post->ID, 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );

        }

      }
      
      // Verificação de quais repetem até 3 vezes
      // código aqui

      //////// SELECIONAR O ORIENTADOR
      $args = array(
        'role' => 'orientador',
        'orderby' => 'meta_value',
        'meta_key' => 'first_name',
        'order' => 'ASC'
      );

      /////////// SE NAO FOR ADMINISTRATOR, RESTRINGIR PARA LISTA MESMA EMPRESA
      if( !current_user_can('administrator') )
        $args_2['meta_query'][] = array(
          'key' => 'user_infos_empresas',
          'value' => get_user_meta(get_current_user_id(), 'user_infos_empresas', true),
          'compare' => '=='
      );
      /////////// FIM 

      $orientadores_users = get_users($args);
      $list_users = array();

      $orientadores_usados = array();

      foreach($orientadores_users as $orientadores_user) {

        // adiciona orientador na lista
        //$list_users[] = $orientadores_user->ID;

        $contagem_orientador = array_keys($orientadores_posts,$orientadores_user->ID);
        if(count($contagem_orientador) >= 3) {
          // Caso já seja orientador 3 vezes ou mais, remove da lista
          // Desmarcar a linha abaixo para voltar a remover da lista
          // unset($list_users[$orientadores_user->ID]);

          // ## Exibe aviso ##
          $membro_infos = get_user_by( 'id', $orientadores_user->ID );
          $membro_matricula = $membro_infos->user_login;
          $list_users[$orientadores_user->data->ID] = apply_filters('str_from_lang','[Já em 3 grupos] ','[Ya en 3 grupos] ') . mb_strimwidth(get_user_meta($orientadores_user->ID, 'first_name', true), 0, 15, "...") . ' - ' . $membro_matricula;
          // ## Fim exibição aviso ##

          // adiciona os excluídos a uma lista extra - caso necessário
          $orientadores_usados[] = $orientadores_user->ID;
        }
        else {
          // Se não estiver mais de 2 vezes, adiciona na lista
          $list_users[$orientadores_user->data->ID] = $orientadores_user->first_name . ' - ' . $orientadores_user->user_login ;
        }

      }

      // echo '<br>Contagem de repeticao: ' . $count;

      return $list_users;

      wp_reset_postdata();

    }

    ////////////////////// CAMPO EXIBIDO EM EM INSCRICAO E 1ª ORIENTATIVA
    function show_if_is_1_orientativa_or_inscricao() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == 'Inscrição' || $status == '1ª Orientativa') {
        return true;
      }
      // EXIBE TODOS OS CAMPOS SEMPRE INDEPENDENTE DO STATUS PARA ESTES USUÁRIOS
      if(current_user_can('administrator') || current_user_can('comissao')) {
        return true;
      }

    }

    ////////////////////// CAMPO EXIBIDO EM TODAS AS ORIENTATIVAS
    function show_if_is_1_orientativa_em_diante() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == '1ª Orientativa' || $status == '2ª Orientativa' || $status == '3ª Orientativa') {
        return true;
      }

    }

    ////////////////////// CAMPO EXIBIDO APENAS NA PRIMEIRA ORIENTATIVA
    function show_if_is_1_orientativa_only() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == '1ª Orientativa') {
        return true;
      }
      // EXIBE TODOS OS CAMPOS SEMPRE INDEPENDENTE DO STATUS PARA ESTES USUÁRIOS
      if(current_user_can('administrator') || current_user_can('comissao')) {
        return true;
      }

    }

    ////////////// CAMPOS PARA A 2ª ORIENTATIVA EM DIANTE
    function show_if_is_2_orientativa_em_diante() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == '2ª Orientativa' || $status == '3ª Orientativa') {
        return true;
      }

    }

    ////////////// CAMPOS APENAS PARA A 2ª ORIENTATIVA
    function show_if_is_2_orientativa_only() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == '2ª Orientativa') {
        return true;
      }
      // EXIBE TODOS OS CAMPOS SEMPRE INDEPENDENTE DO STATUS PARA ESTES USUÁRIOS
      if(current_user_can('administrator') || current_user_can('comissao')) {
        return true;
      }

    }

    ////////////// CAMPOS PARA A 3ª ORIENTATIVA EM DIANTE
    function show_if_is_3_orientativa_em_diante() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == '3ª Orientativa') {
        return true;
      }

    }

    ////////////// CAMPOS APENAS PARA A 3ª ORIENTATIVA
    function show_if_is_3_orientativa_only() {

      $current_user_id = get_current_user_id();
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
      $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

      if($status == '3ª Orientativa') {
        return true;
      }
      // EXIBE TODOS OS CAMPOS SEMPRE INDEPENDENTE DO STATUS PARA ESTES USUÁRIOS
      if(current_user_can('administrator') || current_user_can('comissao')) {
        return true;
      }

    }
    /////////////////////// FIM TODAS AS FUNCOES

}
// FIM INTEGRANTES
// FIM CAMPO DOS GRUPOS

?>