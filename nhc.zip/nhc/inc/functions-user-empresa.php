<?php 

///////////////////// USER TAXONOMY - Empresa
// Tutorial user taxonomy
// https://codebriefly.com/how-to-create-taxonomy-for-users-in-wordpress/

// Register Custom Taxonomy
function register_user_taxonomy() {

  $labels = array(
    'name'                       => apply_filters('str_from_lang','Empresa','Empresa'),
    'singular_name'              => apply_filters('str_from_lang','Empresa','Empresa'),
    'menu_name'                  => apply_filters('str_from_lang','Empresas','Empresas'),
    'all_items'                  => apply_filters('str_from_lang','Todas empresas','Todas las empresas'),
    'parent_item'                => apply_filters('str_from_lang','Empresa pai','Empresa padre'),
    'parent_item_colon'          => apply_filters('str_from_lang','Item padre','Elemento padre'),
    'new_item_name'              => apply_filters('str_from_lang','Nova empresa','Nueva empresa'),
    'add_new_item'               => apply_filters('str_from_lang','Adicionar empresa','Añadir empresa'),
    'edit_item'                  => apply_filters('str_from_lang','Editar empresa','Editar empresa'),
    'update_item'                => apply_filters('str_from_lang','Atualizar empresa','Actualizar empresa'),
    'view_item'                  => apply_filters('str_from_lang','Ver empresa','Ver empresa'),
    'separate_items_with_commas' => apply_filters('str_from_lang','Separar itens com vírgula','Separar los elementos con una coma'),
    'add_or_remove_items'        => apply_filters('str_from_lang','Adicionar ou remover empresas','Anãdir o eliminar empresas'),
    'choose_from_most_used'      => apply_filters('str_from_lang','Escolher as mais usadas','Elegir a las más utilizadas'),
    'popular_items'              => apply_filters('str_from_lang','Empresas populares','Empresas populares'),
    'search_items'               => apply_filters('str_from_lang','Buscar empresas','Buscar empresas'),
    'not_found'                  => apply_filters('str_from_lang','Não encontrado','No encontrado'),
    'no_terms'                   => apply_filters('str_from_lang','Não encontrado','No encontrado'),
    'items_list'                 => apply_filters('str_from_lang','Lista de empresas','Lista de empresas'),
    'items_list_navigation'      => apply_filters('str_from_lang','Lista de empresas','Lista de empresas'),
  );
  $args = array(
    'labels'                     => $labels,
    'hierarchical'               => false,
    'public'                     => false,
    'show_ui'                    => true,
    'show_admin_column'          => false,
    'show_in_nav_menus'          => true,
    'show_tagcloud'              => true,
    'capabilities' => array(
          'manage_terms' => 'manage_empresa',
          'edit_terms' => 'edit_empresa',
          'delete_terms' => 'delete_empresa',
          'assign_terms' => 'assign_empresa',
      )
  );
  register_taxonomy( 'user_empresa', array( 'user' ), $args );

}
add_action( 'init', 'register_user_taxonomy', 0 );

//////////// Adiciona a página para acrescentar/editar taxonomias
function cb_add_user_empresa_taxonomy_admin_page() {
  $tax = get_taxonomy( 'user_empresa' );
  add_users_page(
    esc_attr( $tax->labels->menu_name ),
    esc_attr( $tax->labels->menu_name ),
    $tax->cap->manage_terms,
    'edit-tags.php?taxonomy=' . $tax->name
  );
}
add_action( 'admin_menu', 'cb_add_user_empresa_taxonomy_admin_page' );

//////////// Remove a coluna posts e adiciona a usuários
function cb_manage_user_empresa_user_column( $columns ) {

  unset( $columns['posts'] );

  // $columns['users'] = __( 'Usuários' );

  return $columns;
}
add_filter( 'manage_edit-user_empresa_columns', 'cb_manage_user_empresa_user_column' );

//////////// Atualiza a contagem de membros naquela empresa
function cb_manage_user_empresa_column( $display, $column, $term_id ) {

  if ( 'users' === $column ) {
    $term = get_term( $term_id, 'user_empresa' );
    echo $term->count;
  }
}
add_filter( 'manage_user_empresa_custom_column', 'cb_manage_user_empresa_column', 10, 3 );
///////////////////// END USER TAXONOMY

?>