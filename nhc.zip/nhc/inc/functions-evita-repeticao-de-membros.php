<?php 

add_action( 'admin_head', 'evita_repeticao_membros_grupos' );
function evita_repeticao_membros_grupos() {

	/////////////// ANO VIGENTE ///////////////
	$ano_selecao = get_option( 'opcoes_gerais', 1 );
	$ano = $ano_selecao['opcoes_gerais_ano_vigente'];
	/////////////// ANO VIGENTE ///////////////

	$post_type = get_post_type();

    if ( 'grupos_' . $ano === $post_type ) {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {

        	jQuery(document).on('change','.nome_integrante_js select',function(){

            	var membro_selecionado = jQuery(this).val();
            	var membro_nome = jQuery(this).find('option:selected').text();

            	//alert(membro_selecionado);
            	//alert(membro_nome);

            	//jQuery('.nome_integrante_js option[value="'+ membro_selecionado +'"]').not(this).remove();
            	//$(".content a").not(this).hide("slow");

            	// Remove option para os outros
            	$('.nome_integrante_js select').not(this).find('[value="'+ membro_selecionado +'"]').hide();

            	// Adiciona para todos se select não foi selecionado ainda
            	/* if(jQuery(this).val().length < 1) {
            		alert(membro_selecionado);
            		$('.nome_integrante_js select').append($('<option>', {
					    value: 111,
					    text: 'NOVO'
					}));
            	} /

            });
            

            jQuery(document).on('click','.cmb-add-group-row',function(){
            	// alert('e');
            	alert(membro_selecionado);
            });

        });
    </script>
    <?php
    }
}

?>