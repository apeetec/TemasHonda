<?php 
/////////////// ANO VIGENTE ///////////////
$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
/////////////// ANO VIGENTE ///////////////
?>