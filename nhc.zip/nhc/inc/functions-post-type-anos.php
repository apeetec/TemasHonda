<?php

// Cria Post
add_action('init', 'type_post_anos');
 
    function type_post_anos() { 

        $labels = array(
            'name' => 'Anos',
            'singular_name' => apply_filters('str_from_lang','Ano','Año'),
            'add_new' => apply_filters('str_from_lang','Adicionar ano','Añadir año'),
            'add_new_item' => apply_filters('str_from_lang','Novo ano','Nuevo año'),
            'edit_item' => apply_filters('str_from_lang','Editar ano','Editar año'),
            'new_item' => apply_filters('str_from_lang','Novo ano','Nuevo año'),
            'view_item' => apply_filters('str_from_lang','Ver ano','Ver año'),
            'search_items' => apply_filters('str_from_lang','Procurar ano','Buscar año'),
            'not_found' => apply_filters('str_from_lang','Nenhum ano encontrado','No se encontró ningún año'),
            'not_found_in_trash' => apply_filters('str_from_lang','Nenhum ano encontrado na lixeira','Ningún año encontrado en la papelera'),
            'parent_item_colon' => '',
            'menu_name' => apply_filters('str_from_lang','Anos','Años'),
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'menu_icon' => 'dashicons-search',
            'public_queryable' => true,
            'show_ui' => true,           
            'query_var' => true,
            'rewrite' => array( 'slug' => false, 'with_front' => false ),// true,
            // 'capability_type' => 'post',
            'has_archive' => false,
            'hierarchical' => false,  
            'menu_position' => 2,   
            'supports' => array('title'),            
            'capability_type' => 'anos_cap_',
                'capabilities' => array(
                  'create_posts' => 'create_anos',
                  'publish_posts' => 'publish_anos',
                  'edit_posts' => 'edit_anos',
                  'edit_others_posts' => 'edit_others_anos',
                  'edit_private_posts' => 'edit_private_anos',
                  'delete_posts' => 'delete_anos',
                  'delete_others_posts' => 'delete_others_anos',
                  'delete_private_posts' => 'delete_private_anos',
                  'delete_published_posts' => 'delete_published_anos',
                  'read_private_posts' => 'read_private_anos',
                  'edit_posts' => 'edit_anos',
                  'edit_private_post' => 'edit_private_anos',
                  'edit_published_posts' => 'edit_published_anos',
                  'delete_posts' => 'delete_anos',
                  'read_posts' => 'read_anos',
                ),
            'map_meta_cap'    => true,
          );
 
register_post_type( 'anos' , $args );
flush_rewrite_rules();
}

?>