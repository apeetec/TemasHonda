<?php 

// CMB2 Opções gerais
add_action( 'cmb2_admin_init', 'cmb2_opcoes_geral' );

function cmb2_opcoes_geral() {

$terms = get_terms( 'user_empresa', array('hide_empty' => false) );

  foreach($terms as $term) {

    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

      $cmb_options = new_cmb2_box( array(
        'id'           => 'opcoes_gerais_' . $term->slug,
        'title'        => apply_filters('str_from_lang','Opções gerais','Opciones generales') . ' - ' . $term->name,
        'object_types' => array( 'options-page' ),
        'option_key'      => 'opcoes_gerais_' . $term->slug,
        'icon_url'        => 'dashicons-admin-site-alt3', // Menu icon. Only applicable if 'parent_slug' is left empty.
        'menu_title'      => apply_filters('str_from_lang','Opções gerais','Opciones generales') . ' - ' . $term->name, // Falls back to 'title' (above).
        // 'parent_slug'     => 'themes.php', // Make options page a submenu item of the themes menu.
        'capability'      => 'opcoes-gerais-cmb2', // Cap required to view options-page.
        'position'        => 2, // Menu position. Only applicable if 'parent_slug' is left empty.
      ) );

      $cmb_options->add_field( array(
        'name'    => apply_filters('str_from_lang','Ano vigente (adm)','Año corriente (adm)'),
        'desc'    => apply_filters('str_from_lang','Administrativo: Essa opção atualizará o ano disponível para inscrições de grupos','Administrativo: esta opción actualizará el año disponible para las suscripciones de grupos'),
        'id'      => 'opcoes_gerais_ano_vigente_' . $term->slug,
        'type'    => 'select',
        'default' => date('Y'),
        'options_cb' => 'cmb2_get_post_type_anos',
      ) );

      $cmb_options->add_field( array(
        'name'    => apply_filters('str_from_lang','Ano vigente (home)','Año corriente (adm)'),
        'desc'    => apply_filters('str_from_lang','Visual: Selecione o ano principal a ser exibido na <b>home</b> para membros. <br>Obs: os anos aqui listados são os anos cadastrados através do item "anos" no menu administrativo','Visual: Seleccione el año principal que se mostrará en la <b>página principal</b> para los miembros. <br>Nota: los años enumerados aquí son los años registrados a través de la página "años" en el menú administrativo'),
        'id'      => 'opcoes_gerais_ano_usuarios_' . $term->slug,
        'type'    => 'select',
        'default' => date('Y'),
        'options_cb' => 'cmb2_get_post_type_anos',
      ) );

      $cmb_options->add_field( array(
        'name'    => apply_filters('str_from_lang','Informações de contato','Información del contacto'),
        'desc'    => apply_filters('str_from_lang','Essas informações aparecerão publicamente para todos na aba "Contato"','Esta información aparece públicamente para todos en la página "Contacto"'),
        'id'      => 'opcoes_gerais_contato_' . $term->slug,
        'type'    => 'wysiwyg',
        'options' => array(
            'wpautop' => true, // use wpautop?
            'media_buttons' => false, // show insert/upload button(s)
            // 'textarea_name' => $editor_id, // set the textarea name to something different, square brackets [] can be used here
            'textarea_rows' => get_option('default_post_edit_rows', 5), // rows="..."
            'tabindex' => '',
            'editor_css' => '', // intended for extra styles for both visual and HTML editors buttons, needs to include the `<style>` tags, can use "scoped".
            'editor_class' => '', // add extra class(es) to the editor textarea
            'teeny' => false, // output the minimal editor config used in Press This
            'dfw' => false, // replace the default fullscreen with DFW (needs specific css)
            'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
            'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
        ),
        'classes_cb' => 'divisor-top',
      ) );

      ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
      // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
      if($user_empresa == 'hsa') {
        $_orientativa_3_texto = 'Classificatória';
      }
      else {
        $_orientativa_3_texto = '3ª Orientativa';
      }
      ################# FIM REGRA ADICIONAL

      $cmb_options->add_field( array(
        'name'    => apply_filters('str_from_lang','Fase','Etapa'),
        'desc'    => apply_filters('str_from_lang','Essa opção influenciará as inscrições do ano atual','Esta opción influirá en las suscripciones del año actual'),
        'id'      => 'opcoes_gerais_status_' . $term->slug,
        'type'    => 'radio_inline',
        'classes_cb' => 'divisor-top',
        'default' => 'Inscrição',
        'options' => array(
          'Inscrição' => apply_filters('str_from_lang','Inscrição','Inscripción'),
          '1ª Orientativa' => apply_filters('str_from_lang','1ª Orientativa','1ra Orientación'),
          '2ª Orientativa' => apply_filters('str_from_lang','2ª Orientativa','2da Orientación'),
          '3ª Orientativa' => apply_filters('str_from_lang',$_orientativa_3_texto,'3ra Orientación'),
          'Bloqueado' => apply_filters('str_from_lang','Bloqueado','Bloqueado')
        )
      ) );

      $cmb_options->add_field( array(
        'name' => apply_filters('str_from_lang','Horário de abertura <br>(todo o portal)','Horarios de apertura <br>(todo el portal)'),
        'id' => 'opcoes_gerais_abertura_' . $term->slug,
        'type' => 'text_time',
        'classes_cb' => 'divisor-top',
        // Override default time-picker attributes:
        /* 'attributes' => array(
          'data-timepicker' => json_encode( array(
          'timeOnlyTitle' => __( 'Choose your Time', 'cmb2' ),
          'timeFormat' => 'HH:mm',
          'stepMinute' => 1, // 1 minute increments instead of the default 5
          ) ),
        ), */
        'time_format' => 'H:i',
        'show_on_cb' => 'hide_for_companies',
      ) );

      $cmb_options->add_field( array(
        'name' => apply_filters('str_from_lang','Horário de fechamento <br>(todo o portal)','Hora de cierre <br>(todo el portal)'),
        'id' => 'opcoes_gerais_fechamento_' . $term->slug,
        'type' => 'text_time',
        // Override default time-picker attributes:
        /* 'attributes' => array(
          'data-timepicker' => json_encode( array(
          'timeOnlyTitle' => __( 'Choose your Time', 'cmb2' ),
          'timeFormat' => 'HH:mm',
          'stepMinute' => 1, // 1 minute increments instead of the default 5
          ) ),
        ), */
        'time_format' => 'H:i',
        'show_on_cb' => 'hide_for_companies',
      ) );

      $cmb_options->add_field( array(
        'name' => apply_filters('str_from_lang','Cancelar restrição?','Cancelar restricciones?'),
        'id' => 'opcoes_gerais_ignorar_' . $term->slug,
        'type' => 'select',
        'default' => 'Sim',
        'desc' => apply_filters('str_from_lang','Se nenhuma opção de definição de horários de bloqueio estiver aparecendo, entre em contato com o administrador do sistema para alterá-lo se necessário. Você também pode utilizar as opções acima para manter os bloqueios ou ignorá-lo completamente liberando acesso geral em qualquer horário.','Si no aparece ninguna opción para establecer tiempos de bloqueo, comuníquese con el administrador del sistema para cambiarla si es necesario. También puede utilizar las opciones anteriores para mantener los bloqueos o eludirlos por completo dando acceso general en cualquier momento.'),
        'options' => array(
          'Sim' => apply_filters('str_from_lang','Sim, cancelar horários e liberar o portal','Sí, cancelar horarios y liberar el portal'),
          'Não' => apply_filters('str_from_lang','Não, quero bloquear o portal como base nos horários','No, quiero bloquear el portal en función de los horarios del miembro'),
        ),
        // 'desc' => apply_filters('str_from_lang','Marque essa opção para liberar o portal e ignorar os horários selecionados acima e cancelar qualquer restrição de horário','Marque esta opción para liberar el portal e ignorar los horarios seleccionados arriba y cancelar cualquier restricción de horario')
      ) );

    } // IF

  } // End foreach

  // Funções apenas para empresas
  function hide_for_companies() { 
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);             
    if($user_empresa == 'hab' && !current_user_can('administrator')) {
      return false;
    }
    else {
      return true;
    }
  }

  ///////////////// FUNCOES FORA DO LOOP
  // Exibe os anos
  function cmb2_get_post_type_anos( $query_args ) {

      $args = wp_parse_args( $query_args, array(
          'post_type'   => 'anos',
          'numberposts' => 20,
          'orderby' => 'date',
          'order' => 'ASC'
      ) );

      $posts = get_posts( $args );

      $post_options = array();

      // $post_options[''] = apply_filters('str_from_lang','--- Selecione um ano ---','--- Seleccione un año ---');

      if ( $posts ) {
          foreach ( $posts as $post ) {
            $post_options[ $post->post_name ] = $post->post_title;
          }
      }

      return $post_options;
  }
  ///////////////// FIM FUNCOES

} // End function
// Fim opções gerais

?>