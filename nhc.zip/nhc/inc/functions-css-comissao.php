<?php 
add_action('admin_head', 'custom_css_comissao_admin');
function custom_css_comissao_admin() {

	if(current_user_can('comissao') || current_user_can('administrator')) {
	?>

	<style>
	.postbox-container div#grupos_infos_etapas {display: none;}
	</style>

	<?php
	}
}
?>