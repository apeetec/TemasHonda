<?php 

add_action( 'cmb2_admin_init', 'anos_single_page_videos' );
function anos_single_page_videos() {

    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

    foreach($terms as $term) {

        if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

          $cmb_demo = new_cmb2_box( array(
            'id'            => 'videos_' . $term->slug,
            'title'         => apply_filters('str_from_lang','Vídeos','Videos') . ' - ' . $term->name,
            'object_types'  => array( 'anos' ),
            'closed'     => true, 
          ) );

          $cmb_demo->add_field( array(
            'name'       => apply_filters('str_from_lang','Selecione os vídeos','Seleccione los videos'),
            'desc'       => apply_filters('str_from_lang','Selecione múltiplos vídeos','Seleccione varios videos'),
            'id'         => 'videos_files_' . $term->slug,
            'type'       => 'file_list',
            'query_args' => array( 'type' => 'video' ), // Only video attachment
            // Optional, override default text strings
            'text' => array(
                'add_upload_files_text' => apply_filters('str_from_lang','Adicionar vídeo','Añadir video'), // default: "Add or Upload Files"
                'remove_image_text' => apply_filters('str_from_lang','Remover vídeo','Eliminar video'), // default: "Remove Image"
                'file_text' => apply_filters('str_from_lang','Vídeo','Video'), // default: "File:"
                'remove_text' => apply_filters('str_from_lang','Remover','Eliminar'), // default: "Remove"
            ),
          ) );

        } // IF

    } // End foreach

} // End function

?>