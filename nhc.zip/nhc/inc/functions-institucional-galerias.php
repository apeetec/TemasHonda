<?php 

/////////////// POST TYPE: Galerias criadas como posts, são linkadas aqui

add_action( 'cmb2_admin_init', 'options_page_galeria' );
function options_page_galeria() {

  /////////////////////////////////////////////////////
  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
  /////////////////////////////////////////////////////

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

    foreach($terms as $term) {

      if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

        $cmb_group = new_cmb2_box( array(
          'id'           => 'galeria_group_' . $term->slug,
          'title'        => apply_filters('str_from_lang','Galerias','Galerías') . ' - ' . $term->name,
          'object_types' => array( 'anos' ),
          'closed'     => true,
        ) );

        // $group_field_id is the field id string, so in this case: $prefix . 'demo'
        $group_field_id = $cmb_group->add_field( array(
          'id'          => 'galeria_' . $term->slug,
          'type'        => 'group',
          'description' => apply_filters('str_from_lang','As galerias linkadas serão exibidas na página do ano respectivo','Las galerías vinculadas se mostrarán en la página del año respectivo.'),
          'options'     => array(
            'group_title'    => apply_filters('str_from_lang','Galeria #{#}','Galería #{#}'), // {#} gets replaced by row number
            'add_button'     => apply_filters('str_from_lang','Adicionar galeria','Añadir galería'),
            'remove_button'  => apply_filters('str_from_lang','Remover galeria','Eliminar galería'),
            'sortable'       => true,
            'closed'      => true, // true to have the groups closed by default
            'remove_confirm' => apply_filters('str_from_lang','Deseja realmente remover esta galeria?','¿Realmente quieres eliminar esta galería?'), // Performs confirmation before removing group.
          ),
        ) );

        /* $cmb_group->add_group_field( $group_field_id, array(
          'name' => 'Selecione a imagem de capa da galeria',
          'id'   => 'galeria_file_' . $term->slug,
          'type' => 'file',    
            'options' => array(
              'url' => false, // Hide the text input for the url
            ),
              'query_args' => array(
                'type' => array(
                'image/gif',
                'image/jpeg',
                'image/jpg',
                'image/png',
              ),
            ),
        ) );

        $cmb_group->add_group_field( $group_field_id, array(
          'name' => 'Título',
          'id'   => 'galeria_titulo_' . $term->slug,
          'type' => 'text',
        ) ); */

        $cmb_group->add_group_field( $group_field_id, array(
          'name' => apply_filters('str_from_lang','Data','Fecha'),
          'id'   => 'galeria_data_' . $term->slug,
          'type' => 'text_date',
          'date_format' => 'd-m-Y',
          // Inicio traducao
            'attributes' => array(
              // CMB2 checks for datepicker override data here:
              'data-datepicker' => json_encode( array(
                'dayNames' => array( 
                  apply_filters('str_from_lang','Seg','Lu'), 
                  apply_filters('str_from_lang','Ter','Ma'), 
                  apply_filters('str_from_lang','Qua','Mi'), 
                  apply_filters('str_from_lang','Qui','Ju'), 
                  apply_filters('str_from_lang','Sex','Vi'), 
                  apply_filters('str_from_lang','Sab','Sa'), 
                  apply_filters('str_from_lang','Dom','Do')
                ),
                'dayNamesMin' => array( 
                  apply_filters('str_from_lang','Seg','Lu'), 
                  apply_filters('str_from_lang','Ter','Ma'), 
                  apply_filters('str_from_lang','Qua','Mi'), 
                  apply_filters('str_from_lang','Qui','Ju'), 
                  apply_filters('str_from_lang','Sex','Vi'), 
                  apply_filters('str_from_lang','Sab','Sa'), 
                  apply_filters('str_from_lang','Dom','Do')
                ),
                'monthNamesShort' => explode( ',',
                  apply_filters('str_from_lang','Jan','En') . ',' .
                  apply_filters('str_from_lang','Fev','Feb') . ',' .
                  apply_filters('str_from_lang','Mar','Mar') . ',' .
                  apply_filters('str_from_lang','Abr','Abr') . ',' .
                  apply_filters('str_from_lang','Mai','May') . ',' .
                  apply_filters('str_from_lang','Jun','Jun') . ',' .
                  apply_filters('str_from_lang','Jul','Jul') . ',' .
                  apply_filters('str_from_lang','Ago','Ago') . ',' .
                  apply_filters('str_from_lang','Set','Sept') . ',' .
                  apply_filters('str_from_lang','Out','Oct') . ',' .
                  apply_filters('str_from_lang','Nov','Nov') . ',' .
                  apply_filters('str_from_lang','Dez','Dic')
                ),
                // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                // 'maxDate' => '+1m',
              ) ),                
            ),
            // Fim traducao
        ) );

          $cmb_group->add_group_field( $group_field_id, array(
          'name'        => apply_filters('str_from_lang','Galeria','Galería'),
          'id'          => 'galeria_link_' . $term->slug,
          'description' => apply_filters('str_from_lang','Crie novas galerias <a target="_blank" href="'.admin_url('edit.php?post_type=galerias').'">clicando aqui</a>, e volte aqui para selecionar uma entre as galerias criadas.','Crea nuevas galerías <a target="_blank" href="'.admin_url('edit.php?post_type=galerias').'"> haciendo clic aquí</a> y vuelve aquí para seleccionar una de las galerías creadas.'),
          //'type'        => 'post_search_text', // This field type
          // post type also as array
          // 'post_type'   => 'checkbox',
          // Default is 'checkbox', used in the modal view to select the post type
          'type'       => 'radio',
          'options_cb' => 'cmb2_get_your_post_type_post_options',
            ) );

      } // IF

    } // End foreach

} // End function

// Salva a lista das galerias
function cmb2_get_post_options( $query_args ) {

    $args = wp_parse_args( $query_args, array(
        'post_type'   => 'galerias',
        'numberposts' => 50,
        'orderby' => 'date',
        'order' => 'DESC'
    ) );

    $posts = get_posts( $args );

    $post_options = array();
    if ( $posts ) {
        foreach ( $posts as $post ) {
          $post_options[ $post->ID ] = $post->post_title;
        }
    }

    return $post_options;
}

// Exibe as galerias
function cmb2_get_your_post_type_post_options() {

    // Pega todos os membros de comissao que sao da mesma empresa
    $args = array(
        'role' => 'comissao',
    );

    if( !current_user_can('administrator') )
      $args['meta_query'][] = array(
        'key' => 'user_infos_empresas',
        'value' => get_user_meta(get_current_user_id(), 'user_infos_empresas', true),
        'compare' => '=='
    );
    // Fim

    // Cadastra todos eles em uma array de authors para pegar 'galerias' apenas criadas entre eles
    $users = get_users( $args );
    $authors = array();
      foreach ( (array) $users as $user ) {
        $authors[ $user->ID ] = $user->user_login;
    }
    // Fim

    // Cria outro args de galerias criadas por estes autores 'comissao' da mesma empresa
    $args_galerias = array(
      'post_type' => 'galerias',
      'numberposts' => 50,
      'author__in'=> array_keys( $authors )
    );
    // Fim

    return cmb2_get_post_options( $args_galerias );
}

?>