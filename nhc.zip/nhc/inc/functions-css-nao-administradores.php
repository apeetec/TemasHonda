<?php 

add_action('admin_head', 'custom_css_nao_admin');

function custom_css_nao_admin() {

	if(!current_user_can('administrator')) {

	?>

	<style>
	/* OCULTA ORIENTADORES TEMPORARIAMENTE DA HSA */
	/* body.user-empresa-hsa .cmb2-id-grupos-infos-orientador-2021-hsa {display: none;} */

	/* Remove Logout from admin menu */
	#wpadminbar #wp-admin-bar-user-actions > li#wp-admin-bar-logout {display: none;}

	/* Remove submenu de anos */
	li#menu-posts-anos ul.wp-submenu {display: none;}
	body.post-type-anos .wrap a.page-title-action {display: none;}

	.application-passwords#application-passwords-section, .user-generate-reset-link-wrap, .row-actions span.resetpassword, .row-actions span.view {
		display: none;
	}

	/* Contagem de usuarios */
	.subsubsub a .count {display: none !important}

	/*/////////////////// Remove opcoes rodapé na listagem de usuarios ///////////////////*/
	.users-php .tablenav.bottom {display: none !important}
	.users-php .subsubsub li.administrator {display: none !important}

	/*/////////////////// Página de editar o usuário ///////////////////*/
	form#your-profile .user-email-wrap, form#your-profile .user-nickname-wrap {display: none !important;}
	form#your-profile table.form-table:last-of-type {display: none;}
	form#your-profile table tr.user-description-wrap {display: none;}
	form#your-profile table tr.user-rich-editing-wrap {display: none;}
	form#your-profile table tr.user-comment-shortcuts-wrap {display: none;}
	/* LIBERA ALTERAR SENHA */
	body.user-edit-php form#your-profile table.form-table:last-of-type {display: block;}

	/*/////////////////// Página de criação do usuário ///////////////////*/
	/* Esconde idioma */
	/*form#createuser .user-language-wrap {display: block !important}*/
	/* Esconde email */
	form#createuser table.form-table tbody tr:nth-child(2) {display: none;}
	/* Esconde sobrenome */
	form#createuser table.form-table tbody tr:nth-child(4) {display: none;}
	/* Esconde site */
	form#createuser table.form-table tbody tr:nth-child(5) {display: none;}
	/* Esconde enviar notificacao para usuario */
	form#createuser table.form-table tbody tr:nth-child(10) {display: none;}
	/* Esconde 'other roles' - adicionar múltiplas funções */


	/* form#createuser table.form-table:last-of-type {display: none;} */

	/* Esconde campo de registro de log na criação do usuário */
	form#createuser .cmb2-id-user-log {display: none;}

	/* Esconde contagem de confirmados */
	div.cmb2-id-integrantes-confirmados {display: none;}

	/* Grant roles */
	input#ure_grant_roles, select#ure_add_role, input#ure_add_role_submit, select#ure_revoke_role, input#ure_revoke_role_submit {display: none !important;}

	.row-actions .inline.hide-if-no-js {display: none;}

	/* Esconde o menu de Publicar */
	#misc-publishing-actions{display:none!important}

	/* Esconde select de orientador para HSA */
	.user-empresa-hsa .cmb-row.nome_orientador_js {display: block;}

	/* PUBLISH BOX STICKY */
	@media screen and (min-width: 991px) {
    #submitdiv {position: fixed; z-index:99}
	}
	</style>

	<?php
	}

}

?>