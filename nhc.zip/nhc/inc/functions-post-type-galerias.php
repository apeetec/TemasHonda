<?php 

add_action('init', 'type_post_galerias');
 
    function type_post_galerias() { 
        $labels = array(
            'name' => apply_filters('str_from_lang','Galerias','Galerias'),
            'singular_name' => apply_filters('str_from_lang','Galeria','Galería'),
            'add_new' => apply_filters('str_from_lang','Adicionar Galeria','Añadir Galería'),
            'add_new_item' => apply_filters('str_from_lang','Nova Galeria','Nueva Galería'),
            'edit_item' => apply_filters('str_from_lang','Editar Galeria','Editar Galería'),
            'new_item' => apply_filters('str_from_lang','Nova Galeria','Nueva Galería'),
            'view_item' => apply_filters('str_from_lang','Ver Galeria','Ver Galería'),
            'search_items' => apply_filters('str_from_lang','Procurar Galerias','Buscar Galerias'),
            'not_found' =>  apply_filters('str_from_lang','Nenhuma galeria encontrada','No se encontró galería'),
            'not_found_in_trash' => apply_filters('str_from_lang','Nenhuma galeria encontrada na lixeira.','No se encontró ninguna galería en la papelera.'),
            'parent_item_colon' => '',
            'menu_name' => apply_filters('str_from_lang','Galerias','Galerias')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'menu_icon' => 'dashicons-format-image',
            'public_queryable' => true,
            'show_ui' => true,           
            'query_var' => true,
            'rewrite' => true,
            //'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,    
            'menu_position' => 5,   
            'supports' => array('title'),
            'capability_type' => 'galeria_cap_',
                'capabilities' => array(
                  'create_posts' => 'create_galerias',
                  'publish_posts' => 'publish_galerias',
                  'edit_posts' => 'edit_galerias',
                  'edit_others_posts' => 'edit_others_galerias',
                  'edit_private_posts' => 'edit_private_galerias',
                  'delete_posts' => 'delete_galerias',
                  'delete_others_posts' => 'delete_others_galerias',
                  'delete_private_posts' => 'delete_private_galerias',
                  'delete_published_posts' => 'delete_published_galerias',
                  'read_private_posts' => 'read_private_galerias',
                  'edit_posts' => 'edit_galerias',
                  'edit_private_post' => 'edit_private_galerias',
                  'edit_published_posts' => 'edit_published_galerias',
                  'delete_posts' => 'delete_galerias',
                  'read_posts' => 'read_galerias',
            ),
            'map_meta_cap' => true
          );
 
register_post_type( 'galerias' , $args );
flush_rewrite_rules();
}

// Campos
add_action( 'cmb2_admin_init', 'options_page_galeria_single' );
function options_page_galeria_single() {

  $cmb_demo = new_cmb2_box( array(
    'id'            => 'single_galeria',
    'title'         => apply_filters('str_from_lang','Galeria','Galería'),
    'object_types'  => array( 'galerias' ), // Post type
    // 'show_on_cb' => 'yourprefix_show_if_front_page', // function should return a bool value
    // 'context'    => 'normal',
    // 'priority'   => 'high',
    // 'show_names' => true, // Show field names on the left
    // 'cmb_styles' => false, // false to disable the CMB stylesheet
    'closed'     => false, // true to keep the metabox closed by default
    // 'classes'    => 'extra-class', // Extra cmb2-wrap classes
    // 'classes_cb' => 'yourprefix_add_some_classes', // Add classes through a callback.
  ) );

  $cmb_demo->add_field( array(
    'name'       => apply_filters('str_from_lang','Fotos','Fotos'),
    'desc'       => apply_filters('str_from_lang','Selecione múltiplos arquivos','Seleccione varias imágenes'),
    'id'         => 'galeria_fotos',
    'type'       => 'file_list',
    'query_args' => array( 'type' => 'image' ),
    'text' => array(
        'add_upload_files_text' => apply_filters('str_from_lang','Adicionar ou remover imagens','Anãdir o eliminar imágenes'), // default: "Add or Upload Files"
        'remove_image_text' => apply_filters('str_from_lang','Remover imagem','Eliminar imagen'), // default: "Remove Image"
        'file_text' => apply_filters('str_from_lang','Imagem','Imagen'), // default: "File:"
        'file_download_text' => apply_filters('str_from_lang','Download','Descargar'), // default: "Download"
        'remove_text' => apply_filters('str_from_lang','Remover','Eliminar'), // default: "Remove"
      ),
  ) );

}

?>