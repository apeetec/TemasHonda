<?php 

//////////////// CONFIRMA GRUPO ////////////////
add_action('wp_ajax_confirm_grupo', 'get_user_confirm_grupo_call');
add_action( 'wp_ajax_nopriv_confirm_grupo', 'get_user_confirm_grupo_call' );

function get_user_confirm_grupo_call() {

  //////////////////////////////////////////
  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
  //////////////////////////////////////////

  // Grupo a acrescentar o confirmado
  $post_id = $_REQUEST['post_id'];

  // ID do membro que clicou no botao de confirmacao
  $membro_id = $_REQUEST['add'];

  // Pega a matrícula (login) com base no ID
  $membro_infos = get_user_by( 'id', $membro_id );
  $membro_matricula = $membro_infos->user_login;

  // Pega a quantidade de confirmados salvos no campo
  $confirmados_atual = get_post_meta($post_id, 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true);

  // Atualiza o campo acrescentando o novo membro confirmado
  $novos_confirmados = $confirmados_atual . ' ' . $membro_matricula;

  // Texto de validação visual
  // echo '<br><br>Atualmente, os confirmados são: ' . $confirmados_atual;
  // echo '<br><br>O novo valor será: ' . $novos_confirmados;

  // Salva o campo com todos os confirmados
  update_post_meta($post_id, 'integrantes_confirmados_' . $ano . '_' . $user_empresa, $novos_confirmados );

  // Adiciona horário da confirmação
  $ip = $_SERVER['REMOTE_ADDR'];
  $ip_lista = file_get_contents("http://ip-api.com/json/" . $ip);
  $json = json_decode($ip_lista, true);
  $dispositivo = $_SERVER['HTTP_USER_AGENT'];
  $estado = $json['regionName'];
  $cidade_json = $json['city'];
  $timezone = $json['timezone'];
  $provedor = $json['isp'];
  $empresa_net = $json['org'];
  date_default_timezone_set('America/Sao_Paulo');
  $data = date('d/m/Y');
  $hora = date('H:i:s');
  // Log a ser acrescentado
  $confirmacao = 'IP: ' . $ip . '
' . 'Dispositivo: ' . $dispositivo . '
' . 'Cidade: ' . $cidade_json . ' (' . $estado . ') - ' . $timezone . '
'. 'Internet: ' . $provedor . ' - ' . $empresa_net . '
' . 'Data: ' . $data . '
' . 'Hora: ' . $hora . '';
  update_user_meta($current_user_id, 'user_log_confirmacao', $confirmacao );

    // echo 'O Post é: ' . $post_id . '. E o ID a adicionar é: ' . $id_to_add . '<br>';
    // echo 'Atualizado!';

  wp_die();

}
//////////////// CONFIRMA GRUPO ////////////////

?>