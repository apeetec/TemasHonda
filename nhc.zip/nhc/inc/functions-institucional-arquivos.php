<?php 

add_action( 'cmb2_admin_init', 'options_page_arquivos' );
function options_page_arquivos() {

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

    foreach($terms as $term) {

      if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

        $cmb_demo = new_cmb2_box( array(
          'id'            => 'arquivos_' . $term->slug,
          'title'         => apply_filters('str_from_lang','Arquivos / Cartazes / ATA Reunião','Archivos / Carteles / ACTA Reunión') . ' - ' . $term->name,
          'object_types'  => array( 'anos' ), // Post type
          'closed'     => true, // true to keep the metabox closed by default
        ) );

        $cmb_demo->add_field( array(
          'name'       => apply_filters('str_from_lang','Arquivos','Archivos'),
          'desc'       => apply_filters('str_from_lang','Selecione múltiplos arquivos','Seleccione varios archivos'),
          'id'         => 'arquivos_files_' . $term->slug,
          'type'       => 'file_list',
          'text' => array(
            'add_upload_files_text' => apply_filters('str_from_lang','Adicionar ou remover arquivos','Anãdir o eliminar archivos'), // default: "Add or Upload Files"
            'remove_image_text' => apply_filters('str_from_lang','Remover imagem','Eliminar imagen'), // default: "Remove Image"
            'file_text' => apply_filters('str_from_lang','Arquivo','Archivo'), // default: "File:"
            'file_download_text' => apply_filters('str_from_lang','Download','Descargar'), // default: "Download"
            'remove_text' => apply_filters('str_from_lang','Remover','Eliminar'), // default: "Remove"
          ),
        ) );

        $cmb_demo->add_field( array(
          'name'       => apply_filters('str_from_lang','Cartazes','Carteles'),
          'desc'       => apply_filters('str_from_lang','Selecione múltiplos arquivos','Seleccione varios archivos'),
          'id'         => 'cartazes_files_' . $term->slug,
          'type'       => 'file_list',
          'text' => array(
            'add_upload_files_text' => apply_filters('str_from_lang','Adicionar ou remover arquivos','Anãdir o eliminar archivos'), // default: "Add or Upload Files"
            'remove_image_text' => apply_filters('str_from_lang','Remover imagem','Eliminar imagen'), // default: "Remove Image"
            'file_text' => apply_filters('str_from_lang','Arquivo','Archivo'), // default: "File:"
            'file_download_text' => apply_filters('str_from_lang','Download','Descargar'), // default: "Download"
            'remove_text' => apply_filters('str_from_lang','Remover','Eliminar'), // default: "Remove"
          ),
        ) );

        $cmb_demo->add_field( array(
          'name'       => apply_filters('str_from_lang','ATA Reuniões','ACTA Reunión'),
          'desc'       => apply_filters('str_from_lang','Selecione múltiplos arquivos (arquivos estarão disponíveis apenas para a comissão)','Seleccione varios archivos (los archivos estarán disponibles solo para comisión)'),
          'id'         => 'reunioes_files_' . $term->slug,
          'type'       => 'file_list',
          'text' => array(
            'add_upload_files_text' => apply_filters('str_from_lang','Adicionar ou remover arquivos','Anãdir o eliminar archivos'), // default: "Add or Upload Files"
            'remove_image_text' => apply_filters('str_from_lang','Remover imagem','Eliminar imagen'), // default: "Remove Image"
            'file_text' => apply_filters('str_from_lang','Arquivo','Archivo'), // default: "File:"
            'file_download_text' => apply_filters('str_from_lang','Download','Descargar'), // default: "Download"
            'remove_text' => apply_filters('str_from_lang','Remover','Eliminar'), // default: "Remove"
          ),
        ) );

      } // IF

    } // End foreach

} // End function

?>