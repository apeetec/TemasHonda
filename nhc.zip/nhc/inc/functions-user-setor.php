<?php 

///////////////////// USER TAXONOMY - SETOR
// Tutorial user taxonomy
// https://codebriefly.com/how-to-create-taxonomy-for-users-in-wordpress/

// Register Custom Taxonomy
function register_user_taxonomy_setor() {

  $labels = array(
    'name'                       => apply_filters('str_from_lang','Setor','Sector'),
    'singular_name'              => apply_filters('str_from_lang','Setor','Sector'),
    'menu_name'                  => apply_filters('str_from_lang','Setores','Sectores'),
    'all_items'                  => apply_filters('str_from_lang','Todos setores','Todos los sectores'),
    'parent_item'                => apply_filters('str_from_lang','Setor pai','Sector padre'),
    'parent_item_colon'          => apply_filters('str_from_lang','Item pai','Elemento padre'),
    'new_item_name'              => apply_filters('str_from_lang','Novo setor','Nuevo sector'),
    'add_new_item'               => apply_filters('str_from_lang','Adicionar setor','Añadir sector'),
    'edit_item'                  => apply_filters('str_from_lang','Editar setor','Editar sector'),
    'update_item'                => apply_filters('str_from_lang','Atualizar setor','Actualizar sector'),
    'view_item'                  => apply_filters('str_from_lang','Ver setor','Ver sector'),
    'separate_items_with_commas' => apply_filters('str_from_lang','Separar itens com vírgula','Separe los elementos con una coma'),
    'add_or_remove_items'        => apply_filters('str_from_lang','Adicionar ou remover setores','Añadir o eliminar sectores'),
    'choose_from_most_used'      => apply_filters('str_from_lang','Escolher os mais usados','Elegir a los más usados'),
    'popular_items'              => apply_filters('str_from_lang','Setores populares','Sectores populares'),
    'search_items'               => apply_filters('str_from_lang','Buscar setores','Buscar sectores'),
    'not_found'                  => apply_filters('str_from_lang','Não encontrado','No encontrado'),
    'no_terms'                   => apply_filters('str_from_lang','Não encontrado','No encontrado'),
    'items_list'                 => apply_filters('str_from_lang','Lista de setores','Lista de sectores'),
    'items_list_navigation'      => apply_filters('str_from_lang','Lista de setores','Lista de sectores'),
  );
  $args = array(
    'labels'                     => $labels,
    'hierarchical'               => false,
    'public'                     => false,
    'show_ui'                    => true,
    'show_admin_column'          => false,
    'show_in_nav_menus'          => true,
    'show_tagcloud'              => true,
    'capabilities' => array(
          'manage_terms' => 'manage_setor',
          'edit_terms' => 'edit_setor',
          'delete_terms' => 'delete_setor',
          'assign_terms' => 'assign_setor',
      )
  );
  register_taxonomy( 'user_setor', array( 'user' ), $args );

}
add_action( 'init', 'register_user_taxonomy_setor', 0 );

//////////// Adiciona a página para acrescentar/editar taxonomias
function cb_add_user_setor_taxonomy_admin_page() {
  $tax = get_taxonomy( 'user_setor' );
  add_users_page(
    esc_attr( $tax->labels->menu_name ),
    esc_attr( $tax->labels->menu_name ),
    $tax->cap->manage_terms,
    'edit-tags.php?taxonomy=' . $tax->name
  );
}
add_action( 'admin_menu', 'cb_add_user_setor_taxonomy_admin_page' );

//////////// Remove a coluna posts e adiciona a usuários
function cb_manage_user_setor_user_column( $columns ) {

  unset( $columns['posts'] );

  // $columns['users'] = __( 'Usuários' );

  return $columns;
}
add_filter( 'manage_edit-user_setor_columns', 'cb_manage_user_setor_user_column' );

//////////// Atualiza a contagem de membros naquela setor
function cb_manage_user_setor_column( $display, $column, $term_id ) {

  if ( 'users' === $column ) {
    $term = get_term( $term_id, 'user_setor' );
    echo $term->count;
  }
}
add_filter( 'manage_user_setor_custom_column', 'cb_manage_user_setor_column', 10, 3 );
///////////////////// END USER TAXONOMY

?>