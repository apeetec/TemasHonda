<?php 
//////////////////// NOT ADMIN
add_action('admin_init','custom_rules_non_admins');
function custom_rules_non_admins() {
  if(!current_user_can('administrator')) {
    remove_menu_page('admin.php?page=wpcf7'); // remove ACF7
    remove_menu_page('admin.php?page=wpcf7-integration');
    remove_menu_page('wpcf7');
    remove_menu_page('admin.php?page=cfdb7-list.php');
    remove_menu_page('cfdb7-list.php');    
  }
}

//////////////////// Remove quick edit
if( !current_user_can( 'manage_options' ) ) {
  add_filter( 'post_row_actions', 'my_cpt_row_actions', 10, 2 );
  function my_cpt_row_actions( $actions, $post ) {
      if ( 'grupos' === $post->post_type ) {
          // Removes the "Quick Edit" action.
          unset( $actions['inline hide-if-no-js'] );
          unset( $actions['view'] );
      }
      return $actions;
  }

//////////////////// Remove slug edition
  function hide_permalink() {
    return '';
  }
  add_filter( 'get_sample_permalink_html', 'hide_permalink' );

}

//////////////////// Remove profile page
add_action( 'load-profile.php', function() {
    if( ! current_user_can( 'manage_options' ) )
        exit( wp_safe_redirect( admin_url() ) );
} );

//////////////////// Remover contagem dos grupos
if( !current_user_can( 'manage_options' ) ) {

  /////////////// ANO VIGENTE ///////////////
  $ano_selecao = get_option( 'opcoes_gerais', 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente'];
  /////////////// ANO VIGENTE ///////////////

  add_filter("views_edit-" . $ano, 'custom_editor_counts', 10, 1);

  function custom_editor_counts($views) {
  // var_dump($views) to check other array elements that you can hide.
    unset($views['all']);
    unset($views['publish']);
    unset($views['pending']);
    unset($views['trash']);
    unset($views['draft']);
    return $views;
  }

//////////////////// Redirecionar página de mídias
  global $pagenow;
  if ($pagenow == 'upload.php' || $pagenow == 'media-new.php') {

    wp_redirect(admin_url());

  }
  add_action( 'admin_menu', 'remove_menu_links' );
      function remove_menu_links() {
      remove_menu_page('upload.php'); //remove media
  }

//////////////////// Botão roxo de retorno para o site
  function general_admin_notice(){
         echo '<a id="back-button" href="'.home_url().'">'.apply_filters('str_from_lang','Voltar para o site','Volver al sitio').'</a>';
  }
  add_action('admin_notices', 'general_admin_notice');

//////////////////// Remover botão de NOVO/NEW da barra de admin
  add_action( 'admin_bar_menu', 'remove_wp_nodes', 999 );
  function remove_wp_nodes() 
  {
      global $wp_admin_bar;   
      $wp_admin_bar->remove_node( 'new-post' );
      $wp_admin_bar->remove_node( 'new-link' );
      $wp_admin_bar->remove_node( 'new-media' );
  }

//////////////////// Remover help / options tab
  add_action('admin_head', 'mytheme_remove_help_tabs');
  function mytheme_remove_help_tabs() {
      $screen = get_current_screen();
      $screen->remove_help_tabs();
  }
  add_filter('screen_options_show_screen', '__return_false');

}

//////////////////// REMOVE ADMIN FOR OTHER USERS ON PAGES
function wdm_user_role_dropdown($all_roles) {

    global $pagenow;

    if( !current_user_can('administrator') && $pagenow == 'user-edit.php' || !current_user_can('administrator') && $pagenow == 'user-new.php' || !current_user_can('administrator') && $pagenow == 'users.php' ) {
        // if current user is editor AND current page is edit user page
        unset($all_roles['administrator']);
    }

    return $all_roles;
}
add_filter('editable_roles','wdm_user_role_dropdown');

?>