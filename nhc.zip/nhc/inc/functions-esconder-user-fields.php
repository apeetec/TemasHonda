<?php 

// Remove user fields
if(is_admin()){
  remove_action("admin_color_scheme_picker", "admin_color_scheme_picker");
}

// Remove fields from Admin profile page
    if ( ! function_exists( 'cor_remove_personal_options' ) ) {
        function cor_remove_personal_options( $field ) {

            $field = preg_replace('#<tr class="user-display-name-wrap(.*?)</tr>#s', '', $field, 1);
            // $field = preg_replace('#<tr class="user-nickname-wrap(.*?)</tr>#s', '', $field, 1);
            $field = preg_replace('#<tr class="user-url-wrap(.*?)</tr>#s', '', $field, 1);
            $field = preg_replace('#<tr class="user-last-name-wrap(.*?)</tr>#s', '', $field, 1);
            $field = preg_replace('#<tr class="user-description-wrap(.*?)</tr>#s', '', $field, 1);
            $field = preg_replace('#<tr class="user-profile-picture(.*?)</tr>#s', '', $field, 1);
            $field = preg_replace('#<tr class="show-admin-bar(.*?)</tr>#s', '', $field, 1);
            //$field = preg_replace('#<tr class="user-language-wrap(.*?)</tr>#s', '', $field, 1);
            //$field = preg_replace( '#<h2>Opções pessoais</h2>.+?/table>#s', '', $field, 1 ); // Remove título
            $field = preg_replace( '#<h2>Sobre você</h2>.+?/table>#s', '', $field, 1 ); // Remove título
            $field = preg_replace( '#<h2>Informações de contato</h2>#s', '', $field, 1 ); // Remove título
            $field = preg_replace( '#<h3>Additional Capabilities</h3>#s', '', $field, 1 ); // Remove título
            $field = preg_replace( '#<h2>Sobre o usuário</h2>#s', '', $field, 1 ); // Remove título
            return $field;

        }

        function cor_profile_subject_start() {
            if ( ! current_user_can('administrator') ) {
                ob_start( 'cor_remove_personal_options' );
            }
        }

        function cor_profile_subject_end() {
            if ( ! current_user_can('administrator') ) {
                ob_end_flush();
            }
        }
    }
    add_action( 'admin_head', 'cor_profile_subject_start' );
    add_action( 'admin_footer', 'cor_profile_subject_end' );
// Remove user fields

?>