<?php 

// Author only posts

function posts_for_current_author($query) {
    global $pagenow;
 
    if( 'edit.php' != $pagenow || !$query->is_admin )
        return $query;
 
    if( !current_user_can( 'edit_others_posts' ) ) {
        global $user_ID;
        $query->set('author', $user_ID );
    }
    return $query;
}
add_filter('pre_get_posts', 'posts_for_current_author');

////////////// Current user attachments
/* if(!current_user_can('administrator')) {
	
	add_filter( 'ajax_query_attachments_args', 'show_current_user_attachments' );

	function show_current_user_attachments( $query ) {
		$user_id = get_current_user_id();
		if ( $user_id ) {
			$query['author'] = $user_id;
		}
		return $query;
	}
} */

?>