<?php 

// INICIO CAMPOS USARIOS
add_action( 'cmb2_admin_init', 'campos_usuarios_fields' );

function campos_usuarios_fields() {

  $cmb_user = new_cmb2_box( array(
    'id'               => 'user_infos',
    'title'            => apply_filters('str_from_lang','Informações importantes','Informaciones importantes'), // Doesn't output for user boxes
    'object_types'     => array( 'user' ), // Tells CMB2 to use user_meta vs post_meta
    'show_names'       => true,
    'new_user_section' => 'add-new-user', // where form will show on new user page. 'add-existing-user' is only other valid option.
  ) );

  $cmb_user->add_field( array(
    'name'     => apply_filters('str_from_lang','Empresa','Empresa'),
    'id'       => 'user_infos_empresas',
    'type' => 'pw_select',
    'options_cb' => 'user_taxonomy_empresas',
    'column' => array(
      'position' => 2,
      'name'     => apply_filters('str_from_lang','Empresa','Empresa'),
    ),
    'display_cb' => 'user_infos_empresas_coluna'
    // 'type'     => 'taxonomy_select', // Or `taxonomy_select_hierarchical`
    // 'taxonomy' => 'user_empresa', // Taxonomy Slug
  ) );

  function user_infos_empresas_coluna( $field_args, $field ) {
    
    echo strtoupper($field->escaped_value());

  }

  function user_taxonomy_empresas() {
    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

    $list_empresas = array();

    foreach($terms as $term) {
      // $list_empresas[$term->term_id] = $term->name; // Pega o termo e utiliza o ID
      $list_empresas[$term->slug] = $term->name;
    }

    return $list_empresas;

  }

  /////////////////////////////////////////////////////////////
  $cmb_user->add_field( array(
    'name'     => apply_filters('str_from_lang','Unidade','Unidad'),
    'id'       => 'user_infos_unidades',
    'type' => 'pw_select',
    'options_cb' => 'user_taxonomy_unidades',
    'column' => array(
      'position' => 3,
      'name'     => apply_filters('str_from_lang','Unidade','Unidad'),
    ),
    'display_cb' => 'user_infos_unidades_coluna'
    // 'type'     => 'taxonomy_select', // Or `taxonomy_select_hierarchical`
    // 'taxonomy' => 'user_empresa', // Taxonomy Slug
  ) );

  function user_infos_unidades_coluna( $field_args, $field ) {
    
    echo strtoupper($field->escaped_value());

  }

  function user_taxonomy_unidades() {
    $terms = get_terms( 'user_unidade', array('hide_empty' => false) );

    $list_unidades = array();

    foreach($terms as $term) {
      // $list_unidades[$term->term_id] = $term->name; // Pega o termo e utiliza o ID
      $list_unidades[$term->slug] = $term->name;
    }

    return $list_unidades;

  }

  /////////////////////////////////////////////////////////////
  $cmb_user->add_field( array(
    'name'     => apply_filters('str_from_lang','Setor','Sector'),
    'id'       => 'user_infos_setores',
    'type' => 'pw_select',
    'options_cb' => 'user_taxonomy_setores',
    //'column' => array(
    //  'position' => 3,
    //  'name'     => 'Setor',
    //),
    'display_cb' => 'user_infos_setores_coluna'
    // 'type'     => 'taxonomy_select', // Or `taxonomy_select_hierarchical`
    // 'taxonomy' => 'user_empresa', // Taxonomy Slug
  ) );

  function user_infos_setores_coluna( $field_args, $field ) {
    
    echo strtoupper($field->escaped_value());

  }

  function user_taxonomy_setores() {
    $terms = get_terms( 'user_setor', array('hide_empty' => false) );

    $list_setores = array();

    foreach($terms as $term) {
      // $list_setores[$term->term_id] = $term->name; // Pega o termo e utiliza o ID
      $list_setores[$term->slug] = $term->name;
    }

    return $list_setores;

  }

  /*$cmb_user->add_field( array(
    'name'     => 'Empresa',
    'id'       => 'user_infos_empresa',
    'column' => array(
      'position' => 2,
      'name'     => 'Cidade',
    ),
    'type'     => 'text',
  ) );*/

  $cmb_user->add_field( array(
    'name'     => apply_filters('str_from_lang','Turno','Turno'),
    'id'       => 'user_infos_turno',
    'type' => 'select',
    'show_option_none' => true,
    'options' => array(
      '' => apply_filters('str_from_lang','--- Selecione uma opção ---','--- Seleccione una opción ---'),
      '1-turno' => apply_filters('str_from_lang','1º Turno','1er Turno'),
      '2-turno' => apply_filters('str_from_lang','2º Turno','2do Turno'),
      '3-turno' => apply_filters('str_from_lang','3º Turno','3er Turno'),
      '4-turno' => apply_filters('str_from_lang','4º Turno','4to Turno'),
      'adm' => apply_filters('str_from_lang','Adm','Adm'),
    ),
  ) );

  $cmb_user->add_field( array(
    'name'     => apply_filters('str_from_lang','Log de informações','Registro de información'),
    'id'       => 'user_log',
    'type'     => 'textarea',
    'show_on_cb' => 'user_show_if_is_comissao',
  ) );
  
  $cmb_user->add_field( array(
    'name'     => apply_filters('str_from_lang','Confirmação de participação', 'Confirmación de participación'),
    'id'       => 'user_log_confirmacao',
    'type'     => 'textarea',
    'show_on_cb' => 'user_show_if_is_comissao',
    'attributes' => array(
      'readonly' => true
    )
  ) );

  function user_show_if_is_comissao() {
    if(current_user_can('administrator') || current_user_can('comissao')) {
      return true;
    }
  } 

}
// FIM CAMPOS USUARIOS

?>