<?php 

/**
 * Manage User Admin Display Table Columns
 *
 * @param Array $columns
 *      [cb]        => <input type="checkbox" />
 *      [username]  => Username
 *      [name]      => Name
 *      [email]     => Email
 *      [role]      => Role
 *      [posts]     => Posts
 *
 * @return Array $columns
 */
function wpseq_270133_users( $columns ) {

    unset( $columns['email'] );
    unset( $columns['posts'] );

    return $columns;
}
add_filter( 'manage_users_columns', 'wpseq_270133_users' );

?>