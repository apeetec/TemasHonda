<?php 

function change_role_name() {
    global $wp_roles;

    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();

    //You can list all currently available roles like this...
    //$roles = $wp_roles->get_names();
    //print_r($roles);

    //You can replace "administrator" with any other role "editor", "author", "contributor" or "subscriber"...
    $wp_roles->roles['administrator']['name'] = apply_filters('str_from_lang','Administrador','Administrador');
    $wp_roles->role_names['administrator'] = apply_filters('str_from_lang','Administrador','Administrador');

    $wp_roles->roles['membro-coordenador']['name'] = apply_filters('str_from_lang','Membro-Coordenador','Miembro-Coordinador');
    $wp_roles->role_names['membro-coordenador'] = apply_filters('str_from_lang','Membro-Coordenador','Miembro-Coordinador'); 

    // $wp_roles->roles['membro-orientador']['name'] = apply_filters('str_from_lang','Membro-Orientador','Miembro-Tutor');
    // $wp_roles->role_names['membro-orientador'] = apply_filters('str_from_lang','Membro-Orientador','Miembro-Tutor'); 

    $wp_roles->roles['coordenador']['name'] = apply_filters('str_from_lang','Coordenador','Coordinador');
    $wp_roles->role_names['coordenador'] = apply_filters('str_from_lang','Coordenador','Coordinador'); 

    $wp_roles->roles['comissao']['name'] = apply_filters('str_from_lang','Comissão','Comisíon');
    $wp_roles->role_names['comissao'] = apply_filters('str_from_lang','Comissão','Comisíon'); 

    $wp_roles->roles['orientador']['name'] = apply_filters('str_from_lang','Orientador','Tutor');
    $wp_roles->role_names['orientador'] = apply_filters('str_from_lang','Orientador','Tutor'); 

    $wp_roles->roles['membro']['name'] = apply_filters('str_from_lang','Membro','Miembro');
    $wp_roles->role_names['membro'] = apply_filters('str_from_lang','Membro','Miembro');           
}
add_action('init', 'change_role_name');

?>