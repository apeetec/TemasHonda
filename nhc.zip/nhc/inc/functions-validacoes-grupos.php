<?php 

//////////////// Sem nome de grupo - Bloqueio de botao de publicar/atualizar ////////////////
function rtp_force_fields_to_post_init() 
{
  wp_enqueue_script('jquery');
}

function rtp_force_fields_to_post( $post ) 
{
  $post_type = get_post_type();
  $validation_message = apply_filters('str_from_lang','Digite o nome do grupo para prosseguir!','¡Ingrese el nombre del grupo para continuar!');

  /////////////// ANO VIGENTE ///////////////
  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
  /////////////// ANO VIGENTE ///////////////

  if('grupos_' . $ano . '_' . $user_empresa === $post_type) { ?>
    <script type='text/javascript'>
    /////////////// Validacoes para os campos
    var status = '<?php $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 ); $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa]; echo $status; ?>';

    jQuery( document ).ready(function() {

      jQuery('#publish').on('click',function(){

        ///////////////// NOME DO GRUPO
        var testervar = jQuery('[id^="titlediv"]').find('#title');
        jQuery('#titlewrap div#title_validation').hide();
        if (testervar.val().length < 1)
        { 
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Digite um nome para o grupo!','¡Ingrese un nombre para el grupo!'); ?></p></div></div></div>');    
          return false;
        }

        <?php if($user_empresa != 'hsa') /* REMOVE OBRIGATORIEDADE DO ORIENTADOR PARA EMPRESAS LISTADAS NO IF */ { ?>
        if(status == 'Inscrição' || status == '1ª Orientativa') {
          ///////////////// ORIENTADOR
          /**/
          if(jQuery('#grupos_infos_orientador_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Orientador
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione um orientador!','¡Seleccione un tutor!'); ?></p></div></div></div>');    
            return false;
          }
        }
        <?php } ?>

        if(status == 'Inscrição' || status == '1ª Orientativa') {
          ///////////////// MEMBROS REPETIDOS /////////////////
          var nome_membro_1 = jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_0_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val(); 
          var nome_membro_2 = jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_1_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val();
          var nome_membro_3 = jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_2_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val();
          var nome_membro_4 = jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_3_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val(); 
          var nome_membro_5 = jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_4_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val();        
          ///////////////// FIM MEMBROS REPETIDOS 
        }

        if(status == '3ª Orientativa') {
          if(jQuery('#grupos_infos_confirma_3_orientativa_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma 3ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione uma opção de confirmação da 3ª orientativa!','¡Seleccione una opción de confirmación para la 3ra orientación!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_fator_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma fator
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Preencha o fator do grupo!','¡Complete el factor del grupo!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_objetivo_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma objetivo
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Preencha o objetivo do grupo!','¡Complete el objetivo del grupo!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_situacao_atual_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma situação atual
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Preencha a situação atual do grupo!','¡Complete la situación actual del grupo!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_meta_planejada_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma meta planejada
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Preencha a meta planejada do grupo!','¡Complete la meta planificada del grupo!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_prazo_execucao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma prazo para excecucao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Preencha o prazo para execução da solução!','¡Complete el plazo para ejecutar la solución!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_investimento_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma investimento
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Informe se há necessidade de investimento!','¡Informe si hay necesidad de inversión!'); ?></p></div></div></div>');    
            return false;
          }

          // Se tiver investimento e o valor do investimento estiver vazio, exibe mensagem
          if(jQuery('#grupos_infos_3_orientativa_investimento_<?php echo $ano . '_' . $user_empresa; ?>').val() == 'Sim' && jQuery('#grupos_infos_3_orientativa_investimento_valor_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {            
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Foi selecionado que há necessidade de investimento, informe o valor necessário!','Se seleccionó que hay necesidad de inversión, ¡informe la cantidad necesaria!'); ?></p></div></div></div>');    
            return false;
          }

        } /////////// Fim terceira

        //////////// Inicio segunda
        if(status == '2ª Orientativa') {
          if(jQuery('#grupos_infos_confirma_2_orientativa_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione uma opção de confirmação da 2ª orientativa!','¡Seleccione una opción de confirmación para la 2da orientación!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_turno_apresentador_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma turno do apresentador - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione o turno do apresentador!','¡Seleccione el turno del presentador!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_tema_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Tema - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Digite o tema do grupo!','¡Ingrese el tema del grupo!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_categoria_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Categoria - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a categoria do grupo!','¡Seleccione la categoría del grupo!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_analise_situacao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Analise de situacao - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a data da análise de situação!','¡Seleccione la fecha del análisis de la situación!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_analise_causas_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Analise de causas - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a data da análise de causas!','¡Seleccione la fecha del análisis de la causa!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_obj_metas_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Objetivos e metas - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a data dos objetivos e metas!','¡Seleccione la fecha de los objetivos y metas!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_est_imp_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Estudos e implantação - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a data dos estudos e implantação!','¡Seleccione la fecha de los estudios y implementación!'); ?></p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_analise_result_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Análise dos resultados - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a data da análise dos resultados!','¡Seleccione la fecha del análisis de los resultados!'); ?></p></div></div></div>');    
            return false;
          }
        } //////// Fim segunda

        // VALIDAÇÃO DE LÍDER E APRESENTADOR
        if(status == '1ª Orientativa') {
          
          var selections = [];

          // Salva todas as funções
          jQuery(".funcao_integrante_js select").each(function(index){
              if (jQuery(this).has('option:selected')){
                  // alert('Select number ' + index + ': ' + jQuery(this).val());
                  selections.push(jQuery(this).val());
              }
          });
          
          // Verifica
          if(jQuery.inArray("Apresentador", selections) != -1 && jQuery.inArray("Líder", selections) != -1) {
          // Existe, prossegue normalmente...
          }
          else {
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Verifique as funções dos integrantes! É obrigatório ao menos um <u>Apresentador</u> e um <u>Líder</u>','¡Consulta los roles de los miembros! Se requiere al menos un <u>Presentador</u> y un <u>Líder</u>'); ?></p></div></div></div>');    
            return false; 
          }           
        }

        /////// Inicio primeira
        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_infos_confirma_1_orientativa_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Confirma 1ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione uma opção de confirmação da 1ª orientativa!','¡Seleccione una opción de confirmación para la 1ra orientación!'); ?></p></div></div></div>');    
            return false;
          }
        }

        ///////////////// PRIMEIRO INTEGRANTE
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_0_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
          // Primeiro integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione o nome do primeiro integrante!','¡Seleccione el nombre del primer miembro!'); ?></p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_0_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length > 1) {
          if(nome_membro_1 == nome_membro_2 || nome_membro_1 == nome_membro_3 || nome_membro_1 == nome_membro_4 || nome_membro_1 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Os integrantes não podem ser repetidos! Verifique e tente novamente.','¡Los miembros no se pueden repetir! Verifica y vuelve a intentarlo.'); ?></p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_0_grupos_integrantes_funcao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Primeiro integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a função do primeiro integrante!','¡Seleccione la función del primer miembro!'); ?></p></div></div></div>');    
            return false;
          }
        }

        ///////////////// VALIDA SE HÁ 3 OU MAIS
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_repeat').find('.cmb-repeatable-grouping').length < 3) {
          // 3 ou mais integrantes
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Adicione 3 ou mais integrantes para prosseguir!','¡Agregue 3 o más miembros para continuar!'); ?></p></div></div></div>');    
          return false;
        }  

        ///////////////// SEGUNDO INTEGRANTE
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_1_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
          // Segundo integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione o nome do segundo integrante!','¡Seleccione el nombre del segundo miembro!'); ?></p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_1_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length > 1) {
          if(nome_membro_2 == nome_membro_1 || nome_membro_2 == nome_membro_3 || nome_membro_2 == nome_membro_4 || nome_membro_2 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Os integrantes não podem ser repetidos! Verifique e tente novamente.','¡Los miembros no se pueden repetir! Verifica y vuelve a intentarlo.'); ?></p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_1_grupos_integrantes_funcao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Segundo integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a função do segundo integrante!','¡Seleccione la función del segundo miembro!'); ?></p></div></div></div>');    
            return false;
          }
        }

        ///////////////// TERCEIRO INTEGRANTE
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_2_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
          // Terceiro integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione o nome do terceiro integrante!','¡Seleccione el nombre del tercer miembro!'); ?></p></div></div></div>');    
          return false;
        } 
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_2_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length > 1) {
          if(nome_membro_3 == nome_membro_1 || nome_membro_3 == nome_membro_2 || nome_membro_3 == nome_membro_4 || nome_membro_3 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Os integrantes não podem ser repetidos! Verifique e tente novamente.','¡Los miembros no se pueden repetir! Verifica y vuelve a intentarlo.'); ?></p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_2_grupos_integrantes_funcao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Terceiro integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a função do terceiro integrante!','¡Seleccione la función del tercer miembro!'); ?></p></div></div></div>');    
            return false;
          }   
        }            

        ///////////////// QUARTO INTEGRANTE
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_3_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
          // Quarto integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione o nome do quarto integrante!','¡Seleccione el nombre del cuarto miembro!'); ?></p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_3_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length > 1) {
          if(nome_membro_4 == nome_membro_1 || nome_membro_4 == nome_membro_2 || nome_membro_4 == nome_membro_3 || nome_membro_4 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Os integrantes não podem ser repetidos! Verifique e tente novamente.','¡Los miembros no se pueden repetir! Verifica y vuelve a intentarlo.'); ?></p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_3_grupos_integrantes_funcao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Quarto integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a função do quarto integrante!','¡Seleccione la función del cuarto miembro!'); ?></p></div></div></div>');    
            return false;
          }
        }

        ///////////////// QUINTO INTEGRANTE
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_4_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
          // Quinto integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione o nome do quinto integrante!','¡Seleccione el nombre del quinto miembro!'); ?></p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_4_grupos_integrantes_nome_<?php echo $ano . '_' . $user_empresa; ?>').val().length > 1) {
          if(nome_membro_5 == nome_membro_1 || nome_membro_5 == nome_membro_2 || nome_membro_5 == nome_membro_3 || nome_membro_5 == nome_membro_4) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Os integrantes não podem ser repetidos! Verifique e tente novamente.','¡Los miembros no se pueden repetir! Verifica y vuelve a intentarlo.'); ?></p></div></div></div>');    
              return false;
          }
        } 
        
        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_4_grupos_integrantes_funcao_<?php echo $ano . '_' . $user_empresa; ?>').val().length < 1) {
            // Quinto integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p><?php echo apply_filters('str_from_lang','Selecione a função do quinto integrante!','¡Seleccione la función del quinto miembro!'); ?></p></div></div></div>');    
            return false;
          } 
        }             
        
      });    

      // Clique para fechar .cmb_custom_close
      jQuery(document).on('click','#cmb_custom_close',function(){
        jQuery('.cmb_custom_warning_box').fadeOut(300);
      });      

      // Remove mensagem "Tem certeza que deseja sair desta pagina?"
      jQuery(document).ready(function(){
        jQuery(window).off("beforeunload", null);
      });

      // Opções de investimento
      jQuery('#grupos_infos_3_orientativa_investimento_<?php echo $ano . '_' . $user_empresa; ?>').change(function() {
        // Se não tiver investimento, bloqueia campo de valor
        if(jQuery('#grupos_infos_3_orientativa_investimento_<?php echo $ano . '_' . $user_empresa; ?>').val() == 'Não') {            
          jQuery('.investimento_mask').css('pointer-events','none');
          jQuery('.investimento_mask').css('opacity','0.6');
        }
        else {
          jQuery('.investimento_mask').css('pointer-events','all');
          jQuery('.investimento_mask').css('opacity','1');                   
        }
        jQuery('#grupos_infos_3_orientativa_investimento_valor_<?php echo $ano . '_' . $user_empresa; ?>').val(''); 
      });

      /* jQuery(function() {
        // choose target dropdown
        var select = jQuery('select');
        select.html(select.find('option').sort(function(x, y) {
          // to change to descending order switch "<" for ">"
          return jQuery(x).text() > jQuery(y).text() ? 1 : -1;
        }));

        // select default item after sorting (first item)
        // $('select').get(0).selectedIndex = 0;
      }); */

    });
  </script>

<?php 
  }
}
add_action( 'admin_init', 'rtp_force_fields_to_post_init' );
add_action( 'edit_form_after_title', 'rtp_force_fields_to_post' );
//////////////// Fim Bloqueio de botao de publicar/atualizar ////////////////

//////////////// Criacao de grupos, campos obrigatorios ////////////////
//////////////// Fim Criacao de grupos, campos obrigatorios ////////////////

// Admin css para usuários apenas
add_action('admin_head', 'my_custom_css_subscriber');

function my_custom_css_subscriber() {

if ( ! current_user_can('manage_options') ) {

?>
  <style>
    tr.user-nickname-wrap {display: none !important}
    .submitbox div#misc-publishing-actions {display: none;}
    .submitbox div#minor-publishing-actions {padding: 10px;display: none;}

    a#back-button {background-color: #0e317a !important;position: fixed;bottom: 0;right: 0;z-index: 99999;margin: 0px;font-weight: bold;color: #fff;padding: 13px 1px;text-transform: uppercase;font-size: 16px;text-decoration: none;width: 100%;text-align: center;display: block;letter-spacing: 1.5px;}

    @media screen and (max-width: 991px) {
      a#back-button {display: block;}
      #wpwrap {padding-bottom: 50px;}
    }
  </style>

<?php } }

?>