<?php 

/** Return string by language **/
// Ajustar locale também no 'header.php'
add_filter('str_from_lang','_lt',10,3);
function _lt($pt_string,$es_string) {

    $locale_browser = Locale::acceptFromHttp($_SERVER['HTTP_ACCEPT_LANGUAGE']);
    $languages = ['pt_BR', 'es_ES', 'es_CL', 'es_AR']; 
    $languages_spanish = ['es_ES', 'es_CL', 'es_AR'];

    ///////////// Idioma para usuario nao logado
    if(!is_user_logged_in()) {
      // echo $locale_browser;
      // switch_to_locale('$locale_browser');
      // É espanhol
      if(in_array($locale_browser,$languages_spanish)){
        switch_to_locale('es_ES');
        return $es_string;
      }
      // É portugues
      else if($locale_browser == 'pt_BR'){
        return $pt_string;
      }
      // Qualquer outro, deixa ingles
      else {        
        switch_to_locale('en_US');
        return $pt_string;
      }
    }
    ///////////// Fim idioma para usuario nao logado

    ///////////// Idioma para usuario logado
    else {
      if (get_user_locale(get_current_user_id()) == 'pt_BR') {
        return $pt_string;
      }
      else if (get_user_locale(get_current_user_id()) == 'es_ES') {
        return $es_string;       
      }
      else {
        // Se for qualquer outro, retorna portugues porque ainda nao há traducoes
        return $pt_string;       
      }
    }
    ///////////// Fim idioma para usuario logado
  
}

?>