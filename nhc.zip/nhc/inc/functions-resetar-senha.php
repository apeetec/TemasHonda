<?php 

// Remove Lost Password Link
function vpsb_remove_lostpassword_text ( $text ) {
         if ($text == 'Perdeu a Data de nascimento: DDMMAAAA?'){$text = '';}
                return $text;
         }
add_filter( 'gettext', 'vpsb_remove_lostpassword_text' );

// Disable Password Reset URL & Redirect
function vpsb_disable_lost_password() {
    if (isset( $_GET['action'] )){
        if ( in_array( $_GET['action'], array('lostpassword', 'retrievepassword') ) ) {
            wp_redirect( wp_login_url(), 301 );
            exit;
        }
    }
}
add_action( "login_init", "vpsb_disable_lost_password" );

?>