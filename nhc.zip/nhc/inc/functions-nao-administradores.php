<?php 

if(!current_user_can('administrator')) {
	
  add_filter( 'get_avatar', '__return_null' );
  // Remove items from menu
  add_action( 'admin_menu', 'wps_remove_index', 99 );
  function wps_remove_index(){
      remove_menu_page( 'index.php' ); //dashboard
  }

  // Dashboard redirect
  function dashboard_redirect(){

    /////////////// ANO VIGENTE ///////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
    /////////////// ANO VIGENTE ///////////////

    wp_redirect(admin_url('edit.php?post_type=grupos_' . $ano . '_' . $user_empresa));
  }
  add_action('load-index.php','dashboard_redirect');

  // Remove profile
  function remove_profile_menu() {
      remove_submenu_page('users.php', 'profile.php');
      remove_menu_page('profile.php');
  }

  add_action('admin_menu', 'remove_profile_menu');

  // Remove editar profile from menu
  function ya_do_it_admin_bar_remove() {
    global $wp_admin_bar;

    /* **edit-profile is the ID** */
    $wp_admin_bar->remove_menu('edit-profile');
    $wp_admin_bar->remove_node( 'wp-logo' );
  }

  add_action('wp_before_admin_bar_render', 'ya_do_it_admin_bar_remove', 0);

  // Hide new button
  add_action( 'admin_bar_menu', function( $wp_admin_bar ) {
      $wp_admin_bar->remove_node( 'new-content' );
  },999);

}

?>