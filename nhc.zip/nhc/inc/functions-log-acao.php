<?php 

//////////////////////////////////////////////////
// Funciona apenas no login wp-login.php
//////////////////////////////////////////////////

function user_login_log( $user_login, $user ) {

  if($user->ID != 1) { // Se ID do usuario nao for 1 (admin) executa log

      $current_user_id = $user->ID;
      $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

      $ip = $_SERVER['REMOTE_ADDR'];
      $ip_lista = file_get_contents("http://ip-api.com/json/" . $ip);
      $json = json_decode($ip_lista,true);
      $nome = get_user_meta($current_user_id, 'first_name', true);

      $user_info = get_user_by( 'id', $current_user_id );
      $matricula = $user_info->user_login;

      $dispositivo = $_SERVER['HTTP_USER_AGENT'];
      $estado = $json['regionName'];
      $cidade_json = $json['city'];
      $timezone = $json['timezone'];
      $provedor = $json['isp'];
      $empresa_net = $json['org'];
      date_default_timezone_set('America/Sao_Paulo');
      $data = date('d/m/Y');
      $hora = date('H:i:s');

      //////////////////////////// INICIO #################### ////////////////////////////
      // Pego o log atual
      $log_atual = get_user_meta($current_user_id, 'user_log', true);

      // Log a ser acrescentado
$update = 'IP: ' . $ip . '
' . 'Empresa: ' . strtoupper($user_empresa) . '
' . 'Dispositivo: ' . $dispositivo . '
' . 'Cidade: ' . $cidade_json . ' (' . $estado . ') - ' . $timezone . '
'. 'Internet: ' . $provedor . ' - ' . $empresa_net . '
' . 'Data: ' . $data . '
' . 'Hora: ' . $hora . '

####################################

';

      // Log finalizado com a junção dos dois
      $log_final = $update . $log_atual;

      update_user_meta( $current_user_id, 'user_log', $log_final );
      //////////////////////////// FIM #################### ////////////////////////////

      //////////////////////////// INICIO #################### ////////////////////////////
      // Pego o log atual
      $log_atual_option = get_post_meta(451, 'registro_de_atividade_log_' . $user_empresa, true);

      // Log a ser acrescentado no option
$update_log_geral = 'IP: ' . $ip . '
' . 'Empresa: ' . strtoupper($user_empresa) . '
' . 'Nome: ' . $nome . '
' . 'Matrícula: ' . $matricula . '
' . 'Dispositivo: ' . $dispositivo . '
' . 'Cidade: ' . $cidade_json . ' (' . $estado . ') - ' . $timezone . '
' . 'Internet: ' . $provedor . ' - ' . $empresa_net . '
' . 'Data: ' . $data . '
' . 'Hora: ' . $hora . '

####################################

';
    
      // Log finalizado com a junção dos dois
      $log_final_geral = $update_log_geral . $log_atual_option;

      update_post_meta( 451, 'registro_de_atividade_log_' . $user_empresa, $log_final_geral );    
      //////////////////////////// FIM #################### ////////////////////////////

    } // Fim - se nao for admin

}
add_action('wp_login', 'user_login_log', 10, 2);

?>