<?php 

add_action('admin_head', 'custom_css_orientadores');

function custom_css_orientadores() {

	if(current_user_can('orientador')) {
	?>

	<style>
	/* Bloqueia edição dos campos principais de inscrições para orientadores, permitindo alterar apenas nas orientativas */
	html div select#grupos_infos_orientador, .role_is_orientador .cmb-td, #poststuff #titlediv #title {pointer-events: none !important;opacity: 0.6}

	button.cmb-add-group-row, button.cmb-remove-group-row {pointer-events: none !important;opacity: 0.6}
	</style>

	<?php
	}
}

?>