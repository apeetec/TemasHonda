<?php 

//////////////// Sem nome de grupo - Bloqueio de botao de publicar/atualizar ////////////////
function rtp_force_fields_to_post_init() 
{
  wp_enqueue_script('jquery');
}

function rtp_force_fields_to_post( $post ) 
{
  $post_type = get_post_type();
  $validation_message = _("Digite o nome do grupo para prosseguir!");

  /////////////// ANO VIGENTE ///////////////
  $ano_selecao = get_option( 'opcoes_gerais', 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente'];
  /////////////// ANO VIGENTE ///////////////

  if('grupos_' . $ano === $post_type) { ?>
    <script type='text/javascript'>
    // Desativa os membros que já se encontram em grupos
    // Membros removidos através do arquivo inc/functions-cmb2-grupos.php linha 610
    jQuery( document ).ready(function() {
      jQuery(".nome_integrante_js select option:contains('[Já em um grupo]')").attr('disabled','disabled'
        );
    });
    </script>

    <script type='text/javascript'>
    /////////////// Validacoes para os campos
    var status = '<?php $opcoes_gerais = get_option( 'opcoes_gerais', 1 ); $status = $opcoes_gerais['opcoes_gerais_status']; echo $status; ?>';

    jQuery( document ).ready(function() {

      /*
      jQuery('#publish').click(function(){
        var testervar = jQuery('[id^="titlediv"]').find('#title');
        jQuery('#titlewrap div#title_validation').hide();
        if (testervar.val().length < 1)
        { 
          setTimeout(jQuery('#ajax-loading').css('visibility', 'hidden'), 100);
          var validator_snippet = '<div id="title_validation" style="padding: 10px; color: #fff; margin-top: -3px; background: #F55E4F;margin: 1px 0px 2px 0px;"><?php echo $validation_message; ?></div>';                    
          jQuery('[id^="titlediv"]').find('#titlewrap').append(validator_snippet);          
          setTimeout(jQuery('#publish').removeClass('button-primary-disabled'), 100);
            return false;

          return false;
        }
        else {
          jQuery("#titlewrap div#title_validation").hide();
        }
      });*/

      jQuery('#publish').on('click',function(){

        ///////////////// NOME DO GRUPO
        var testervar = jQuery('[id^="titlediv"]').find('#title');
        jQuery('#titlewrap div#title_validation').hide();
        if (testervar.val().length < 1)
        { 
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Digite um nome para o grupo!</p></div></div></div>');    
          return false;
        }

        if(status == 'Inscrição') {
          ///////////////// ORIENTADOR
          if(jQuery('#grupos_infos_orientador').val().length < 1) {
            // Orientador
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione um orientador!</p></div></div></div>');    
            return false;
          }

        }
        if(status == 'Inscrição' || status == '1ª Orientativa') {
          ///////////////// MEMBROS REPETIDOS /////////////////
          var nome_membro_1 = jQuery('#grupos_integrantes_0_grupos_integrantes_nome').val(); 
          var nome_membro_2 = jQuery('#grupos_integrantes_1_grupos_integrantes_nome').val();
          var nome_membro_3 = jQuery('#grupos_integrantes_2_grupos_integrantes_nome').val();
          var nome_membro_4 = jQuery('#grupos_integrantes_3_grupos_integrantes_nome').val(); 
          var nome_membro_5 = jQuery('#grupos_integrantes_4_grupos_integrantes_nome').val();        
          ///////////////// FIM MEMBROS REPETIDOS 
        }

        if(status == '3ª Orientativa') {
          if(jQuery('#grupos_infos_confirma_3_orientativa').val().length < 1) {
            // Confirma 3ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione uma opção de confirmação da 3ª orientativa!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_fator').val().length < 1) {
            // Confirma fator
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Preencha o fator do grupo!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_objetivo').val().length < 1) {
            // Confirma objetivo
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Preencha o objetivo do grupo!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_situacao_atual').val().length < 1) {
            // Confirma situação atual
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Preencha a situação atual do grupo!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_meta_planejada').val().length < 1) {
            // Confirma meta planejada
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Preencha a meta planejada do grupo!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_prazo_execucao').val().length < 1) {
            // Confirma prazo para excecucao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Preencha o prazo para execução da solução!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_3_orientativa_investimento').val().length < 1) {
            // Confirma investimento
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Informe se há necessidade de investimento!</p></div></div></div>');    
            return false;
          }
            // Se tiver investimento e o valor do investimento estiver vazio, exibe mensagem
            if(jQuery('#grupos_infos_3_orientativa_investimento').val() == 'Sim' && jQuery('#grupos_infos_3_orientativa_investimento_valor').val().length < 1) {            
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Foi selecionado que há necessidade de investimento, informe o valor necessário!</p></div></div></div>');    
              return false;
            }
        }

        if(status == '2ª Orientativa') {
          if(jQuery('#grupos_infos_confirma_2_orientativa').val().length < 1) {
            // Confirma 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione uma opção de confirmação da 2ª orientativa!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_turno_apresentador').val().length < 1) {
            // Confirma turno do apresentador - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione o turno do apresentador!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_tema').val().length < 1) {
            // Tema - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Digite o tema do grupo!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_categoria').val().length < 1) {
            // Categoria - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a categoria do grupo!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_analise_situacao').val().length < 1) {
            // Analise de situacao - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a data da análise de situação!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_analise_causas').val().length < 1) {
            // Analise de causas - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a data da análise de causas!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_obj_metas').val().length < 1) {
            // Objetivos e metas - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a data dos objetivos e metas!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_est_imp').val().length < 1) {
            // Estudos e implantação - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a data dos estudos e implantação!</p></div></div></div>');    
            return false;
          }

          if(jQuery('#grupos_infos_2_orientativa_analise_result').val().length < 1) {
            // Análise dos resultados - 2ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a data da análise dos resultados!</p></div></div></div>');    
            return false;
          }
        }        

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_infos_confirma_1_orientativa').val().length < 1) {
            // Confirma 1ª orientativa
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione uma opção de confirmação da 1ª orientativa!</p></div></div></div>');    
            return false;
          }
        }

        ///////////////// PRIMEIRO INTEGRANTE
        if(jQuery('#grupos_integrantes_0_grupos_integrantes_nome').val().length < 1) {
          // Primeiro integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione o nome do primeiro integrante!</p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_0_grupos_integrantes_nome').val().length > 1) {
          if(nome_membro_1 == nome_membro_2 || nome_membro_1 == nome_membro_3 || nome_membro_1 == nome_membro_4 || nome_membro_1 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Os integrantes não podem ser repetidos! Verifique e tente novamente. 1</p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_0_grupos_integrantes_funcao').val().length < 1) {
            // Primeiro integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a função do primeiro integrante!</p></div></div></div>');    
            return false;
          }
        }

        ///////////////// VALIDA SE HÁ 3 OU MAIS
        if(jQuery('#grupos_integrantes_repeat').find('.cmb-repeatable-grouping').length < 3) {
          // 3 ou mais integrantes
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Adicione 3 ou mais integrantes para prosseguir!</p></div></div></div>');    
          return false;
        }  

        ///////////////// SEGUNDO INTEGRANTE
        if(jQuery('#grupos_integrantes_1_grupos_integrantes_nome').val().length < 1) {
          // Segundo integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione o nome do segundo integrante!</p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_1_grupos_integrantes_nome').val().length > 1) {
          if(nome_membro_2 == nome_membro_1 || nome_membro_2 == nome_membro_3 || nome_membro_2 == nome_membro_4 || nome_membro_2 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Os integrantes não podem ser repetidos! Verifique e tente novamente. 2</p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_1_grupos_integrantes_funcao').val().length < 1) {
            // Segundo integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a função do segundo integrante!</p></div></div></div>');    
            return false;
          }
        }

        ///////////////// TERCEIRO INTEGRANTE
        if(jQuery('#grupos_integrantes_2_grupos_integrantes_nome').val().length < 1) {
          // Terceiro integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione o nome do terceiro integrante!</p></div></div></div>');    
          return false;
        } 
        if(jQuery('#grupos_integrantes_2_grupos_integrantes_nome').val().length > 1) {
          if(nome_membro_3 == nome_membro_1 || nome_membro_3 == nome_membro_2 || nome_membro_3 == nome_membro_4 || nome_membro_3 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Os integrantes não podem ser repetidos! Verifique e tente novamente. 3</p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_2_grupos_integrantes_funcao').val().length < 1) {
            // Terceiro integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a função do terceiro integrante!</p></div></div></div>');    
            return false;
          }   
        }            

        ///////////////// QUARTO INTEGRANTE
        if(jQuery('#grupos_integrantes_3_grupos_integrantes_nome').val().length < 1) {
          // Quarto integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione o nome do quarto integrante!</p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_3_grupos_integrantes_nome').val().length > 1) {
          if(nome_membro_4 == nome_membro_1 || nome_membro_4 == nome_membro_2 || nome_membro_4 == nome_membro_3 || nome_membro_4 == nome_membro_5) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Os integrantes não podem ser repetidos! Verifique e tente novamente.</p></div></div></div>');    
              return false;
          }
        }

        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_3_grupos_integrantes_funcao').val().length < 1) {
            // Quarto integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a função do quarto integrante!</p></div></div></div>');    
            return false;
          }
        }

        ///////////////// QUINTO INTEGRANTE
        if(jQuery('#grupos_integrantes_4_grupos_integrantes_nome').val().length < 1) {
          // Quinto integrante - nome
          jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione o nome do quinto integrante!</p></div></div></div>');    
          return false;
        }
        if(jQuery('#grupos_integrantes_4_grupos_integrantes_nome').val().length > 1) {
          if(nome_membro_5 == nome_membro_1 || nome_membro_5 == nome_membro_2 || nome_membro_5 == nome_membro_3 || nome_membro_5 == nome_membro_4) {
            // Se nomes de membros contém duplicatas
              jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Os integrantes não podem ser repetidos! Verifique e tente novamente.</p></div></div></div>');    
              return false;
          }
        } 
        
        if(status == '1ª Orientativa') {
          if(jQuery('#grupos_integrantes_4_grupos_integrantes_funcao').val().length < 1) {
            // Quinto integrante - funcao
            jQuery('#poststuff').append('<div class="cmb_custom_warning_box"><div class="cmb_custom_warning"><div class="cmb_custom_warning_inside"><span id="cmb_custom_close">X</span><p>Selecione a função do quinto integrante!</p></div></div></div>');    
            return false;
          } 
        }              
        
      });    

      // Clique para fechar .cmb_custom_close
      jQuery(document).on('click','#cmb_custom_close',function(){
        jQuery('.cmb_custom_warning_box').fadeOut(300);
      });

    });
  </script>
<?php 
  }
}
add_action( 'admin_init', 'rtp_force_fields_to_post_init' );
add_action( 'edit_form_after_title', 'rtp_force_fields_to_post' );
//////////////// Fim Bloqueio de botao de publicar/atualizar ////////////////

//////////////// Criacao de grupos, campos obrigatorios ////////////////
//////////////// Fim Criacao de grupos, campos obrigatorios ////////////////

// Admin css para usuários apenas
add_action('admin_head', 'my_custom_css_subscriber');

function my_custom_css_subscriber() {

if ( ! current_user_can('manage_options') ) {

?>
  <style>
    tr.user-nickname-wrap {display: none !important}
    .submitbox div#misc-publishing-actions {display: none;}
    .submitbox div#minor-publishing-actions {padding: 10px;display: none;}

    a#back-button {background-color: #0e317a !important;position: fixed;bottom: 0;right: 0;z-index: 99999;margin: 0px;font-weight: bold;color: #fff;padding: 13px 1px;text-transform: uppercase;font-size: 16px;text-decoration: none;width: 100%;text-align: center;display: block;letter-spacing: 1.5px;}

    @media screen and (max-width: 991px) {
      a#back-button {display: block;}
      #wpwrap {padding-bottom: 50px;}
    }
  </style>

<?php } }

?>