<script type='text/javascript'>
	alert('inscricoes');
</script>