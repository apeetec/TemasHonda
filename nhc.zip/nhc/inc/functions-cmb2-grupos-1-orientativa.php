<?php 

// INÍCIO CAMPOS DOS GRUPOS
// INICIO SLIDES
add_action( 'cmb2_admin_init', 'custom_post_grupos_fields_1_orientativa' );

function custom_post_grupos_fields_1_orientativa() {

  /////////////// ANO VIGENTE ///////////////
  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
  $status = $ano_selecao['opcoes_gerais_status_' . $user_empresa];
  /////////////// ANO VIGENTE ///////////////

  $cmb2_demo = new_cmb2_box( array(
    'id'           => 'grupos_infos_etapas_' . $user_empresa,
    'title'        => apply_filters('str_from_lang','Etapas - Leia abaixo as orientações da fase atual','Etapas -
    Lee abajo las pautas de la fase actual'),
    'object_types' => array( 'grupos_' . $ano . '_' . $user_empresa ),
    'closed' => false,
  ) );

  $cmb2_demo->add_field(array(
    'name' => apply_filters('str_from_lang','Novas informações precisam ser preenchidas!','Es necesario completar las nuevas informaciones!'),
    'type' => 'title',
    'id'   => 'grupos_infos_1_orientativa_aviso_' . $user_empresa,
    'show_on_cb' => 'show_if_status',
  ));

  function show_if_status() {

    /////////////// ANO VIGENTE ///////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);
    /////////////// ANO VIGENTE ///////////////

    ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
    // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
    if($user_empresa == 'hsa') {
      $_orientativa_3_texto = 'Classificatória';
    }
    else {
      $_orientativa_3_texto = '3ª Orientativa';
    }
    ################# FIM REGRA ADICIONAL

    /////////////// ANO VIGENTE ///////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
    $status = $ano_selecao['opcoes_gerais_status_' . $user_empresa];
    /////////////// ANO VIGENTE ///////////////

    $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $status = $ano_selecao['opcoes_gerais_status_' . $user_empresa];

    // return 'Inscrição' === $status;

    echo '<p style="margin: 0px;padding: 10px 0px;font-style: italic;font-size: 15px;"><b>Fase:</b> ';

      if($status == 'Inscrição') {
        echo apply_filters('str_from_lang','Inscrição','Inscripción');
      }
      else if($status == '1ª Orientativa') {
        echo apply_filters('str_from_lang','1ª Orientativa','1ra Orientación');
      }
      else if($status == '2ª Orientativa') {
        echo apply_filters('str_from_lang','2ª Orientativa','2da Orientación');
      }
      else if($status == '3ª Orientativa') {
        echo apply_filters('str_from_lang',$_orientativa_3_texto,'3ra Orientación');
      }
      else if($status == 'Bloqueado') {
        echo apply_filters('str_from_lang','Bloqueado','Bloqueado');
      }
      
    echo '</p>
    <p>'.apply_filters('str_from_lang','Importante: Durante essa fase, apenas as informações abaixo poderão ser editadas pelos orientadores:','Importante: Durante esta fase, los tutores solo pueden editar las siguientes informaciones:').'</p>';

    if ($status === 'Inscrição') {
      echo '<p style="margin: 0px;padding: 10px 0px;">'.apply_filters('str_from_lang','Obs: Edições de novos campos serão disponíveis apenas nas fases de orientativas. Aguarde a próxima fase','Nota: Las ediciones de nuevos campos estarán disponibles solo en las fases de orientación. Espere la siguiente fase').'</p>';
    }  
    else if ($status === '1ª Orientativa') {
      echo '<p style="margin: 0px;padding: 10px 0px;">'.apply_filters('str_from_lang','- Campo "função" de cada integrante do grupo<br>- Confirmar a 1ª orientativa','- Campo "función" para cada miembro del grupo <br> - Confirme la 1ra orientación').'
      </p>';
    } 
    else if ($status === '2ª Orientativa') {
      echo '<p style="margin: 0px;padding: 10px 0px;">
      '.
      apply_filters('str_from_lang','
      - Tema<br>
      - Categoria<br>
      - Turno do apresentador<br>
      - Análise de situação<br>
      - Análise das causas<br>
      - Objetivos e metas<br>
      - Estudos e implantação<br>
      - Análise dos resultados<br>
      - Confirmar a 2ª orientativa
      ','
      - Tema del grupo<br>
      - Categoría<br>
      - Turno del presentador<br>
      - Análisis de la situación<br>
      - Análisis de las causas<br>
      - Objetivos y metas<br>
      - Estudios y implementación<br>
      - Análisis de los resultados<br>
      - Confirmar la 2da orientación
      ')
      .'
      </p>';
    } 
    else if ($status === '3ª Orientativa') {
      echo '<p style="margin: 0px;padding: 10px 0px;">
      '.
      apply_filters('str_from_lang','
      - Fator<br>
      - Objetivo<br>
      - Situação atual<br>
      - Meta planejada<br>
      - Prazo para execução da solução<br>
      - Investimentos<br>
      - Confirmar a 
      ' . $_orientativa_3_texto,'
      - Factor<br>
      - Objetivo<br>
      - Situación actual<br>
      - Meta planejada<br>
      - Fecha límite para implementar la solución<br>
      - Inversiones<br>
      - Confirmar la 3ra orientación
      ')
      .'
      </p>';
    } 
    else if ($status === 'Bloqueado') {
      echo '<p style="margin: 0px;padding: 10px 0px;">'.apply_filters('str_from_lang','Funcionalidades restritas, usuários podem apenas acessar a página para visualização do conteúdo do ano','Funciones restringidas, los usuarios solo pueden acceder a la página para ver el contenido del año').'</p>';
    }    

  }

} 
// FIM INTEGRANTES
// FIM CAMPO DOS GRUPOS

?>