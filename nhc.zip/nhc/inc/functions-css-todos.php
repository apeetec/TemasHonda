<?php 

  /////////////// ANO VIGENTE ///////////////
  $ano_selecao = get_option( 'opcoes_gerais', 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente'];
  $status = $ano_selecao['opcoes_gerais_status'];
  /////////////// ANO VIGENTE ///////////////

add_action('admin_head', 'custom_css_integrantes');

function custom_css_integrantes() { ?>

<style>
/* Avoid orientador table to be sortable */
table.wp-list-table th[id*="grupos_infos_orientador"] {pointer-events: none}
table.wp-list-table th[id*="grupos_infos_orientador"] a {color: #2c3338;}

<?php if($status != 'Inscrição' && current_user_can('coordenador')) { ?>
/* Remove botões de adicionar grupo se não for fase inscrição e se for orientador */
#wpbody-content .wrap > a.page-title-action {display: none;}
#adminmenu .wp-has-current-submenu ul {padding: 0px;}
#adminmenu .wp-has-current-submenu ul > li {display: none;}
<?php } ?>
table.wp-list-table tr.wp-locked .row-actions {position: static;}
.postbox-container div#grupos_infos_etapas h2 {pointer-events: none}
.postbox-container div#grupos_infos_etapas .handle-actions {display: none;}
.postbox-container .postbox-header h2 {cursor: default !important}
.trofeus #trofeu {max-width: 30px;}
.trofeus ul li {}
.trofeus ul li input {}
.trofeus ul li label {}
.trofeus ul li img {}
.postbox-header h2.ui-sortable-handle {pointer-events: all;}
.postbox-header h2.ui-sortable-handle span#expand-warning {display: block;position: initial;float: none;text-align: left;width: 100%;font-weight: normal;font-style: italic;margin-left: 10px;font-size: 14px;letter-spacing: 0.1px;max-width: 670px;}
.postbox-header button.handle-order-higher, .postbox-header button.handle-order-lower {display: none;}
.divisor-top {margin-top: 15px !important}
#wpadminbar li#wp-admin-bar-view {display: none;}
.cmb2-metabox .box3_no {width: 100%;max-width: calc(100%/3);float: left;}
.cmb2-metabox .select2-container {width: 300px !important;max-width: 300px;}
.campo_desativado .cmb-td {pointer-events: none;opacity: 0.6;}
.cmb_custom_warning_box {position: fixed;top: 0;z-index: 99999;background-color: rgba(0, 0, 0, 0.4);width: 100%;left: 0;height: 100%;}
.cmb_custom_warning_box .cmb_custom_warning {align-content: center;align-items: center;display: grid;height: 100%;width: 100%;}
.cmb_custom_warning_box .cmb_custom_warning_inside {background-color: #fff;width: auto;max-width: 500px;margin: 0 auto;padding: 20px;position: relative;}
.cmb_custom_warning #cmb_custom_close {position: absolute;right: 0;top: 0;text-decoration: none;color: #ce3d3d;
  font-size: 20px;font-weight: bold;padding: 8px;}
.cmb_custom_warning #cmb_custom_close:hover {cursor: pointer}
.cmb_custom_warning p {text-align: center;font-size: 20px;}

@media screen and (max-width: 991px) {
  .cmb-type-group .cmb-th + .cmb-td, .cmb2-postbox .cmb-th + .cmb-td {width: 100% !important}
}

@media screen and (max-width: 500px) {
  .cmb_custom_warning_box .cmb_custom_warning_inside {margin: 0px 15px;}
}
</style>

<?php
}

?>