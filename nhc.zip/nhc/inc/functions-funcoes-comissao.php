<?php 

// Função para comissao
if(current_user_can('comissao')) {

  // Remove items from menu
  add_action( 'admin_menu', 'wps_remove_tools', 99 );
  function wps_remove_tools(){
      // remove_menu_page( 'tools.php' ); //dashboard
      remove_menu_page( 'export-personal-data.php' ); //dashboard
      remove_menu_page( 'options-general.php' ); //dashboard
  }

  // Another hook
  add_action( 'admin_init', 'wpse_136058_remove_menu_pages' );
  function wpse_136058_remove_menu_pages() {
      remove_menu_page( 'limit-login-attempts' );
      remove_menu_page( 'wp_pda_options' );
      remove_menu_page( 'loco' );
  }

  // Redirecionar caso acesse tools/options-general
  global $pagenow;
  if (( $pagenow == 'options-general.php' || $pagenow == 'export-personal-data.php' || $pagenow == 'erase-personal-data.php' )) {

    wp_redirect(admin_url());
    
  }

}

?>