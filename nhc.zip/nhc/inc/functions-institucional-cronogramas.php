<?php 

////////////// Cronogramas
add_action( 'cmb2_admin_init', 'custom_post_anos_cronograma' );
function custom_post_anos_cronograma() {

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

    foreach($terms as $term) {

      if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

          $cmb = new_cmb2_box( array(
            'id'           => 'cronograma_group_' . $term->slug,
            'title'         => apply_filters('str_from_lang','Bloco de cronogramas','Bloque de cronología') . ' - ' . $term->name,
            'object_types'  => array( 'anos' ), // Post type
            'rows_limit'   => 15, // custom attribute to use in our JS
            'closed'     => true,
          ) );

          $group_id = $cmb->add_field( array(
            'id'          => 'group_cronograma_' . $term->slug,
            'type'        => 'group',
            'description' => apply_filters('str_from_lang','Clique em \'adicionar novo cronograma\' para adicionar uma nova data na linha do tempo','Haga clic en \'agregar nueva cronología\' para agregar una nueva fecha a la línea de tiempo'),
            // 'repeatable'  => false, // use false if you want non-repeatable group
            'options'     => array(
              'group_title'       => apply_filters('str_from_lang','Cronograma #{#}','Cronología #{#}'), // since version 1.1.4, {#} gets replaced by row number
              'add_button'        => apply_filters('str_from_lang','Adicionar novo cronograma','Agregar nueva cronología'),
              'remove_button'     => apply_filters('str_from_lang','Remover cronograma','Eliminar cronología'),
              'sortable'          => true,
              'closed'         => true, // true to have the groups closed by default
              // 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'cmb2' ), // Performs confirmation before removing group.
              ),
          ) );

          $cmb->add_group_field( $group_id, array(
            'name' => apply_filters('str_from_lang','Título','Título'),
            'id'   => 'title_' . $term->slug,
            'type' => 'text',
            'attributes'  => array(
              // 'required'    => 'required',
            ),
          ) );

          $cmb->add_group_field( $group_id, array(
          'name' => apply_filters('str_from_lang','Texto customizado','Texto personalizado'),
          'description' => apply_filters('str_from_lang','Este texto substituirá as datas caso haja algo escrito','Este texto reemplazará las fechas si hay algo escrito'),
          'id'   => 'custom_text_' . $term->slug,
          'type' => 'text',
          ) );

          $cmb->add_group_field( $group_id, array(
            'name' => apply_filters('str_from_lang','Data #1 (de:)','Fecha #1 (del:)'),
            // 'description' => '<br><br>Atenção: seletores de data utilizam o padrão americano: mês/dia/ano, as conversões para dia/mês serão feitas na exibição das datas no site. Será utilizada no modelo: de <b style="font-weight: bolder">XX</b> até XX',
            'id'   => 'date_1_' . $term->slug,
            'type' => 'text_date',
            'date_format'       => 'd-m-Y',
            // Inicio traducao
              'attributes' => array(
                // CMB2 checks for datepicker override data here:
                'data-datepicker' => json_encode( array(
                  'dayNames' => array( 
                    apply_filters('str_from_lang','Seg','Lu'), 
                    apply_filters('str_from_lang','Ter','Ma'), 
                    apply_filters('str_from_lang','Qua','Mi'), 
                    apply_filters('str_from_lang','Qui','Ju'), 
                    apply_filters('str_from_lang','Sex','Vi'), 
                    apply_filters('str_from_lang','Sab','Sa'), 
                    apply_filters('str_from_lang','Dom','Do')
                  ),
                  'dayNamesMin' => array( 
                    apply_filters('str_from_lang','Seg','Lu'), 
                    apply_filters('str_from_lang','Ter','Ma'), 
                    apply_filters('str_from_lang','Qua','Mi'), 
                    apply_filters('str_from_lang','Qui','Ju'), 
                    apply_filters('str_from_lang','Sex','Vi'), 
                    apply_filters('str_from_lang','Sab','Sa'), 
                    apply_filters('str_from_lang','Dom','Do')
                  ),
                  'monthNamesShort' => explode( ',',
                    apply_filters('str_from_lang','Jan','En') . ',' .
                    apply_filters('str_from_lang','Fev','Feb') . ',' .
                    apply_filters('str_from_lang','Mar','Mar') . ',' .
                    apply_filters('str_from_lang','Abr','Abr') . ',' .
                    apply_filters('str_from_lang','Mai','May') . ',' .
                    apply_filters('str_from_lang','Jun','Jun') . ',' .
                    apply_filters('str_from_lang','Jul','Jul') . ',' .
                    apply_filters('str_from_lang','Ago','Ago') . ',' .
                    apply_filters('str_from_lang','Set','Sept') . ',' .
                    apply_filters('str_from_lang','Out','Oct') . ',' .
                    apply_filters('str_from_lang','Nov','Nov') . ',' .
                    apply_filters('str_from_lang','Dez','Dic')
                  ),
                  // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                  // 'maxDate' => '+1m',
                ) ),                
              ),
              // Fim traducao
          ) );

          $cmb->add_group_field( $group_id, array(
            'name' => apply_filters('str_from_lang','Data #2 (até:)','Fecha #2 (al:)'),
            // 'description' => '<br><br>Atenção: seletores de data utilizam o padrão americano: mês/dia/ano, as conversões para dia/mês serão feitas na exibição das datas no site. Será utilizada no modelo: de XX até <b style="font-weight: bolder">XX</b>',
            'id'   => 'date_2_' . $term->slug,
            'type' => 'text_date',
            'date_format'       => 'd-m-Y',
            // Inicio traducao
              'attributes' => array(
                // CMB2 checks for datepicker override data here:
                'data-datepicker' => json_encode( array(
                  'dayNames' => array( 
                    apply_filters('str_from_lang','Seg','Lu'), 
                    apply_filters('str_from_lang','Ter','Ma'), 
                    apply_filters('str_from_lang','Qua','Mi'), 
                    apply_filters('str_from_lang','Qui','Ju'), 
                    apply_filters('str_from_lang','Sex','Vi'), 
                    apply_filters('str_from_lang','Sab','Sa'), 
                    apply_filters('str_from_lang','Dom','Do')
                  ),
                  'dayNamesMin' => array( 
                    apply_filters('str_from_lang','Seg','Lu'), 
                    apply_filters('str_from_lang','Ter','Ma'), 
                    apply_filters('str_from_lang','Qua','Mi'), 
                    apply_filters('str_from_lang','Qui','Ju'), 
                    apply_filters('str_from_lang','Sex','Vi'), 
                    apply_filters('str_from_lang','Sab','Sa'), 
                    apply_filters('str_from_lang','Dom','Do')
                  ),
                  'monthNamesShort' => explode( ',',
                    apply_filters('str_from_lang','Jan','En') . ',' .
                    apply_filters('str_from_lang','Fev','Feb') . ',' .
                    apply_filters('str_from_lang','Mar','Mar') . ',' .
                    apply_filters('str_from_lang','Abr','Abr') . ',' .
                    apply_filters('str_from_lang','Mai','May') . ',' .
                    apply_filters('str_from_lang','Jun','Jun') . ',' .
                    apply_filters('str_from_lang','Jul','Jul') . ',' .
                    apply_filters('str_from_lang','Ago','Ago') . ',' .
                    apply_filters('str_from_lang','Set','Sept') . ',' .
                    apply_filters('str_from_lang','Out','Oct') . ',' .
                    apply_filters('str_from_lang','Nov','Nov') . ',' .
                    apply_filters('str_from_lang','Dez','Dic')
                  ),
                  // 'minDate' => '+1d', // 1 dia a partir de hoje - Outros valores: +2y +1m +1w +4d
                  // 'maxDate' => '+1m',
                ) ),                
              ),
              // Fim traducao
          ) );

      } // IF

    } // End foreach

} // End function

// Repetição
function js_limit_group_repeat( $post_id, $cmb ) {

  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  // Grab the custom attribute to determine the limit
  $limit = absint( $cmb->prop( 'rows_limit' ) );
  $limit = $limit ? $limit : 0;
  ?>
  <script type="text/javascript">
  jQuery(document).ready(function($){
    // Only allow 3 groups
    var limit            = <?php echo $limit; ?>;
    var fieldGroupId     = 'group_cronograma_<?php echo $user_empresa; ?>'; // This should match the ID of your group field.
    var $fieldGroupTable = $( document.getElementById( fieldGroupId + '_repeat' ) );

    var countRows = function() {
      return $fieldGroupTable.find( '> .cmb-row.cmb-repeatable-grouping' ).length;
    };

    var disableAdder = function() {
      $fieldGroupTable.find('.cmb-add-group-row').prop( 'disabled', true );
    };
    
    // Se quantidade for maior ou igual, desativa
    if ( countRows() >= limit ) {
      disableAdder();
    }     

    var enableAdder = function() {
      $fieldGroupTable.find('.cmb-add-group-row').prop( 'disabled', false );
    };
    
    // Se quantidade for menor que o limite, ativa
    if ( countRows() < limit ) {
                  enableAdder();
              }

    $fieldGroupTable
      .on( 'cmb2_add_row', function() {
        // Se quantidade for maior ou igual, desativa
        if ( countRows() >= limit ) {
          disableAdder();
        }
      })
      // Se quantidade for menor que o limite, ativa
      .on( 'cmb2_remove_row', function() {
        if ( countRows() < limit ) {
          enableAdder();
        }
      });
  });
  </script>
  <?php
}

// Replace `field_group_test` with the ID of the CMB2 meta box in question e.g. this
// should match the value of $cmb->id in the above example.
add_action( 'cmb2_after_post_form_cronograma_group', 'js_limit_group_repeat', 10, 2 );

?>