<?php 

// INICIO SLIDES
add_action( 'cmb2_admin_init', 'options_page_meu_slider' );

function options_page_meu_slider() {

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

  foreach($terms as $term) {

    if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

      $prefix = 'tema_slider_';

      $cmb_group = new_cmb2_box( array(
        'id'           => 'meu_slider_' . $term->slug,
        'title'        => apply_filters('str_from_lang','Slider Home','Slider Home') . ' - ' . $term->name,
        'object_types' => array( 'anos' ),
        'closed'     => true,
      ) );

      // $group_field_id is the field id string, so in this case: $prefix . 'demo'
      $group_field_id = $cmb_group->add_field( array(
        'id'          => $prefix . 'slides_' . $term->slug,
        'type'        => 'group',
        //'description' => 'Preencha as informações para criar novos slides',
        'options'     => array(
          'group_title'    => apply_filters('str_from_lang','Slide #{#}','Slide #{#}'), // {#} gets replaced by row number
          'add_button'     => apply_filters('str_from_lang','Adicionar Slide','Añadir Slide'),
          'remove_button'  => apply_filters('str_from_lang','Remover Slide','Eliminar Slide'),
          'sortable'       => true,
          'closed'      => true, // true to have the groups closed by default
          'remove_confirm' => apply_filters('str_from_lang','Deseja realmente remover este slide?','¿Realmente desea eliminar esta imagen?'), // Performs confirmation before removing group.
        ),
      ) );

      $cmb_group->add_group_field( $group_field_id, array(
        'name' => apply_filters('str_from_lang','Selecione uma imagem','Seleccione una imagen'),
        'id'   => $prefix . 'image_' . $term->slug,
        'type' => 'file',
        'text'    => array(
          'add_upload_file_text' => apply_filters('str_from_lang','Adicionar imagem','Anãdir imagen') // Change upload button text. Default: "Add or Upload File"
        ),
        'desc' => apply_filters('str_from_lang','Mantenha as imagens do mesmo tamanho para que não fique desproporcional. Tamanho sugerido: 1900x500','Mantenga las imágenes del mismo tamaño para que no sean desproporcionadas. Ej: 1900x500'),
          'options' => array(
            'url' => false, // Hide the text input for the url
          ),
            'query_args' => array(
              'type' => array(
              'image/gif',
              'image/jpeg',
              'image/jpg',
              'image/png',
            ),
          ),
      ) );

      $cmb_group->add_group_field( $group_field_id, array(
        'name'       => apply_filters('str_from_lang','Redirecionar para:','Redirigir a:'),
        'id'         => $prefix . 'link_' . $term->slug,
        'desc'       => apply_filters('str_from_lang','(opcional)','(opcional)'),
        'type'       => 'text_url',
          'attributes'  => array(
            'placeholder' => apply_filters('str_from_lang','Digite o link a ser redirecionado','Introduzca el enlace para ser redirigido'),
          ),
        // 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
      ) );

      $cmb_group->add_group_field( $group_field_id, array(
        'name' => apply_filters('str_from_lang','Abrir link em nova aba?','¿Abrir enlace en una nueva pestaña?'),
        //'desc' => esc_html__( 'field description (optional)', 'cmb2' ),
        'id'   => $prefix . 'newtab_' . $term->slug,
        'type' => 'checkbox',
      ) );

    } // IF

  } // End foreach

} // End function
// FIM SLIDES

?>