<?php 

// Função para membro-orientador
if(current_user_can('membro-orientador')) {

  /////////////// ANO VIGENTE ///////////////
  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
  /////////////// ANO VIGENTE ///////////////

  // Pega o ID do post sendo editado
  $current_post_id = $_GET['post'];

  // Pega o ID do membro-orientador logado
  $current_user_id = get_current_user_id();

  $posts = get_posts(
        array(
            'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
            'posts_per_page' => -1,
            'meta_key' => 'grupos_infos_membro_orientador_' . $ano . '_' . $user_empresa, 
    		    'meta_value' => $current_user_id
        )
    );

  $membro_orientadores_posts = array();

    // Visita cada grupo e criar array com grupos em que o membro-orientador está
    foreach( $posts as $post ) {

      // Array de grupos em que é membro-orientador
      $membro_orientadores_posts[] = $post->ID;

   }

  // print_r($membro_orientadores_posts);

  // Redirecionar caso acesse a listagem de grupos ou grupos em que não pode e ditar
  global $pagenow;

  // Se a página de criação de grupos for a que estiver aberta, redireciona pois não há permissão
  // Se a página de edição de grupos não estiver no array de grupos que ele é orientador, redireciona pois não há permissão

  /* Condição antiga, estava dando problema e acusando o redirecionamento ao atualizar
  'post-new.php' === $pagenow || 'post.php' === $pagenow && !array_keys($membro_orientadores_posts,$current_post_id) */

  if ( 'post-new.php' === $pagenow || isset($_GET['action']) && $_GET['action'] === 'edit' && !array_keys($membro_orientadores_posts,$current_post_id) ) {

    wp_redirect(home_url());
    exit;
    
  }

}

?>