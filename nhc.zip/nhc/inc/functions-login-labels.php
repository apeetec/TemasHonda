<?php 

/// Muda texto do e-mail
if ( $GLOBALS['pagenow'] === 'wp-login.php' ) {
// #################### Português #################### //
add_filter(  'gettext',  'register_text_matricula'  );
function register_text_matricula( $translating ) {
	    $translated = str_ireplace(  'Nome de usuário ou endereço de e-mail', 'Matrícula',  $translating );
	    return $translated;
	}
add_filter(  'gettext',  'register_text_senha'  );
function register_text_senha( $translating ) {
	    $translated = str_ireplace(  'Senha', 'Data de nascimento: DDMMAAAA',  $translating );
	    return $translated;
	}
// #################### Fim Português #################### //

// #################### Espanhol #################### //
add_filter(  'gettext',  'register_text_matricula_es'  );
function register_text_matricula_es( $translating ) {
	    $translated = str_ireplace(  'Nome de usuário ou endereço de e-mail', 'Matrícula',  $translating );
	    return $translated;
	}
add_filter(  'gettext',  'register_text_senha_es'  );
function register_text_senha_es( $translating ) {
	    $translated = str_ireplace(  'Senha', 'Fecha de nacimiento: DDMMAAAA',  $translating );
	    return $translated;
	}
// #################### Fim Espanhol #################### //

// #################### Ingles #################### //
add_filter(  'gettext',  'register_text_matricula_en'  );
function register_text_matricula_en( $translating ) {
	    $translated = str_ireplace(  'Username or Email Address', 'Honda ID',  $translating );
	    return $translated;
	}
add_filter(  'gettext',  'register_text_senha_en'  );
function register_text_senha_en( $translating ) {
	    $translated = str_ireplace(  'Password', 'Birth date: DDMMYYYY',  $translating );
	    return $translated;
	}
// #################### Fim Ingles #################### //
}
?>