<?php 

// CMB2 Opções gerais
add_action( 'cmb2_admin_init', 'cmb2_registros_log' );

function cmb2_registros_log() {

  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

  foreach($terms as $term) {

    if($term->slug == get_user_meta(get_current_user_id(), 'user_infos_empresas', true) || current_user_can('administrator')) {

      $cmb_options = new_cmb2_box( array(
        'id'           => 'registro_de_atividade_' . $term->slug,
        'title'        => apply_filters('str_from_lang','Registro de atividades','Registro de actividad') . ' - ' . $term->name,
        'object_types' => array( 'page' ),
        'closed' => true,
        'show_on'      => array(
          'id' => array( 451 ), // ID da página de registros
        ),
      ) );

      $cmb_options->add_field( array(
        'name'     => apply_filters('str_from_lang','Log de informações','Registro de información'),
        'id'       => 'registro_de_atividade_log_' . $term->slug,
        'type'     => 'textarea',
      ) );

    } // IF

  } // End foreach

} // End function
// Fim opções gerais
?>