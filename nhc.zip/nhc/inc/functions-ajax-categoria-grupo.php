<?php
// Função para atualizar a categoria
add_action('wp_ajax_atualizar_metacampo_categoria', 'atualizar_metacampo_categoria_callback');
add_action('wp_ajax_nopriv_atualizar_metacampo_categoria', 'atualizar_metacampo_categoria_callback');
function atualizar_metacampo_categoria_callback() {
    if (
        !isset($_POST['post_id']) ||
        !isset($_POST['categoria'])
    ) {
        echo 'Dados incompletos.';
        wp_die();
    }

    $post_id = intval($_POST['post_id']);
    $categoria = $_POST['categoria'];
    $ano_atual = date('Y');
    // Nome do campo no CMB2
    $meta_key = 'categorias_grupos_infos_orientador' . $ano_atual . '_' . 'hsa';
    update_post_meta($post_id, $meta_key, $categoria);
    echo 'Categoria marcado com sucesso!';
    wp_die();
}
?>