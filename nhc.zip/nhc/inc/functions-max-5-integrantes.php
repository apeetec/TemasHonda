<?php 

/////////////// ANO VIGENTE ///////////////
$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];
/////////////// ANO VIGENTE ///////////////

/////////////////// MAXIMO 5 INTEGRANTES
$repeater_metaboxes = array('grupos_infos_' . $ano . '_' . $user_empresa); // IDs of the metabox containing the repeater group

foreach ($repeater_metaboxes as $value) {
    add_action( 'cmb2_after_post_form_'.$value, 'js_limit_group_repeat_integrantes', 10, 2);
}

function js_limit_group_repeat_integrantes( $post_id, $cmb ) {
  // Grab the custom attribute to determine the limit
  $limit = absint( $cmb->prop( 'rows_limit' ) );
  $limit = $limit ? $limit : 0;
  $group =  $cmb->prop( 'groupId' )
  ?>

  <script type="text/javascript">
  <?php $current_user_id = get_current_user_id(); $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true); $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 ); $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa]; ?>

  jQuery(document).ready(function($){

    // Only allow 3 groups
    var limit            = <?php echo $limit; ?>;
    var fieldGroupId     = '<?php echo $group; ?>'; 
    var $fieldGroupTable = $( document.getElementById( fieldGroupId + '_repeat' ) );
    var countRows = function() {
      return $fieldGroupTable.find( '> .cmb-row.cmb-repeatable-grouping' ).length;
    };
    var disableAdder = function() {
      $fieldGroupTable.find('.cmb-add-group-row.button-secondary').prop( {disabled: true} );
    };
    var enableAdder = function() {
      $fieldGroupTable.find('.cmb-add-group-row.button-secondary').prop( {disabled: false} );
    };
    $fieldGroupTable
      .on( 'cmb2_add_row', function() {
        if ( countRows() >= limit ) {
          disableAdder();
        }
      })
      .on( 'cmb2_remove_row', function() {
        if ( countRows() < limit ) {
          enableAdder();
        }
      });

    // CASO SAIA DA PÁGINA, VERIFICA SE JÁ HÁ 5 INTEGRANTES AO VOLTAR
    var count = $('#grupos_integrantes_<?php echo $ano . '_' . $user_empresa; ?>_repeat').children('.cmb-repeatable-grouping').length;
    if(count >= 5){
      disableAdder();
    }

  });
  </script>
  <?php
}
//////////////// FIM MAXIMO 5 INTEGRANTES

?>