<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

?>

<div class="page<?php echo get_the_ID(); ?> page-single">          
  <div class="container">

  <?php get_template_part('legenda'); ?>

  <?php if($_GET && $_GET['confirm'] == 'true' && !empty($_GET['grupo'])) {
  update_post_meta($_GET['grupo'],'grupos_infos_orientador_check_' . $ano . '_' . $user_empresa,'on');  
  ?>
  <p id="sucesso-block">
  <?php echo apply_filters('str_from_lang','Confirmação de participação realizada com sucesso!','Confirmación de participación realizada con éxito! '); ?>
  </p>
  <?php } ?>

  <div class="grupos-list orientadores space-top" id="gruposorientador">
    <div class="container">
    <h2><?php echo apply_filters('str_from_lang','Grupos em que você é orientador(a): <span>Ano vigente ('.$ano.')</span>','Grupos en los que eres tutor(a): <span>Año actual ('.$ano.')</span>'); ?></h2>

    <div class="body">
        <?php

          $args = array(
              'post_type' => 'grupos_' . $ano . '_' .$user_empresa,
              'post_status' => array('publish'),
              'posts_per_page' => -1
            );

          $loop = new WP_Query( $args );

          if ( $loop->have_posts() ) { ?>

          <div class="flow-root head">
            <div class="single">
              <p><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></p>
            </div>
            <div class="single" id="middle">
              <p><?php echo apply_filters('str_from_lang','Coordenador e integrantes','Coordinador y miembros'); ?></p>
            </div>
            <div class="single">
              <p><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></p>
            </div>
          </div>

          <?php

          if ($loop->have_posts())
          
          while ( $loop->have_posts() ) : $loop->the_post();

            $ids_integrantes = array();
            $orientador = get_post_meta( get_the_ID(), 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
            $integrantes = get_post_meta( get_the_ID(), 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
            $confirmados = get_post_meta( get_the_ID(), 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );
            // Se orientador confirmou participação
            $orientador_check = get_post_meta( get_the_ID(), 'grupos_infos_orientador_check_' . $ano . '_' . $user_empresa, true );

            $coordenador = get_post_field( 'post_author', get_the_ID() );

            $confirmados = ltrim($confirmados);

            $confirma_1_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_1_orientativa_' . $ano . '_' . $user_empresa, true ); 
            $confirma_2_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_2_orientativa_' . $ano . '_' . $user_empresa, true );
            $confirma_3_orientativa = get_post_meta( get_the_ID(), 'grupos_infos_confirma_3_orientativa_' . $ano . '_' . $user_empresa, true );                     

            $classificatorias = get_post_meta( get_the_ID(), 'integrantes_classificatorias_' . $ano . '_' . $user_empresa, true );
            
              $count = $count + 1;

              // Se usuário está, exibe confirmação
              if ($current_user_id == $orientador) { ?>

              <div class="flow-root corpo">
                <div class="single">
                  <p id="title-name">
                    <?php the_title(); ?>
                  </p>
                </div>
                <div class="single" id="integrantes">

                  <?php
                  if(!empty($coordenador)) { ?>
                  <b id="ori"><?php echo apply_filters('str_from_lang','Coordenador','Coordinador'); ?>: </b><p><?php echo get_user_meta($coordenador, 'first_name', true); ?></p>
                  <?php }
                  // Exibe orientador

                  // if(!empty($orientador)) { ?>
                  <!-- <b id="ori">Orientador: </b><p><?php echo $orientador; ?></p> -->
                  <?php //} 

                  if($integrantes) {

                  echo '<b id="int">'.apply_filters('str_from_lang','Integrantes','Miembros').': </b>';
                  foreach((array) $integrantes as $key => $entry ){

                  // Contagem de integrantes
                  $quantidade_integrantes = $quantidade_integrantes + 1;

                  ?>
                   <p>
                    <?php $id = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                    $integrante_nome = get_user_meta($id, 'first_name', true);
                    echo mb_strimwidth($integrante_nome, 0, 30, "...");

                    // Exibe se integrante confirmou ou não
                    $confirmados_array = explode(" ", $confirmados);  

                    // Pega matricula (username) pelo ID do membro no loop
                    $membro_infos = get_user_by( 'id', $id );
                    $membro_matricula = $membro_infos->user_login;

                    // Compara se existe na array de confirmados
                    if (in_array($membro_matricula,$confirmados_array)) {
                      echo '<i class="fas fa-check-circle"></i>';
                    }
                    else {
                      echo '<i class="fas fa-exclamation-circle"></i>';
                    }
                    ?>
                   </p>
                  <?php
                    } // Fim foreach integrantes

                  } // fim if($integrantes)

                  $integrantes_confirmados = 0;
                  foreach($confirmados_array as $confirmed) {

                    // Contagem de integrantes confirmados
                    $integrantes_confirmados = $integrantes_confirmados + 1;

                  }

                  ?>
                </div>
                <div class="single">

                      <?php if ($status == 'Inscrição'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '1ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '2ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                      <?php }else if($status == '3ª Orientativa'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                        <?php if($status != 'Inscrição' && $status != 'Bloqueado') { ?>
                          <span id="status-label"><?php echo apply_filters('str_from_lang','Confirmação','Confirmación'); ?>: 
                            <?php

                            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                            if($user_empresa == 'hsa') {
                              if($status == '3ª Orientativa') {
                                echo 'Classificatória';
                              }
                              else {
                                echo $status;
                              }
                            }
                            else {
                              echo $status;
                            }
                            ################# FIM REGRA ADICIONAL

                            ?>:</span>
                          <span id="status-confirma">
                            <?php

                            if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
                            ) {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Não','No').'</span>';
                            }
                            else if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
                            ) {
                              echo '<span class="status-confirma" id="confirmado">Status: '.apply_filters('str_from_lang','Sim','Sí').'</span>';
                            }

                            else {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Pendente','Pendiente').'</span>';
                            }
                            ?>
                          </span>
                        <?php } ?>
                      <?php }else if($status == 'Classificatória'){ ?>
                        <a id="edit" href="<?php echo get_site_url(); ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit"><?php echo apply_filters('str_from_lang','Editar','Editar'); ?></a>
                        <?php if($status != 'Inscrição' && $status != 'Bloqueado') { ?>
                          <span id="status-label"><?php echo apply_filters('str_from_lang','Confirmação','Confirmación'); ?>: 
                            <?php

                            ################# REGRA ADICIONAL: Exibie "Classificatória" ao invés de 3ª Orientativa para as empresas na condição abaixo
                            // OBS do dev: usado apenas este ano por causa do curto prazo, verificar próximos anos para voltar ao normal
                            if($user_empresa == 'hsa') {
                              if($status == '3ª Orientativa') {
                                echo 'Classificatória';
                              }
                              else {
                                echo $status;
                              }
                            }
                            else {
                              echo $status;
                            }
                            ################# FIM REGRA ADICIONAL

                            ?>:</span>
                          <span id="status-confirma">
                            <?php

                            if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Não' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Não' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Não' 
                            ) {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Não','No').'</span>';
                            }
                            else if(
                            $status == '1ª Orientativa' && $confirma_1_orientativa == 'Sim' ||
                            $status == '2ª Orientativa' && $confirma_2_orientativa == 'Sim' ||
                            $status == '3ª Orientativa' && $confirma_3_orientativa == 'Sim'
                            ) {
                              echo '<span class="status-confirma" id="confirmado">Status: '.apply_filters('str_from_lang','Sim','Sí').'</span>';
                            }

                            else {
                              echo '<span class="status-confirma" id="pendente">Status: '.apply_filters('str_from_lang','Pendente','Pendiente').'</span>';
                            }
                            ?>
                          </span>
                        <?php } ?>
                      <?php }else{ }?>
                    
                  </div>
              </div>

              <?php

              } // Verifica se existe no array de matriculas confirmadas                      

            // }

          ?>                  

          <?php endwhile;

              } else {
                  echo '<div id="text"><p>Você ainda não é orientador(a) de nenhum grupo.</div>';
              }

          wp_reset_postdata();

        ?>
      </div>
    </div>
  </div>

  </div>
</div>