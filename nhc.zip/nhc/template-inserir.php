<?php
/**
 * Template Name: Inserir usuários
 * Description: Template para importação em massa de usuários via CSV
 */

// Security check
if (!current_user_can('create_users')) {
    wp_die('Você não tem permissão para acessar esta página.');
}

get_header(); 
?>
<style>
.content-text .container, .box-upload {padding: 0 2rem;}
.content-text h1 {font-size: 3rem; margin-top: 40px;}
.content-text .divider {height: 1px; background-color: #e0e0e0; display: block; width: 100%; margin: 15px 0;}
.content-text p {font-size: 1.3rem; line-height: 2.2rem;}
.box-text {margin-top: 20px;}
.box-upload {margin-top: 70px;}
.import-results {display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin: 40px 0;}
.grid-div {height: 400px; overflow-y: auto; border: 1px solid #e0e0e0; padding: 15px; background: #f9f9f9;}
.grid-div h3 {margin-top: 0; color: #333; font-size: 1.5rem;}
.grid-div p {border: 1px solid #e0e0e0; padding: 10px; margin: 5px 0; background: white;}
.bnt-download {display: inline-block; padding: 20px; background-color: #8fcdff; font-weight: 400; margin-top: 40px; text-decoration: none; color: #000; border-radius: 4px; transition: background-color 0.3s;}
.bnt-download:hover {background-color: #6bb8ff;}
.upload-button {padding: 15px 30px; background-color: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; margin-top: 15px;}
.upload-button:hover {background-color: #45a049;}
.upload-button:disabled {background-color: #cccccc; cursor: not-allowed;}
.file-input {margin-top: 10px; padding: 10px; border: 2px dashed #ccc; display: inline-block; border-radius: 4px;}
.alert {padding: 15px; margin: 20px 0; border-radius: 4px;}
.alert-warning {background-color: #fff3cd; border-left: 4px solid #ffc107; color: #856404;}
.alert-info {background-color: #d1ecf1; border-left: 4px solid #17a2b8; color: #0c5460;}
.alert-error {background-color: #f8d7da; border-left: 4px solid #dc3545; color: #721c24;}
.alert-success {background-color: #d4edda; border-left: 4px solid #28a745; color: #155724;}
.loading-spinner {display: none; border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 20px auto;}
@keyframes spin {0% {transform: rotate(0deg);} 100% {transform: rotate(360deg);}}
.progress-info {text-align: center; margin: 20px 0; font-size: 1.2rem; color: #333;}
</style>

<article class="content-text">
    <section class="container">
        <h1>Importação de Usuários</h1>
        <div class="divider"></div>
        
        <div class="alert alert-warning">
            <strong>⚠️ ATENÇÃO:</strong> É de extrema importância que seja realizado o backup de todos os arquivos do site e seu banco de dados antes de prosseguir. Este processo é definitivo e não pode ser interrompido ou revertido!
        </div>
        
        <div class="box-text">
            <div class="alert alert-info">
                <strong>ℹ️ Como funciona:</strong>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Usuários que não existem serão criados</li>
                    <li>Usuários existentes terão seus dados atualizados</li>
                    <li>Unidades, Setores e Empresas serão criados automaticamente se não existirem</li>
                    <li>O arquivo CSV deve usar ponto e vírgula (;) como separador</li>
                </ul>
            </div>
            
            <p>Faça o download do arquivo CSV modelo abaixo para preparar a lista de usuários:</p>
        </div>
    </section>
    
    <section class="container">
        <a href="https://www.hondahcnc.com/wp-content/uploads/2026/04/upload-de-usuarios-1-7.csv" download="modelo-usuarios" class="bnt-download">
            📥 Download do Modelo CSV
        </a>
    </section>
</article>

<article class="box-upload">
    <section class="container">
        <h2>Enviar Arquivo CSV</h2>
        <form id="uploadForm" enctype="multipart/form-data" method="POST">
            <?php wp_nonce_field('csv_user_import', '_wpnonce'); ?>
            <div class="file-input">
                <input type="file" name="csvFile" id="csvFile" accept=".csv" required>
            </div>
            <br>
            <button type="button" class="upload-button" id="uploadButton" onclick="uploadCSV()">
                📤 Enviar e Processar
            </button>
        </form>
        <div class="loading-spinner" id="loadingSpinner"></div>
        <div class="progress-info" id="progressInfo"></div>
    </section>
</article>

<article class="box-results">
    <section class="container">
        <div id="result"></div>
    </section>
</article>

<?php get_footer(); ?>

<script>
function uploadCSV() {
    // Validate file selection
    var fileInput = document.getElementById('csvFile');
    if (!fileInput.files || !fileInput.files[0]) {
        showMessage('Por favor, selecione um arquivo CSV.', 'error');
        return;
    }
    
    // Validate file extension
    var fileName = fileInput.files[0].name;
    var fileExtension = fileName.split('.').pop().toLowerCase();
    if (fileExtension !== 'csv') {
        showMessage('Por favor, selecione apenas arquivos CSV.', 'error');
        return;
    }
    
    // Confirm action
    if (!confirm('Tem certeza que deseja importar os usuários? Este processo pode demorar alguns minutos.')) {
        return;
    }
    
    // Prepare form data
    var formData = new FormData(document.getElementById('uploadForm'));
    
    // Update UI
    var button = document.getElementById('uploadButton');
    var spinner = document.getElementById('loadingSpinner');
    var progressInfo = document.getElementById('progressInfo');
    var resultDiv = document.getElementById('result');
    
    button.disabled = true;
    button.textContent = '⏳ Processando...';
    spinner.style.display = 'block';
    progressInfo.textContent = 'Enviando arquivo e processando usuários...';
    resultDiv.innerHTML = '';
    
    // Send AJAX request
    jQuery.ajax({
        url: '<?php echo esc_url(get_template_directory_uri() . "/sql/sql.php"); ?>',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        timeout: 300000, // 5 minutes timeout
        success: function(response) {
            spinner.style.display = 'none';
            button.disabled = false;
            button.textContent = '📤 Enviar e Processar';
            progressInfo.textContent = '';
            
            if (typeof response === 'string') {
                // Old format (HTML response)
                resultDiv.innerHTML = response;
                showMessage('Processamento concluído!', 'success');
            } else if (response.success) {
                // New format (JSON response)
                resultDiv.innerHTML = response.data.html;
                var summary = 'Processamento concluído! ' +
                    'Criados: ' + response.data.criados + ', ' +
                    'Atualizados: ' + response.data.atualizados + ', ' +
                    'Erros: ' + response.data.erros;
                showMessage(summary, 'success');
            } else {
                showMessage('Erro: ' + (response.message || 'Erro desconhecido'), 'error');
            }
            
            // Reset file input
            fileInput.value = '';
        },
        error: function(xhr, status, error) {
            spinner.style.display = 'none';
            button.disabled = false;
            button.textContent = '📤 Enviar e Processar';
            progressInfo.textContent = '';
            
            var errorMessage = 'Erro ao processar o arquivo. ';
            
            if (status === 'timeout') {
                errorMessage += 'O processamento demorou muito tempo. Tente com um arquivo menor.';
            } else if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMessage += xhr.responseJSON.message;
            } else if (xhr.responseText) {
                // Try to extract error message from HTML response
                var tempDiv = document.createElement('div');
                tempDiv.innerHTML = xhr.responseText;
                var errorText = tempDiv.textContent || tempDiv.innerText || '';
                errorMessage += errorText.substring(0, 200);
            } else {
                errorMessage += 'Status: ' + status + ', Erro: ' + error;
            }
            
            showMessage(errorMessage, 'error');
            
            // Log full error to console for debugging
            console.error('Upload error:', {
                status: status,
                error: error,
                responseText: xhr.responseText,
                statusCode: xhr.status
            });
        }
    });
}

function showMessage(message, type) {
    var resultDiv = document.getElementById('result');
    var alertClass = 'alert-' + type;
    var icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
    
    var alertDiv = '<div class="alert ' + alertClass + '" style="margin-bottom: 20px;">' +
        '<strong>' + icon + '</strong> ' + message +
        '</div>';
    
    resultDiv.innerHTML = alertDiv + resultDiv.innerHTML;
}

// Prevent accidental page close during upload
var isUploading = false;
jQuery('#uploadButton').on('click', function() {
    isUploading = true;
});

window.addEventListener('beforeunload', function(e) {
    if (isUploading) {
        e.preventDefault();
        e.returnValue = '';
        return '';
    }
});

jQuery(document).ajaxComplete(function() {
    isUploading = false;
});
</script>