<?php

/* Template Name: Inscrições */

// COMISSAO
if(current_user_can('comissao') || current_user_can('administrator')) {

get_header(); ?>

      <?php if(

        // Condições para exibição de conteúdo
        // Exibe conteúdo apenas se o status for diferente de bloqueado
        $status != 'Bloqueado'
        || // ou - Exibe se estiver bloqueado mas é 'administrator'
        $status == 'Bloqueado' && current_user_can('administrator')
        || // ou - Exibe se estiver bloqueado mas é 'comissao'
        $status == 'Bloqueado' && current_user_can('comissao')

      ) { 

      // Exibe a tabela de grupos da página do orientador
      get_template_part('comissao/content','tabela');

      } else { get_template_part('bloqueado'); } ?>

<?php get_footer(); } else { wp_redirect(home_url()); } ?>