<?php

$current_user_id = get_current_user_id();
$user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

$opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
$ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
$status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];

?>

<?php if($_GET && $_GET['confirm'] == 'true') { ?>
<p id="sucesso-block">
<?php echo apply_filters('str_from_lang','Confirmação de participação realizada com sucesso!','Confirmación de participación realizada con éxito! '); ?>
</p>
<?php } ?>

<div class="grupos-list invite space-top" id="grupospendentes">
  <div class="container">
  <h2>
    <?php echo apply_filters('str_from_lang','Grupos aguardando confirmação: <span>Ano vigente ('.$ano.')</span>','Grupos en espera de confirmación: <span>Año actual ('.$ano.')</span>'); ?></h2>

  <div class="body">
      <?php

        $args = array(
            'post_type' => 'grupos_' . $ano . '_' . $user_empresa,
            'post_status' => array('publish'),
            'posts_per_page' => -1
          );

        $loop = new WP_Query( $args );

        if ( $loop->have_posts() ) { ?>

        <div class="flow-root head">
          <div class="single">
            <p><?php echo apply_filters('str_from_lang','Nome do grupo','Nombre del grupo'); ?></p>
          </div>
          <div class="single" id="middle">
            <p><?php echo apply_filters('str_from_lang','Coordenador, orientador e Integrantes','Coordinador, tutor y miembros '); ?></p>
          </div>
          <div class="single">
            <p><?php echo apply_filters('str_from_lang','Ações','Acciones'); ?></p>
          </div>
        </div>

        <?php

        if ($loop->have_posts())
        
        while ( $loop->have_posts() ) : $loop->the_post();

          /*
          $meta1 = get_post_meta( get_the_ID(), 'grupos_integrantes', true );
          $meta2 = $meta1[2];
          $meta3 = $meta2['grupos_integrantes_camiseta'];
          echo $meta3;*/

          $ids_integrantes = array();
          $orientador = get_post_meta( get_the_ID(), 'grupos_infos_orientador_' . $ano . '_' . $user_empresa, true );
          $integrantes = get_post_meta( get_the_ID(), 'grupos_integrantes_' . $ano . '_' . $user_empresa, true );
          $confirmados = get_post_meta( get_the_ID(), 'integrantes_confirmados_' . $ano . '_' . $user_empresa, true );

          $coordenador = get_post_field( 'post_author', get_the_ID() );

            foreach((array) $integrantes as $key => $entry ){
              $ids_integrantes[] = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
            }                            

            $count = $count + 1;

            // Se usuário está, exibe confirmação
            if (in_array($current_user_id,$ids_integrantes)) { ?>

            <div class="flow-root corpo">
              <div class="single">
                <p id="title-name">
                  <?php the_title(); ?>
                </p>
              </div>
              <div class="single" id="integrantes">
                <?php
                if(!empty($coordenador)) { ?>
                <b id="ori"><?php echo apply_filters('str_from_lang','Coordenador','Coordinador'); ?>: </b><p><?php echo get_user_meta($coordenador, 'first_name', true); ?></p>
                <?php }

                if(!empty($orientador)) { ?>
                <b id="ori"><?php echo apply_filters('str_from_lang','Orientador','Tutor'); ?>: </b><p><?php echo get_user_meta($orientador, 'first_name', true); ?></p>
                <?php } 

                if($integrantes) {
                echo '<b id="int">'.apply_filters('str_from_lang','Integrantes','Miembros').': </b>';
                foreach((array) $integrantes as $key => $entry ){ ?>
                 <p <?php if($entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa] == $current_user_id) { echo ' class="me"'; } ?>>
                    <?php
                    $id = $entry['grupos_integrantes_nome_' . $ano . '_' . $user_empresa];
                      $integrante_nome = get_user_meta($id, 'first_name', true);
                      echo mb_strimwidth($integrante_nome, 0, 30, "...");
                    ?>
                   </p>
                <?php
                  } }
                ?>
              </div>
              <div class="single">
                <?php
                $confirmados_array = explode(" ", $confirmados);
                $matricula_membro_current = wp_get_current_user()->user_login;
                if (!in_array($matricula_membro_current,$confirmados_array)) {
                ?>
                <a id="edit" class="notscrollable" data-toggle="modal" data-target="#ModalConfirmacao<?php echo $count; ?>" data-confirm="<?php echo get_the_ID(); ?>" id-to-add="<?php echo $current_user_id; ?>" href="#"><?php echo apply_filters('str_from_lang','Confirmar','Confirmar'); ?></a>
                <?php } else { ?>
                <span id="confirmado"><?php echo apply_filters('str_from_lang','Confirmado','Confirmado'); ?></span>
                <?php } ?>
              </div>
            </div>

            <div id="ModalConfirmacao<?php echo $count; ?>" class="modal-center modal fade covid" role="dialog">
              <div class="full">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <button type="button" class="close" data-dismiss="modal">X</button>
                    <div class="modal-body">
                      <h1 id="main"><?php echo apply_filters('str_from_lang','Confirmação da inscrição','Confirmación de la inscripción'); ?></h1>                            
                      <br>
                      <p><?php echo apply_filters('str_from_lang','Olá, seja bem-vindo ao NHC '.date('Y').'! Agradecemos pelo seu interesse em participar. Lembrando que sua participação é voluntária e não obrigatória. Estando de acordo, assinale os campos abaixo.','¡Hola, bienvenido al NHC '.date('Y').'! Gracias por su interés en participar. Recordando que su participación es voluntaria y no obligatoria. Si estás de acuerdo, marque los campos de abajo.'); ?></p>
                        <div class="form-check" style="text-align: center;margin: 6px 0px 9px 0px;">   
                          <label><input type="checkbox" class="check-confirm" value="confirmar">
                            <?php echo apply_filters('str_from_lang','<b>Sim</b>, estou ciente.','<b>Sí</b>, estoy consciente.'); ?>
                          </label>
                        </div>
                        <br>
                     <!--  <h1><?php echo apply_filters('str_from_lang','Regulamento interno e guia prático <span>de prevenção à Covid-19</span>','Normativa interna y guía práctica <span>de prevención de Covid-19</span>'); ?></h1> -->
                      <br>
                        <p><?php echo apply_filters('str_from_lang','Para confirmar a sua participação é necessário <b>ler e marcar</b> todos os tópicos de confirmação para prosseguir.','Para confirmar su participación, debes <b>leer y marcar</b> todos los temas de confirmación para continuar.'); ?></p>
                      <br>
                      <div class="form-check">                             
  <!--                       <label><input type="checkbox" class="check-confirm" value="areas_adm">
                          <?php echo apply_filters('str_from_lang','<b>Mantenha a distância</b> de 1 metro para conversar.','<b>Mantenga una distancia</b> de 1 metro para hablar.'); ?>                          
                        </label> -->
 <!--                        <label>
                          <input type="checkbox" class="check-confirm" value="reunioes">
                          <?php echo apply_filters('str_from_lang','<b>Respeite as demarcações</b> de mesas e cadeiras.','<b>Respete las demarcaciones</b> de mesas y sillas.'); ?>
                        </label> -->
   <!--                      <label>
                          <input type="checkbox" class="check-confirm" value="mascara">
                          <?php echo apply_filters('str_from_lang','A máscara deve ser <b>utilizada a todo momento</b>.','La máscara debe <b>usarse en todo momento</b>.'); ?>
                        </label> -->
<!--                         <label>
                          <input type="checkbox" class="check-confirm" value="reunioes">
                          <?php echo apply_filters('str_from_lang','Caso seja preciso a realização de reuniões presenciais, <b>respeite a capacidade máxima das salas</b>, que foi reduzida.','Si se requieren reuniones presenciales, <b>respetar la capacidad máxima de las salas</b>, que se ha reducido.'); ?>
                        </label> -->
                        <label>
                          <input type="checkbox" class="check-confirm" value="equipamentos">
                          <?php echo apply_filters('str_from_lang','Equipamentos de uso comum das salas, como controles, botões, mesa e braços das cadeiras, deverão ser <b>higienizados pelo usuário antes e após a reunião</b> - com kit fornecido pela empresa.','Los equipos de uso común en las salas, como controles, botones, mesa y apoyabrazos, deben ser <b>higienizados por el usuario antes y después de la reunión</b>, con un kit proporcionado por la empresa.'); ?>
                        </label>
<!--                         <label>
                          <input type="checkbox" class="check-confirm" value="ambinete">
                          <?php echo apply_filters('str_from_lang','<b>Mantenha os ambientes arejados</b>, sempre que possível, dando preferência para a ventilação natural.','<b>Mantener las habitaciones ventiladas</b>, siempre que sea posible, dando preferencia a la ventilación natural.'); ?>                          
                        </label> -->
 <!--                        <label>
                          <input type="checkbox" class="check-confirm" value="compartilhamento">
                          <?php echo apply_filters('str_from_lang','Não compartilhe computadores, canetas, blocos de notas, laser pointers, mouses ou celulares. Sempre que possível, apenas um participante deve higienizar e manusear itens de uso comum da sala como controles, botões de equipamentos, conexões, HDMI, etc.','No comparta computadoras, bolígrafos, cuadernos de notas, laser pointers, ratones o teléfonos celulares. Siempre que sea posible, solo un participante debe limpiar y manipular elementos de uso común en la sala como controles, botones de equipo, conexiones, HDMI, etc. '); ?>                          
                        </label> -->
                        <!--<label><input type="checkbox" class="check-confirm" value="reunioes">
                          <?php echo apply_filters('str_from_lang','<b>Reuniões de início de expediente</b> devem ser breves e realizadas em locais amplos e arejados, respeitando o distanciamento mínimo entre pessoas.','<b>Reuniones de
                            inicio de la jornada laboral</b> deben ser breves y realizarse en lugares amplios y ventilados, respetando la distancia mínima entre personas.'); ?>
                        </label>-->
                      </div>
                      <a id="edit" class="confirm notscrollable off" data-confirm="<?php echo get_the_ID(); ?>" id-to-add="<?php echo $current_user_id; ?>" href="#"><?php echo apply_filters('str_from_lang','Confirmar','Confirmar'); ?></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <?php

            } // Verifica se existe no array de matriculas confirmadas

          // }

        ?>                  

        <?php endwhile;

            } else {
                echo '<div id="text"><p>'.apply_filters('str_from_lang','Você não possui confirmações pendentes.','No tienes confirmaciones pendientes.').'</div>';
            }

        wp_reset_postdata();

      ?>
    </div>
  </div>
</div>