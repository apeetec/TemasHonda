<?php

/* Plugin Name: Increase Upload Limit */
/*add_filter( 'upload_size_limit', 'custom_upload_size' );
//https://stackoverflow.com/questions/17751779/increase-max-upload-limit-in-wordpress
function custom_upload_size( $bytes )
{
    return 125829120; // 32 megabytes
}*/

############### ADMIN BODY CLASS
add_filter( 'admin_body_class', 'my_admin_body_class' );

/**
 * Adds one or more classes to the body tag in the dashboard.
 *
 * @link https://wordpress.stackexchange.com/a/154951/17187
 * @param  String $classes Current body classes.
 * @return String          Altered body classes.
 */
function my_admin_body_class( $classes ) {
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $ano_selecao = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $user_empresa];

    return "$classes user-empresa-$user_empresa ano-$ano";
    // Or: return "$classes my_class_1 my_class_2 my_class_3";
}
############### FIM ADMIN BODY CLASS

add_action('init','custom_login');

function criar_role_personalizada() {
    add_role(
        'Integrante', // Slug da role (identificador único)
        'Integrante', // Nome exibido no painel
        array(
            'read' => true,  // Pode ler posts e páginas
            'edit_posts' => true, // Pode editar seus próprios posts
            'delete_posts' => false, // Não pode excluir posts
            'publish_posts' => false, // Não pode publicar posts
            'upload_files' => true, // Pode enviar arquivos (imagens, PDFs, etc.)
        )
    );
}
add_action('init', 'criar_role_personalizada');


function custom_login(){
 global $pagenow;
 if( 'wp-login.php' == $pagenow && !is_user_logged_in()) {
  wp_redirect(home_url());
  exit();
 }
}

// Custom size - galeria
add_image_size( 'galeria_thumb', 188, 200, true );

/// CMB2
if ( file_exists( dirname( __FILE__ ) . '/cmb2/init.php' ) ) {
  require_once dirname( __FILE__ ) . '/cmb2/init.php';
} elseif ( file_exists( dirname( __FILE__ ) . '/CMB2/init.php' ) ) {
  require_once dirname( __FILE__ ) . '/CMB2/init.php';
}

$dirbase = get_template_directory();
require_once $dirbase . '/inc/functions-post-type-galerias.php';
require_once $dirbase . '/inc/functions-post-type-grupos.php';
require_once $dirbase . '/inc/functions-post-type-anos.php';
require_once $dirbase . '/inc/functions-css-todos.php';
require_once $dirbase . '/inc/functions-css-orientador.php';
require_once $dirbase . '/inc/functions-css-nao-administradores.php';
require_once $dirbase . '/inc/functions-css-comissao.php';
require_once $dirbase . '/inc/functions-nao-administradores.php';
require_once $dirbase . '/inc/functions-cmb2-users.php';
require_once $dirbase . '/inc/functions-evitar-grupos-duplicados.php';
require_once $dirbase . '/inc/functions-max-5-integrantes.php';
require_once $dirbase . '/inc/functions-setor-automatico.php';
require_once $dirbase . '/inc/functions-ajax-categoria-grupo.php';
// VALIDACAO: Pede validações de campos apenas se o usuário for DIFERENTE de:
if(!current_user_can('comissao') && !current_user_can('administrator'))  {
require_once $dirbase . '/inc/functions-validacoes-grupos.php';
}

require_once $dirbase . '/inc/functions-opcoes-gerais.php';
require_once $dirbase . '/inc/functions-funcoes-nao-admins.php';
require_once $dirbase . '/inc/functions-funcoes-comissao.php';
require_once $dirbase . '/inc/functions-funcoes-orientador.php';
// require_once $dirbase . '/inc/functions-funcoes-membro-orientador.php';
require_once $dirbase . '/inc/functions-confirma-grupo.php';
require_once $dirbase . '/inc/functions-institucional-slides.php';
require_once $dirbase . '/inc/functions-institucional-cronogramas.php';
require_once $dirbase . '/inc/functions-institucional-midias.php';
require_once $dirbase . '/inc/functions-institucional-arquivos.php';
require_once $dirbase . '/inc/functions-institucional-galerias.php';
require_once $dirbase . '/inc/functions-cmb2-grupos-1-orientativa.php';
require_once $dirbase . '/inc/functions-cmb2-grupos.php';
// require_once $dirbase . '/inc/functions-login-labels.php';
require_once $dirbase . '/inc/functions-resetar-senha.php';
require_once $dirbase . '/inc/functions-css-login.php';
require_once $dirbase . '/inc/functions-author-only-posts.php';
require_once $dirbase . '/inc/functions-esconder-user-fields.php';
// require_once $dirbase . '/inc/functions-users-sem-email.php';
require_once $dirbase . '/inc/functions-listagem-usuarios.php';
require_once $dirbase . '/inc/functions-seguranca.php';
require_once $dirbase . '/inc/functions-log-geral.php';
// require_once $dirbase . '/inc/functions-log-acao.php';
require_once $dirbase . '/inc/functions-user-empresa.php';
require_once $dirbase . '/inc/functions-user-unidade.php';
require_once $dirbase . '/inc/functions-user-setor.php';
require_once $dirbase . '/inc/functions-role-name-traducao.php';
require_once $dirbase . '/inc/functions-traducao.php';
// require_once $dirbase . '/inc/functions-disable-dragging.php';
// require_once $dirbase . '/inc/functions-evita-repeticao-de-membros.php';

/// Redireciona 404 para a Home
if( !function_exists('redirect_404_to_homepage') ){

    add_action( 'template_redirect', 'redirect_404_to_homepage' );

    function redirect_404_to_homepage(){
       if(is_404()):
            wp_safe_redirect( home_url('/') );
            exit;
        endif;
    }
}

// Add menu item for home
function add_menu_item_home() {
  // $page_title, $menu_title, $capability, $menu_slug, $callback_function
  // add_posts_page(__('Drafts'), __('Drafts'), 'read', 'edit.php?post_status=draft&post_type=post');
  add_menu_page( apply_filters('str_from_lang','Voltar para o site','Volver al sitio'), apply_filters('str_from_lang','Voltar para o site','Volver al sitio'), 'read', home_url() );
}
add_action('admin_menu', 'add_menu_item_home');

// Opções de layout mais clean do WordPress
function remove_admin_login_header() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}

add_action('get_header', 'remove_admin_login_header');
add_theme_support( 'post-thumbnails' );
show_admin_bar(false);

add_action( 'cmb2_render_post_search_text', function( $field ) {
  $args = [
    'post_type' => $field->args['post_type'],
    'post_count' => -1,
    'orderby' => 'post__in',
    'post__in' => explode( ',', $field->escaped_value ),
  ];
  $posts = get_posts( $args );
  foreach ( $posts as $post ) {
    printf( '%d: <a href="%s">%s</a><br>', $post->ID, get_edit_post_link( $post->ID ), $post->post_title );
  }
}, 20 );

// Change Url
add_filter( 'login_headerurl', 'custom_loginlogo_url' );
function custom_loginlogo_url($url) {
  return home_url();
}

// Redirect after login
// function login_redirect( $redirect_to, $request, $user ){
//     return home_url();
// }
// add_filter( 'login_redirect', 'login_redirect', 10, 3 );

// Redirect Home para ano vigente do usuário
function redirect_to_year() {

  $current_user_id = get_current_user_id();
  $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

  $ano_home_opcoes = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
  $ano_home = $ano_home_opcoes['opcoes_gerais_ano_usuarios_' . $user_empresa];

  $id_from_slug = get_page_by_path( $ano_home, OBJECT, 'anos' );

  if(!is_admin() && is_home() && is_user_logged_in()) {
    wp_redirect(get_permalink( $id_from_slug ));
    exit();
  }
}
add_action('template_redirect', 'redirect_to_year');

// Custom post count
add_action( 'admin_init', 'grupos_post_count' );
  function grupos_post_count() {
    $author_id = get_the_author_meta( 'ID' ); 
    $current_user_id = get_current_user_id();

  $count = count_user_posts( $current_user_id , 'grupos'  );

  if($count >= 1) {
    // echo '<style>.page-title-action {display: none !important}</style>';
  }
}

////////////////////////////////////////////////////
// Extend Search
// Fim Extend Search
///////////////////////////////////////////////////

///////////////////////////////////////////////////
// https://rudrastyh.com/wordpress/pre_user_query.html
// Hide users
function modify_user_list($query){
  if(!current_user_can('administrator')) {
    $user = wp_get_current_user();

    $user_id = $user->ID; 
    $user_infos_empresas = get_user_meta($user_id, 'user_infos_empresas', true);

    $query->query_vars['meta_key'] = 'user_infos_empresas';
    $query->query_vars['meta_value'] = $user_infos_empresas; 
    $query->query_vars['meta_compare'] = '=';

    return $query;
  }
}
add_action('pre_get_users', 'modify_user_list');
///////////////////////////////////////////////////

//////////////////// Exibe author/criador/cordenador do grupo
function add_author_support_to_posts() {
  if(current_user_can('administrator')) {

    /////////////////////////////////////////////////////////////////////
    $current_user_id = get_current_user_id();
    $user_empresa = get_user_meta($current_user_id, 'user_infos_empresas', true);

    $opcoes_gerais = get_option( 'opcoes_gerais_' . $user_empresa, 1 );
    $ano = $opcoes_gerais['opcoes_gerais_ano_vigente_' . $user_empresa];
    $status = $opcoes_gerais['opcoes_gerais_status_' . $user_empresa];
    /////////////////////////////////////////////////////////////////////

    $terms = get_terms( 'user_empresa', array('hide_empty' => false) );

      foreach($terms as $term) {

        add_post_type_support( 'grupos_' . $ano . '_' . $term->slug, 'author' );

      }
  
  }
}
add_action( 'init', 'add_author_support_to_posts' );

//////////////////////////// Restrição post editado
// Retorna membro para listagem de posts evitando que prossiga tomando controle
add_action( 'load-post.php', 'redirect_locked_post_wpse_95718' );

function redirect_locked_post_wpse_95718()
{
    if( isset($_GET['post'] ) && wp_check_post_lock( $_GET['post'] ) )
    {
        global $typenow;
        $goto = ( 'post' == $typenow ) ? '' : "?post_type=$typenow";
        wp_redirect( admin_url( "edit.php$goto" ) );
        exit();
    }
}
// Fim redirecionamento
// Exibe mensagem
foreach( array( 'post', 'page' ) as $hook )
    add_filter( "{$hook}_row_actions", 'locked_post_notice_wpse_95718', 10, 2 );

function locked_post_notice_wpse_95718( $actions, $post ) 
{
    if( wp_check_post_lock( $post->ID ) )
    {
        $actions['locked'] = sprintf(
            '<span style="color: #c23b3b;display: block;margin-top: 10px;margin-bottom: 10px;">'.apply_filters('str_from_lang','Esta página está sendo editada no momento. Este bloqueio ocorre para que nenhuma informação seja perdida. <br>Essa mesma mensagem aparecerá para outros membros quando você estiver realizando suas alterações. Tente novamente mais tarde.','Esta página está siendo editada en el momento. Este bloqueo se produce para que no se pierda información. <br>Este mismo mensaje aparecerá para otros miembros cuando realice sus cambios. Vuelve a intentarlo más tarde.').'</span>',
            strtoupper( $post->post_type )
        );
    }
    return $actions; 
}
// Fim mensagem
//////////////////////////// Fim restrição

//////////////////////////// Remove coluna de author admin
function manage_colum_grupos( $columns ) {
  unset($columns['author']);
  return $columns;
}

function my_columns_grpuos() {
  add_filter( 'manage_posts_columns' , 'manage_colum_grupos' );
}
add_action( 'admin_init' , 'my_columns_grpuos' );
//////////////////////////// Fim remove coluna

########### USER BY NAME ###########
/*
add_action( 'pre_get_users', 'user_by_name' );  
function user_by_name( $query ) {  
  if( ! is_admin() )  
      return;  

  $orderby = $query->get( 'orderby');  

  if( 'user_field_confirmado' == $orderby ) {  
      $query->set('meta_key','user_field_confirmado');
      $query->set('meta_type','text');
      $query->set('orderby','meta_value');  
  } 
  
  ########### CUSTOM META_QUERY ###########
  // META QUERY - RELAÇÃO
  $meta_query = array(
    'relation' => 'AND'
  );

  // Aprovação de selife
  if(!empty($_GET['user_field_selfie_aprov'])) {
    $meta_query[] = array(
    'key'       => 'user_field_selfie_aprov',
      'value'     => $_GET['user_field_selfie_aprov'],
      'compare'   => '==',
    );
  }
	$query->set( 'meta_query', $meta_query );
########### FIM USER BY NAME ###########
} */

function search_by_users_query($query)
{
    global $pagenow;

    if (is_admin() && 'users.php' == $pagenow && $_GET['s']) {

        //Remove trailing and starting empty spaces
        $the_search = trim($query->query_vars['search']);
        $the_search = trim($query->query_vars['search'], '*');

        $query->set('meta_key', array('first_name','user_infos_empresas','user_infos_unidades','login'));
        $query->set('meta_value', $_GET['s']);
        $query->set('meta_compare', 'LIKE');

        $query->set('search', '');
    }
}
add_action('pre_get_users', 'search_by_users_query', 20);

############################ AUTHOR/COORDINADOR NAME IN ALL POST TYPES
add_action('admin_init', 'custom_column_coordenador');
function custom_author_column($columns) {

  $date = $columns['date'];
  unset($columns['date']);

  $columns['custom_author'] = 'Coordenador';
  $columns['date'] = $date;

  return $columns;
}
function custom_author_column_content($column_name, $post_id) {
  if ($column_name === 'custom_author') {
      $author_id = get_post_field('post_author', $post_id);
      $author_meta = get_userdata($author_id);
      echo get_user_meta($author_id, 'first_name', $author_id);
  }
}
function add_custom_author_column_to_all_post_types($post_types) {
  foreach ($post_types as $post_type) {
      add_filter("manage_{$post_type}_posts_columns", 'custom_author_column');
      add_action("manage_{$post_type}_posts_custom_column", 'custom_author_column_content', 10, 2);
  }
}
add_action('admin_init', function() {
  $post_types = array();
  $terms = get_terms( 'user_empresa', array('hide_empty' => false) );
  foreach($terms as $term) {
    $ano_selecao = get_option( 'opcoes_gerais_' . $term->slug, 1 );
    $ano = $ano_selecao['opcoes_gerais_ano_vigente_' . $term->slug];
    $post_types[] = 'grupos_' . $ano . '_' . $term->slug;
  }
  add_custom_author_column_to_all_post_types($post_types);  
});
// End

/******************************************************************************
 * INÍCIO: GERENCIAMENTO DE ROLES EM LOTE
 * 
 * Descrição: Esta seção adiciona uma página administrativa que permite
 *            mudança em lote das funções (roles) dos usuários.
 * 
 * Funcionalidades:
 * - Lista todos os usuários com paginação (20 por página)
 * - Filtro por role atual
 * - Filtro por busca (nome/email)
 * - Seleção múltipla de usuários via checkbox
 * - Seleção automática de TODOS os usuários de uma função específica
 * - Contador de usuários selecionados em tempo real
 * - Alteração em lote da role dos usuários selecionados
 * - Mensagens de sucesso/erro
 * - Confirmação antes de aplicar mudanças
 * 
 * Roles disponíveis: membro, orientador, coordenador, comissao, 
 *                    membro-coordenador, integrante
 * 
 * Como usar:
 * 1. Acesse: Usuários → Funções em Lote
 * 2. Para trocar função de usuários específicos: marque os checkboxes
 * 3. Para trocar TODOS de uma função: filtre a função e clique no botão azul
 * 4. Selecione a nova função e clique em "Aplicar Alteração"
 ******************************************************************************/

// Adiciona o menu no painel administrativo
add_action('admin_menu', 'bulk_role_manager_menu');

function bulk_role_manager_menu() {
    add_users_page(
        'Gerenciar Funções em Lote',           // Título da página
        'Funções em Lote',                      // Título do menu
        'edit_users',                           // Capacidade necessária
        'bulk-role-manager',                    // Slug do menu
        'bulk_role_manager_page'                // Função callback
    );
}

// Renderiza a página de gerenciamento
function bulk_role_manager_page() {
    // Verifica permissões
    if (!current_user_can('edit_users')) {
        wp_die(__('Você não tem permissão para acessar esta página.'));
    }

    // Processa o formulário de mudança em lote
    if (isset($_POST['bulk_change_role']) && check_admin_referer('bulk_role_change', 'bulk_role_nonce')) {
        bulk_process_role_change();
    }

    // Parâmetros de filtro e paginação
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;
    $role_filter = isset($_GET['role_filter']) ? sanitize_text_field($_GET['role_filter']) : '';
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    // Argumentos para buscar usuários
    $args = array(
        'number' => $per_page,
        'paged' => $current_page,
        'orderby' => 'display_name',
        'order' => 'ASC'
    );

    // Adiciona filtro por role
    if (!empty($role_filter)) {
        $args['role'] = $role_filter;
    }

    // Adiciona filtro de busca
    if (!empty($search)) {
        $args['search'] = '*' . $search . '*';
        $args['search_columns'] = array('user_login', 'user_email', 'display_name');
    }

    // Busca os usuários
    $user_query = new WP_User_Query($args);
    $users = $user_query->get_results();
    $total_users = $user_query->get_total();
    $total_pages = ceil($total_users / $per_page);

    // Roles disponíveis
    $available_roles = array(
        'membro' => 'Membro',
        'orientador' => 'Orientador',
        'coordenador' => 'Coordenador',
        'comissao' => 'Comissão',
        'membro-coordenador' => 'Membro Coordenador',
        'integrante' => 'Integrante'
    );

    ?>
    <div class="wrap">
        <h1>Gerenciar Funções de Usuários em Lote</h1>
        
        <!-- Caixa de instruções -->
        <div class="bulk-help-box">
            <h3>💡 Como trocar funções em lote:</h3>
            <ol>
                <li><strong>Para trocar usuários específicos:</strong> Marque os checkboxes dos usuários desejados</li>
                <li><strong>Para trocar TODOS de uma função:</strong> Use o filtro de função, depois clique no botão azul "Selecionar todos os [função]"</li>
                <li>Selecione a nova função no dropdown "Alterar função selecionados para"</li>
                <li>Clique em "Aplicar Alteração" e confirme</li>
            </ol>
        </div>
        
        <?php
        // Exibe mensagens de sucesso/erro
        if (isset($_GET['updated'])) {
            $count = intval($_GET['updated']);
            echo '<div class="notice notice-success is-dismissible"><p>';
            echo sprintf(_n('%s usuário atualizado com sucesso.', '%s usuários atualizados com sucesso.', $count), $count);
            echo '</p></div>';
        }
        if (isset($_GET['error'])) {
            echo '<div class="notice notice-error is-dismissible"><p>Erro ao atualizar usuários.</p></div>';
        }
        ?>

        <!-- Formulário de filtros -->
        <form method="get" action="">
            <input type="hidden" name="page" value="bulk-role-manager" />
            <p class="search-box">
                <label class="screen-reader-text" for="user-search-input">Buscar usuários:</label>
                <input type="search" id="user-search-input" name="s" value="<?php echo esc_attr($search); ?>" placeholder="Buscar por nome ou email" />
                
                <label for="role-filter">Filtrar por função:</label>
                <select name="role_filter" id="role-filter">
                    <option value="">Todas as funções</option>
                    <?php foreach ($available_roles as $role_slug => $role_name): ?>
                        <option value="<?php echo esc_attr($role_slug); ?>" <?php selected($role_filter, $role_slug); ?>>
                            <?php echo esc_html($role_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <input type="submit" class="button" value="Filtrar" />
            </p>
        </form>

        <!-- Formulário principal de mudança em lote -->
        <form method="post" action="">
            <?php wp_nonce_field('bulk_role_change', 'bulk_role_nonce'); ?>
            
            <div class="tablenav top">
                <div class="alignleft actions">
                    <?php if (!empty($role_filter)): ?>
                        <div style="margin-bottom: 10px; padding: 10px; background: #e7f3ff; border-left: 4px solid #2271b1;">
                            <strong>Filtro ativo:</strong> <?php echo esc_html($available_roles[$role_filter]); ?>
                            <button type="button" id="select-all-filtered" class="button" style="margin-left: 10px;">
                                ✓ Selecionar todos os <?php echo esc_html($available_roles[$role_filter]); ?> (<?php echo $total_users; ?>)
                            </button>
                        </div>
                    <?php endif; ?>
                    
                    <label for="new-role-select">Alterar função selecionados para:</label>
                    <select name="new_role" id="new-role-select" required>
                        <option value="">Selecione uma função</option>
                        <?php foreach ($available_roles as $role_slug => $role_name): ?>
                            <option value="<?php echo esc_attr($role_slug); ?>">
                                <?php echo esc_html($role_name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="submit" name="bulk_change_role" class="button action" value="Aplicar Alteração" 
                           onclick="return confirmBulkChange();" />
                    <span id="selected-count" style="margin-left: 10px; font-weight: bold;"></span>
                </div>
                
                <!-- Paginação superior -->
                <?php if ($total_pages > 1): ?>
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo $total_users; ?> itens</span>
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $current_page,
                        'add_args' => array(
                            'role_filter' => $role_filter,
                            's' => $search
                        )
                    ));
                    ?>
                </div>
                <?php endif; ?>
            </div>

            <table class="wp-list-table widefat fixed striped users">
                <thead>
                    <tr>
                        <td class="manage-column column-cb check-column">
                            <input type="checkbox" id="select-all-users" />
                        </td>
                        <th scope="col" class="manage-column column-username">Nome de Usuário</th>
                        <th scope="col" class="manage-column column-name">Nome</th>
                        <th scope="col" class="manage-column column-email">Email</th>
                        <th scope="col" class="manage-column column-role">Função Atual</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($users)): ?>
                        <?php foreach ($users as $user): ?>
                            <?php 
                            $user_roles = $user->roles;
                            $user_role = !empty($user_roles) ? $user_roles[0] : 'Nenhuma';
                            $user_role_name = isset($available_roles[$user_role]) ? $available_roles[$user_role] : ucfirst($user_role);
                            ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="users[]" value="<?php echo esc_attr($user->ID); ?>" class="user-checkbox" />
                                </th>
                                <td class="username column-username">
                                    <strong><?php echo esc_html($user->user_login); ?></strong>
                                </td>
                                <td class="name column-name">
                                    <?php echo esc_html($user->display_name); ?>
                                </td>
                                <td class="email column-email">
                                    <a href="mailto:<?php echo esc_attr($user->user_email); ?>">
                                        <?php echo esc_html($user->user_email); ?>
                                    </a>
                                </td>
                                <td class="role column-role">
                                    <span class="role-badge"><?php echo esc_html($user_role_name); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">Nenhum usuário encontrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Paginação inferior -->
            <?php if ($total_pages > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <span class="displaying-num"><?php echo $total_users; ?> itens</span>
                    <?php
                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%'),
                        'format' => '',
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;',
                        'total' => $total_pages,
                        'current' => $current_page,
                        'add_args' => array(
                            'role_filter' => $role_filter,
                            's' => $search
                        )
                    ));
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </form>

        <!-- JavaScript para selecionar todos -->
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Função para atualizar contador de selecionados
            function updateSelectedCount() {
                var count = $('.user-checkbox:checked').length;
                if (count > 0) {
                    $('#selected-count').text(count + ' usuário(s) selecionado(s)').css('color', '#2271b1');
                } else {
                    $('#selected-count').text('');
                }
            }
            
            // Selecionar/desselecionar todos
            $('#select-all-users').on('click', function() {
                $('.user-checkbox').prop('checked', this.checked);
                updateSelectedCount();
            });
            
            // Atualizar estado do checkbox "selecionar todos"
            $('.user-checkbox').on('click', function() {
                if ($('.user-checkbox:checked').length == $('.user-checkbox').length) {
                    $('#select-all-users').prop('checked', true);
                } else {
                    $('#select-all-users').prop('checked', false);
                }
                updateSelectedCount();
            });
            
            // Selecionar todos da função filtrada (todas as páginas)
            $('#select-all-filtered').on('click', function(e) {
                e.preventDefault();
                
                var roleCount = <?php echo $total_users; ?>;
                var roleName = '<?php echo esc_js($available_roles[$role_filter] ?? ''); ?>';
                
                var message = 'Isso vai selecionar TODOS os ' + roleCount + ' usuários com a função "' + roleName + '" (incluindo usuários em outras páginas).\n\nDeseja continuar?';
                
                var confirmed = confirm(message);
                if (confirmed) {
                    // Marca todos os checkboxes visíveis
                    $('.user-checkbox').prop('checked', true);
                    $('#select-all-users').prop('checked', true);
                    
                    // Adiciona campo hidden para indicar seleção total
                    if ($('#select-all-role-users').length === 0) {
                        $('<input>').attr({
                            type: 'hidden',
                            id: 'select-all-role-users',
                            name: 'select_all_role',
                            value: '<?php echo esc_js($role_filter); ?>'
                        }).appendTo('form[method="post"]');
                    }
                    
                    updateSelectedCount();
                    alert('✓ ' + roleCount + ' usuários com a função "' + roleName + '" foram selecionados!\n\nAgora escolha a nova função e clique em "Aplicar Alteração".');
                }
            });
            
            // Inicializa o contador
            updateSelectedCount();
            
            // Função global para confirmação de mudança
            window.confirmBulkChange = function() {
                var newRole = $('#new-role-select option:selected').text();
                var isSelectAllRole = $('#select-all-role-users').length > 0;
                
                if (!newRole || newRole === 'Selecione uma função') {
                    alert('Por favor, selecione uma função de destino.');
                    return false;
                }
                
                if (isSelectAllRole) {
                    var oldRoleName = '<?php echo esc_js($available_roles[$role_filter] ?? ''); ?>';
                    var totalCount = <?php echo $total_users; ?>;
                    return confirm('⚠️ ATENÇÃO: Você está prestes a alterar TODOS os ' + totalCount + ' usuários da função "' + oldRoleName + '" para "' + newRole + '".\n\nEsta ação não pode ser desfeita automaticamente.\n\nDeseja continuar?');
                } else {
                    var count = $('.user-checkbox:checked').length;
                    if (count === 0) {
                        alert('Por favor, selecione pelo menos um usuário.');
                        return false;
                    }
                    return confirm('Confirma a alteração de ' + count + ' usuário(s) para a função "' + newRole + '"?');
                }
            };
        });
        </script>

        <!-- CSS customizado -->
        <style>
        .role-badge {
            display: inline-block;
            padding: 3px 8px;
            background: #f0f0f1;
            border-radius: 3px;
            font-size: 12px;
        }
        .search-box {
            display: flex;
            gap: 10px;
            align-items: center;
            margin: 15px 0;
        }
        .search-box input[type="search"] {
            width: 250px;
        }
        .tablenav.top {
            margin-bottom: 10px;
        }
        .tablenav-pages {
            float: right;
        }
        #select-all-filtered {
            background: #2271b1;
            color: white;
            border-color: #2271b1;
            font-weight: bold;
        }
        #select-all-filtered:hover {
            background: #135e96;
            border-color: #135e96;
        }
        #selected-count {
            background: #d63638;
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 13px;
        }
        .bulk-help-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 12px;
            margin: 15px 0;
            border-radius: 4px;
        }
        .bulk-help-box h3 {
            margin-top: 0;
            color: #856404;
            font-size: 14px;
        }
        .bulk-help-box ol {
            margin: 10px 0 0 20px;
            color: #856404;
        }
        .bulk-help-box ol li {
            margin-bottom: 5px;
        }
        </style>
    </div>
    <?php
}

// Processa a mudança de roles em lote
function bulk_process_role_change() {
    // Verifica se uma nova role foi selecionada
    if (empty($_POST['new_role'])) {
        wp_redirect(add_query_arg('error', '2', wp_get_referer()));
        exit;
    }

    $new_role = sanitize_text_field($_POST['new_role']);
    $updated = 0;

    // Roles válidas
    $valid_roles = array('membro', 'orientador', 'coordenador', 'comissao', 'membro-coordenador', 'integrante');
    
    // Verifica se a role é válida
    if (!in_array($new_role, $valid_roles)) {
        wp_redirect(add_query_arg('error', '3', wp_get_referer()));
        exit;
    }

    // Verifica se é seleção de todos de uma função específica
    if (!empty($_POST['select_all_role'])) {
        $old_role = sanitize_text_field($_POST['select_all_role']);
        
        // Busca TODOS os usuários com a role antiga
        $args = array(
            'role' => $old_role,
            'number' => -1, // Sem limite
        );
        
        $user_query = new WP_User_Query($args);
        $users = $user_query->get_results();
        
        // Atualiza cada usuário
        foreach ($users as $user) {
            // Verifica se não é o usuário atual (segurança)
            if ($user->ID != get_current_user_id()) {
                // Remove todas as roles antigas
                $user->set_role('');
                // Define a nova role
                $user->set_role($new_role);
                $updated++;
            }
        }
    } else {
        // Seleção manual de usuários
        // Verifica se usuários foram selecionados
        if (empty($_POST['users']) || !is_array($_POST['users'])) {
            wp_redirect(add_query_arg('error', '1', wp_get_referer()));
            exit;
        }

        $user_ids = array_map('intval', $_POST['users']);

        // Atualiza cada usuário
        foreach ($user_ids as $user_id) {
            $user = get_userdata($user_id);
            
            // Verifica se o usuário existe e não é o usuário atual (segurança)
            if ($user && $user_id != get_current_user_id()) {
                // Remove todas as roles antigas
                $user->set_role('');
                // Define a nova role
                $user->set_role($new_role);
                $updated++;
            }
        }
    }

    // Redireciona com mensagem de sucesso
    wp_redirect(add_query_arg('updated', $updated, wp_get_referer()));
    exit;
}

/******************************************************************************
 * FIM: GERENCIAMENTO DE ROLES EM LOTE
 ******************************************************************************/